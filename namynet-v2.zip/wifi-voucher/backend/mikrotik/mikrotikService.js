const MikroTikAPI = require("../mikrotik/api");

exports.testConnection = async (router) => {

    const api = new MikroTikAPI(router);

    try {

        await api.identity();

        return {
            success: true,
            message: "Koneksi berhasil"
        };

    } catch (err) {

        return {
            success: false,
            message: err.message
        };

    }

};

exports.createVoucher = async (router, data) => {

    const api = new MikroTikAPI(router);

    return await api.createVoucher(
        data.username,
        data.password,
        data.profile
    );

};

exports.hotspotUsers = async (router) => {

    const api = new MikroTikAPI(router);

    return await api.hotspotUsers();

};

exports.deleteVoucher = async (router, username) => {

    const api = new MikroTikAPI(router);

    return await api.deleteVoucher(username);

};
