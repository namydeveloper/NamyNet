const { RouterOSAPI } = require("node-routeros");

class MikroTikConnection {
    constructor(config) {
        this.config = config;
        this.conn = new RouterOSAPI({
            host: config.host,
            user: config.user,
            password: config.password,
            port: config.port || 8728,
            timeout: 5
        });
    }

    async connect() {
        try {
            await this.conn.connect();
            console.log(`[MikroTik] Connected to ${this.config.host}`);
            return this.conn;
        } catch (err) {
            console.error("[MikroTik] Connection failed");
            throw err;
        }
    }

    async disconnect() {
        if (this.conn.connected) {
            await this.conn.close();
            console.log("[MikroTik] Disconnected");
        }
    }
}

module.exports = MikroTikConnection;
