const MikroTikConnection = require("./connect");

class MikroTikAPI {

    constructor(router){

        this.router = new MikroTikConnection({

            host: router.host,
            port: router.port,
            user: router.username,
            password: router.password

        });

    }
    async createHotspotUser(username, password, profile = "default") {

    return await this.command([

        "/ip/hotspot/user/add",

        `=name=${username}`,

        `=password=${password}`,

        `=profile=${profile}`

    ]);

}
    async getConnection(){

        return await this.router.connect();

    }

    async command(commands){

        const conn = await this.getConnection();

        const ch = conn.openChannel();

        const result = await ch.write(commands);

        await conn.close();

        return result;

    }

    async identity(){

        return await this.command([
            "/system/identity/print"
        ]);

    }

    async hotspotUsers(){

        return await this.command([
            "/ip/hotspot/user/print"
        ]);

    }

       async hotspotActive(){

    return await this.command([
        "/ip/hotspot/active/print"
    ]);

}

    async createVoucher(username,password,profile="default"){

        return await this.command([

            "/ip/hotspot/user/add",

            `=name=${username}`,

            `=password=${password}`,

            `=profile=${profile}`

        ]);

    }

async disconnectUser(username){

    const active = await this.command([
        "/ip/hotspot/active/print"
    ]);

    const user = active.find(u =>
        u.user === username ||
        u.name === username
    );

    if(!user){
        return { success:true };
    }

    await this.command([
        "/ip/hotspot/active/remove",
        `=.id=${user[".id"]}`
    ]);

    return { success:true };

}

    async deleteVoucher(username){

    // Putuskan sesi aktif
    await this.disconnectUser(username);

    // Hapus cookie login
    await this.deleteCookie(username);

    // Cari user hotspot
    const users = await this.hotspotUsers();

    const user = users.find(u => u.name === username);

    if(!user){

        return {
            success:false,
            message:"User tidak ditemukan"
        };

    }

    await this.command([
        "/ip/hotspot/user/remove",
        `=.id=${user[".id"]}`
    ]);

    return { success:true };

}
// ===============================
// SYSTEM RESOURCE
// ===============================
async systemResource(){

    return await this.command([
        "/system/resource/print"
    ]);

}

// ===============================
// ROUTERBOARD
// ===============================
async routerboard(){

    return await this.command([
        "/system/routerboard/print"
    ]);

}
// ===============================
// DELETE HOTSPOT COOKIE
// ===============================
async deleteCookie(username){

    const cookies = await this.command([
        "/ip/hotspot/cookie/print"
    ]);

    const list = cookies.filter(c => c.user === username);

    for (const cookie of list){

        await this.command([
            "/ip/hotspot/cookie/remove",
            `=.id=${cookie[".id"]}`
        ]);

    }

    return { success:true };

}
// ===============================
// ROUTER INFO
// ===============================
async routerInfo(){

    const identity = await this.identity();
    const resource = await this.systemResource();
    const board = await this.routerboard();

    return {

        identity : identity[0] || {},
        resource : resource[0] || {},
        board    : board[0] || {}

    };

}
}

module.exports = MikroTikAPI;
