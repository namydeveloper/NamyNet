const MikroTikAPI = require("./api");

const mikrotik = new MikroTikAPI({
    host: "10.100.0.2",
    port: 8728,
    username: "namynet",
    password: "Namy1234@MRX"
});

(async () => {

    try {

        console.log("CREATE VOUCHER");

        let add = await mikrotik.createVoucher(
            "TEST003",
            "123456",
            "default"
        );

        console.log(add);

        console.log("================");

        let users = await mikrotik.hotspotUsers();

        console.log(users);

    } catch (e) {

        console.error(e);

    }

})();
