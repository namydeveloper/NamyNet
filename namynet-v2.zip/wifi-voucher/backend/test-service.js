const service = require("./services/systemService");

(async () => {

    console.log(
        await service.getStatus("ssh")
    );

})();
