// =======================================
// NAMYNET SYSTEM SERVICE
// =======================================

const { exec } = require("child_process");

function run(cmd) {
    return new Promise((resolve) => {
        exec(cmd, (err, stdout, stderr) => {

            if (err) {
                resolve({
                    success: false,
                    output: stderr.trim()
                });
                return;
            }

            resolve({
                success: true,
                output: stdout.trim()
            });

        });
    });
}

// =======================================
// STATUS
// =======================================

async function getStatus(service) {

    const result = await run(
        `systemctl is-active ${service}`
    );

    return {
        service,
        status: result.output || "unknown",
        running: result.output === "active"
    };

}

// =======================================
// START
// =======================================

async function start(service) {

    await run(`systemctl start ${service}`);

    return getStatus(service);

}

// =======================================
// STOP
// =======================================

async function stop(service) {

    await run(`systemctl stop ${service}`);

    return getStatus(service);

}

// =======================================
// RESTART
// =======================================

async function restart(service) {

    await run(`systemctl restart ${service}`);

    return getStatus(service);

}

// =======================================
// ENABLE
// =======================================

async function enable(service) {

    await run(`systemctl enable ${service}`);

    return getStatus(service);

}

// =======================================
// DISABLE
// =======================================

async function disable(service) {

    await run(`systemctl disable ${service}`);

    return getStatus(service);

}

module.exports = {

    getStatus,

    start,

    stop,

    restart,

    enable,

    disable

};
