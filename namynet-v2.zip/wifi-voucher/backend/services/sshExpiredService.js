// =======================================
// NAMYNET SSH EXPIRED SERVICE
// =======================================

const sshAccountModel = require("../models/sshAccountModel");

// =======================================
// CHECK EXPIRED ACCOUNT
// =======================================

async function checkExpired() {

    try {

        const accounts = await sshAccountModel.expiredAccounts();

        if (!accounts.length) {

            return;

        }

        for (const account of accounts) {

            await sshAccountModel.setExpired(account.id);

            console.log(
                "[SSH EXPIRED]",
                account.username,
                "=> expired"
            );

            // ===================================
            // NEXT VERSION
            // Lock akun SSH di server
            // ===================================

        }

    } catch (err) {

        console.error(
            "[SSH EXPIRED ERROR]",
            err.message
        );

    }

}

module.exports = {

    checkExpired

};
