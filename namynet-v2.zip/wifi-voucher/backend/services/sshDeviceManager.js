// =======================================
// NAMYNET SSH DEVICE MANAGER V2
// =======================================

const sshAccountModel = require("../models/sshAccountModel");
const sessionModel = require("../models/sshSessionModel");
const sshServerModel = require("../models/sshServerModel");
const sshService = require("./sshService");

async function checkLoginAllowed(server_id, username) {

    // Cari account berdasarkan server + username
    const account = await sshAccountModel.findByUsername(
        username,
        server_id
    );

    if (!account) {

        return {
            allowed: false,
            reason: "ACCOUNT_NOT_FOUND"
        };

    }

    // Jumlah device online pada server yang sama
    const online = await sessionModel.getUserOnlineCount(
        username,
        server_id
    );

    // Unlimited (0 = unlimited)
    if (account.device_limit === 0) {

        return {
            allowed: true,
            online,
            limit: account.device_limit
        };

    }

    // Masih boleh login
    if (online < account.device_limit) {

        return {
            allowed: true,
            online,
            limit: account.device_limit
        };

    }

    // Sudah melebihi limit
    return {

        allowed: false,

        online,

        limit: account.device_limit,

        reason: "DEVICE_LIMIT"

    };

}
// =======================================
// ENFORCE DEVICE LIMIT
// =======================================

async function enforceLimit(server_id, username) {

    const account = await sshAccountModel.findByUsername(
        username,
        server_id
    );

    if (!account) {
        return;
    }

    if (account.device_limit === 0) {
        return;
    }

    const sessions = await sessionModel.getOnlineSessionsByUser(
        server_id,
        username
    );

    if (sessions.length <= account.device_limit) {
        return;
    }

    console.log("=================================");
    console.log("DEVICE LIMIT EXCEEDED");
    console.log("SERVER :", server_id);
    console.log("USER   :", username);
    console.log("ONLINE :", sessions.length);
    console.log("LIMIT  :", account.device_limit);
    console.log("=================================");
//////////////////////////////////
const kickSession = sessions[sessions.length - 1];

console.log("KICK PID :", kickSession.pid);
console.log("KICK IP  :", kickSession.ip);

const server = await sshServerModel.findById(server_id);

if (!server) {
    console.log("SERVER NOT FOUND");
    return;
}

const findResult = await sshService.execCommand(
    server,
    `pgrep -u ${username} sshd`
);

if (!findResult.success || !findResult.output.trim()) {
    console.log("SSH PROCESS NOT FOUND");
    return;
}

const pids = findResult.output
    .trim()
    .split("\n")
    .filter(Boolean);

console.log("SSH PIDS :", pids);

let killed = false;

for (const pid of pids.reverse()) {

    const command = `kill -9 ${pid}`;

    const result = await sshService.execCommand(
        server,
        command
    );

    console.log("COMMAND :", command);
    console.log("SUCCESS :", result.success);

    if (result.success) {
        killed = true;
        break;
    }

}

if (!killed) {

    console.log("NO SSH SESSION KILLED");

    return;

}
//////////////////////////////////
const command = `kill -9 ${kickSession.pid}`;

const result = await sshService.execCommand(
    server,
    command
);

console.log("COMMAND :", command);
console.log("SUCCESS :", result.success);

if (!result.success) {

    console.log("KILL FAILED :", result.error);

    return;

}
await sessionModel.forceOffline(
    kickSession.pid
);

console.log("=================================");
console.log("DEVICE KICKED");
console.log("USER   :", username);
console.log("PID    :", kickSession.pid);
console.log("=================================");
}
module.exports = {

    checkLoginAllowed,
    enforceLimit

};
