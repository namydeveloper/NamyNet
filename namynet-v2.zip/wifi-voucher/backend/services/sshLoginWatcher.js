// =======================================
// NAMYNET SSH LOGIN WATCHER V2
// =======================================

const fs = require("fs");
const db = require("../config/database");
const sessionManager = require("./sshSessionManager");
const sessionModel = require("../models/sshSessionModel");
const deviceManager = require("./sshDeviceManager");
const LOG_FILE = "/var/log/auth.log";

let position = 0;

console.log("=================================");
console.log("NamyNet SSH Login Watcher Started");
console.log("Watching:", LOG_FILE);
console.log("=================================");

fs.stat(LOG_FILE, (err, stat) => {

    if (err) {
        console.error(err);
        return;
    }

    position = stat.size;

    setInterval(readNewLines, 1000);

});

async function activateFirstLogin(server_id, username) {

    const [rows] = await db.query(`
    SELECT
        a.id,
        a.status,
        a.first_login,
        a.package_id,
        p.duration
    FROM ssh_accounts a
    LEFT JOIN packages p
        ON p.id = a.package_id
    WHERE a.username=?
      AND a.server_id=?
    LIMIT 1
`,[
    username,
    server_id
]);

    if(rows.length===0){
        return;
    }

    const account = rows[0];

    // Sudah aktif sebelumnya
    if(account.first_login){
        return;
    }

    const now = new Date();

    const expired = new Date(now);

    expired.setMinutes(
        expired.getMinutes() + Number(account.duration || 0)
    );

    await db.query(`
        UPDATE ssh_accounts
        SET
            status='active',
            first_login=?,
            expired_at=?
        WHERE id=?
    `,[
        now,
        expired,
        account.id
    ]);

    console.log("=================================");
    console.log("SSH ACCOUNT ACTIVATED");
    console.log("USERNAME :", username);
    console.log("EXPIRED :", expired);
    console.log("=================================");
}
async function closeSession(pid) {

    try {

        await sessionModel.closeSession(pid);

        console.log("=================================");
        console.log("SSH SESSION CLOSED");
        console.log("PID :", pid);
        console.log("=================================");

    } catch (err) {

        console.error(err);

    }

}

function readNewLines() {

    fs.stat(LOG_FILE, (err, stat) => {

        if (err) return;

        if (stat.size < position) {
            position = 0;
        }

        if (stat.size === position) {
            return;
        }

        const stream = fs.createReadStream(LOG_FILE, {
            start: position,
            end: stat.size
        });

        let data = "";

        stream.on("data", chunk => {
            data += chunk.toString();
        });

        stream.on("end", async () => {

            position = stat.size;

            const lines = data.split("\n");

            for (const line of lines) {

                // =======================================
                // SSH LOGIN DETECTED
                // =======================================

                if (line.includes("Accepted password for")) {

                    const match = line.match(
                        /Accepted password for ([^\s]+)/
                    );

                    if (match) {

                        const username = match[1];

                        const ipMatch = line.match(/from ([0-9a-fA-F\.:]+)/);

                        const pidMatch = line.match(/sshd\[(\d+)\]/);

                        const ip = ipMatch ? ipMatch[1] : "-";

                        const pid = pidMatch ? pidMatch[1] : "-";

                        console.log("=================================");
                        console.log("SSH LOGIN DETECTED");
                        console.log("USERNAME :", username);
                        console.log("IP       :", ip);
                        console.log("PID      :", pid);
                        console.log("TIME     :", new Date().toISOString());
                        console.log("=================================");

              const SERVER_ID = 6;

deviceManager.checkLoginAllowed(
    SERVER_ID,
    username
)
.then(device => {

    console.log("=================================");
    console.log("DEVICE CHECK");
    console.log("USERNAME :", username);
    console.log("ONLINE   :", device.online);
    console.log("ALLOWED  :", device.allowed);

    if (device.limit !== undefined) {
        console.log("LIMIT    :", device.limit);
    }

    console.log("=================================");

})
.catch(err => {

    console.error("DEVICE CHECK ERROR:", err);

});
try {

    const SERVER_ID = 6;

    await sessionManager.login({
        server_id: SERVER_ID,
        username,
        ip,
        pid
    });

    console.log("SESSION MANAGER OK");

    await deviceManager.enforceLimit(
        SERVER_ID,
        username
    );

    await activateFirstLogin(
        SERVER_ID,
        username
    );

} catch (err) {

    console.error("SESSION MANAGER ERROR:", err);

}}}

                // =======================================
                // SSH LOGOUT DETECTED
                // =======================================

                if (line.includes("pam_unix(sshd:session): session closed")) {

                    const pidMatch = line.match(/sshd\[(\d+)\]/);

                    const userMatch = line.match(
                        /session closed for user ([^\s]+)/
                    );

                    if (pidMatch) {

                        const pid = pidMatch[1];

                        const username = userMatch ? userMatch[1] : "-";

                        console.log("=================================");
                        console.log("SSH LOGOUT DETECTED");
                        console.log("USERNAME :", username);
                        console.log("PID      :", pid);
                        console.log("TIME     :", new Date().toISOString());
                        console.log("=================================");

                        sessionManager.logout(pid);

                        closeSession(pid)
                            .catch(console.error);

                    }

                }

            }

        });

    });

}
