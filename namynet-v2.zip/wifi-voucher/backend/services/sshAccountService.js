// =======================================
// NAMYNET SSH ACCOUNT SERVICE
// =======================================

const sshServerModel = require("../models/sshServerModel");
const packageModel = require("../models/packageModel");
const sshAccountModel = require("../models/sshAccountModel");
const sshService = require("./sshService");

// =======================================
// SHELL ESCAPE
// =======================================

function shellEscape(value) {

    if (value === null || value === undefined) {
        return "''";
    }

    return `'${String(value).replace(/'/g, `'\\''`)}'`;

}

// =======================================
// GET SERVER
// =======================================

async function getServer(serverId) {

    const server = await sshServerModel.findById(serverId);

    if (!server) {
        throw new Error("SSH Server tidak ditemukan");
    }

    return server;

}

// =======================================
// CREATE SSH ACCOUNT
// =======================================

async function createAccount(data) {

    // ==========================
    // SERVER
    // ==========================

    const server = await getServer(data.server_id);
    // ==========================
    // VALIDASI INPUT
    // ==========================

    if (!data.server_id) {
        throw new Error("Server wajib dipilih");
    }

    if (!data.package_id) {
        throw new Error("Package wajib dipilih");
    }

    if (!data.username || !data.username.trim()) {
        throw new Error("Username wajib diisi");
    }

    if (!data.password || !data.password.trim()) {
        throw new Error("Password wajib diisi");
    }

    // hanya huruf, angka, underscore, titik dan strip
    if (!/^[a-zA-Z0-9_.-]+$/.test(data.username)) {
        throw new Error("Username mengandung karakter yang tidak diperbolehkan");
    }
    // ==========================
    // PACKAGE
    // ==========================

    const packageModel = require("../models/packageModel");

    const pkg = await packageModel.findById(data.package_id);

    if (!pkg) {
        throw new Error("Package tidak ditemukan");
    }

    // Belum aktif sampai login pertama
   data.first_login = null;
   data.expired_at = null;

    // default port
    data.ssh_port = 22;
    data.dropbear_port = 80;
    data.ssl_port = 443;
    data.udp_port = 7300;
    data.status = "unused";

    // ==========================
    // CREATE USER VPS
    // ==========================

    const username = shellEscape(data.username);
    const password = shellEscape(data.password);

    const command = [
    `useradd -M -s /bin/false ${username}`,
    `echo ${username}:${password} | chpasswd`
].join(" && ");

    const result = await sshService.execCommand(server, command);

    if (!result.success) {
        throw new Error(result.error || "Gagal membuat akun SSH");
    }

    const id = await sshAccountModel.create(data);

    return {
        success: true,
        id
    };

}
// =======================================
// DELETE SSH ACCOUNT
// =======================================

async function deleteAccount(id) {

    const account = await sshAccountModel.findById(id);
    if (!account) {
        throw new Error("Account tidak ditemukan");
    }

    if (!account.username || !account.username.trim()) {
        throw new Error("Username account kosong");
    }

    if (!/^[a-zA-Z0-9_.-]+$/.test(account.username)) {
        throw new Error("Username account tidak valid");
    }

    if (!account.server_id) {
        throw new Error("Server account tidak valid");
    }

    if (!account) {
        throw new Error("Account tidak ditemukan");
    }

    const server = await getServer(account.server_id);

    const username = shellEscape(account.username);

    const command = [

    // Putuskan semua proses user
    `pkill -KILL -u ${username} || true`,

    // Tunggu proses selesai
    `sleep 1`,

    // Hapus account Linux
    `userdel -f -r ${username}`

].join(" && ");

const result = await sshService.execCommand(
    server,
    command
);

    if (!result.success) {

        throw new Error(
            result.error || "Gagal menghapus account dari VPS"
        );

    }

    await sshAccountModel.delete(id);

    return {

        success: true

    };

}
// =======================================
// CHANGE PASSWORD
// =======================================

async function changePassword(id, password) {

    const account = await sshAccountModel.findById(id);

    if (!account) {
        throw new Error("Account tidak ditemukan");
    }

    const server = await getServer(account.server_id);

    const username = shellEscape(account.username);
    const newPassword = shellEscape(password);

    const command =
    `echo ${username}:${newPassword} | chpasswd`;

    const result = await sshService.execCommand(server, command);

    if (!result.success) {
        throw new Error(
            result.error || "Gagal mengganti password"
        );
    }

    await sshAccountModel.update(id, {
        ...account,
        password
    });

    return {
        success: true
    };

}
// =======================================
// SUSPEND ACCOUNT
// =======================================

async function suspendAccount(id) {

    const account = await sshAccountModel.findById(id);

    if (!account) {
        throw new Error("SSH Account tidak ditemukan");
    }

    const server = await getServer(account.server_id);

    const username = shellEscape(account.username);

    const result = await sshService.execCommand(
    server,
    `passwd -l ${username}`);

    if (!result.success) {
        throw new Error(result.error || "Gagal suspend account");
    }

    await sshAccountModel.updateStatus(id, "disabled");

    return {
        success: true
    };

}

// =======================================
// ACTIVATE ACCOUNT
// =======================================
async function activateAccount(id) {

    const account = await sshAccountModel.findById(id);

    if (!account) {
        throw new Error("SSH Account tidak ditemukan");
    }

    const server = await getServer(account.server_id);

    const username = shellEscape(account.username);

    const result = await sshService.execCommand(
    server,
    `passwd -u ${username}`);

    if (!result.success) {
        throw new Error(result.error || "Gagal mengaktifkan account");
    }

    await sshAccountModel.updateStatus(id, "active");

    return {
        success: true
    };

}
// =======================================
// RENEW ACCOUNT
// =======================================

async function renewAccount(id, package_id) {
////////////////////
console.log("RENEW ID:", id);
console.log("PACKAGE ID:", package_id);
console.log("TYPE:", typeof package_id);
////////////////////
    const account = await sshAccountModel.findById(id);

    if (!account) {
        throw new Error("SSH Account tidak ditemukan");
    }

    const server = await getServer(account.server_id);

    const pkg = await packageModel.findById(package_id);
////////////////////////
console.log("PACKAGE:", pkg);
///////////////////////
    if (!pkg) {
        throw new Error("Package tidak ditemukan");
    }

    const duration = Number(pkg.duration || 0);

    // ==========================
    // HITUNG EXPIRED BARU
    // ==========================

    let expired = new Date();

    if (
        account.expired_at &&
        new Date(account.expired_at) > expired
    ) {

        expired = new Date(account.expired_at);

    }

    expired.setMinutes(
        expired.getMinutes() + duration
    );

    const expireLinux = expired
        .toISOString()
        .slice(0,10);

    // ==========================
    // UPDATE EXPIRE LINUX
    // ==========================

    const username = shellEscape(account.username);

    const command = [
    `usermod -e ${expireLinux} ${username}`,
    `passwd -u ${username}`
].join(" && ");

    const result = await sshService.execCommand(
        server,
        command
    );

    if (!result.success) {

        throw new Error(
            result.error || "Renew SSH gagal"
        );

    }

    await sshAccountModel.renew(
        id,
        expired
    );

    return {

        success:true,
        expired_at:expired

    };

}
// =======================================
module.exports = {

    getServer,
    createAccount,
    deleteAccount,
    changePassword,
    suspendAccount,
    activateAccount,
    renewAccount

};
