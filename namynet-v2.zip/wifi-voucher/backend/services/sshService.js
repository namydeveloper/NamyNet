// =======================================
// NAMYNET SSH SERVICE
// =======================================

const { Client } = require("ssh2");

// =======================================
// TEST CONNECTION
// =======================================

exports.testConnection = (server) => {

    return new Promise((resolve) => {

        const conn = new Client();

        conn.on("ready", () => {

            conn.exec("hostname", (err, stream) => {

                if (err) {

                    conn.end();

                    return resolve({

                        success: false,

                        message: err.message

                    });

                }

                let hostname = "";

                stream.on("data", (data) => {

                    hostname += data.toString();

                });

                stream.on("close", () => {

                    conn.end();

                    resolve({

                        success: true,

                        hostname: hostname.trim()

                    });

                });

            });

        });

        conn.on("error", (err) => {

            resolve({

                success: false,

                message: err.message

            });

        });

        conn.connect({

            host: server.host,

            port: server.ssh_port,

            username: server.username,

            password: server.password,

            readyTimeout: 10000

        });

    });

};
// =======================================
// EXECUTE COMMAND
// =======================================

exports.execCommand = (server, command) => {

    return new Promise((resolve) => {

        const conn = new Client();

        conn.on("ready", () => {

            conn.exec(command, (err, stream) => {

                if (err) {

                    conn.end();

                    return resolve({

                        success: false,
                        output: "",
                        error: err.message

                    });

                }

                let stdout = "";
                let stderr = "";

                stream.on("data", (data) => {

                    stdout += data.toString();

                });

                stream.stderr.on("data", (data) => {

                    stderr += data.toString();

                });

                stream.on("close", (code) => {

                   stream.on("exit", (code) => {

    conn.end();

    resolve({

        success: code === 0,

        code,

        output: stdout.trim(),

        error: stderr.trim()

    });

});
                    conn.end();

                    resolve({

                        success: code === 0,

                        code,

                        output: stdout.trim(),

                        error: stderr.trim()

                    });

                });

            });

        });

        conn.on("error", (err) => {

            resolve({

                success: false,

                code: -1,

                output: "",

                error: err.message

            });

        });

        conn.connect({

            host: server.host,

            port: server.ssh_port,

            username: server.username,

            password: server.password,

            readyTimeout: 10000

        });

    });

};
// =======================================
// GET SYSTEM INFO
// =======================================

exports.getSystemInfo = async (server) => {

    try {

        const [
            hostname,
            os,
            kernel,
            uptime,
            ram,
            disk,
            cpu
        ] = await Promise.all([

            exports.execCommand(server, "hostname"),

            exports.execCommand(server, "grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '\"'"),

            exports.execCommand(server, "uname -r"),

            exports.execCommand(server, "uptime -p"),

            exports.execCommand(server, "free -m"),

            exports.execCommand(server, "df -h /"),

            exports.execCommand(server, "nproc")

        ]);

        return {

            success: true,

            hostname: hostname.output,

            os: os.output,

            kernel: kernel.output,

            uptime: uptime.output,

            cpu_cores: cpu.output,

            ram: ram.output,

            disk: disk.output

        };

    } catch (err) {

        return {

            success: false,

            message: err.message

        };

    }

};
