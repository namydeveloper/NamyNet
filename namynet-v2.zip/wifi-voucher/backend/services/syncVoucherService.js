const routerModel = require("../models/routerModel");
const voucherModel = require("../models/voucherModel");
const activityModel = require("../models/activityModel");
const mikrotikService = require("./mikrotikService");

exports.sync = async () => {

    const routers = await routerModel.getAll();

    for (const router of routers) {

        try {

            const active = await mikrotikService.hotspotActive(router);

            for (const user of active) {

                const username =
                    user.user ||
                    user.name ||
                    user.username;

                if (!username) continue;

                const updated =
                    await voucherModel.markAsUsed(username);

                if (updated > 0) {

                    await activityModel.add(
                        "fa-wifi",
                        `Voucher ${username} digunakan`
                    );

                }

            }

        } catch (err) {

            console.log("Router offline:", router.name);

        }

    }

};
