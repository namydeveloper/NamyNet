// =======================================
// NAMYNET SSH SESSION MANAGER
// =======================================

const sessionModel = require("../models/sshSessionModel");
const activeSessions = new Map();

async function login(data) {

    activeSessions.set(data.pid, {
        server_id: data.server_id,
        username: data.username,
        ip: data.ip,
        pid: data.pid,
        loginTime: new Date()
    });
try {

    const account = await sessionModel.getAccountByUsername(
        data.username,
        data.server_id
    );

    if (!account) {

        console.log("=================================");
        console.log("ACCOUNT NOT FOUND");
        console.log("SERVER  :", data.server_id);
        console.log("USER    :", data.username);
        console.log("=================================");

        return;

    }

    await sessionModel.createSession({

        account_id: account.id,
        server_id: data.server_id,
        username: data.username,
        pid: data.pid,
        ip: data.ip

    });

    console.log("=================================");
    console.log("SESSION SAVED");
    console.log("SERVER  :", data.server_id);
    console.log("USER    :", data.username);
    console.log("PID     :", data.pid);
    console.log("=================================");

} catch (err) {

    console.error(err);

}

    console.log("=================================");
    console.log("SESSION CREATED");
    console.log("SERVER  :", data.server_id);
    console.log("USER    :", data.username);
    console.log("ONLINE  :", activeSessions.size);
    console.log("=================================");

}

function logout(pid) {

    activeSessions.delete(pid);

    console.log("=================================");
    console.log("SESSION CLOSED");
    console.log("ONLINE :", activeSessions.size);
    console.log("=================================");
}

function getOnlineUsers() {

    return activeSessions.size;

}

function getSessions(username){

    return [...activeSessions.values()]
        .filter(x=>x.username===username);

}

module.exports = {

    login,
    logout,
    getOnlineUsers,
    getSessions

};
