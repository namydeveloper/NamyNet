const voucherModel = require("../models/voucherModel");
const routerModel = require("../models/routerModel");
const mikrotikService = require("./mikrotikService");
const activityModel = require("../models/activityModel");

exports.run = async () => {

    try {

        const vouchers = await voucherModel.getExpiredVouchers();

        for (const voucher of vouchers) {

            try {

                const router = await routerModel.findById(voucher.router_id);

                if (!router) continue;

                // Putuskan jika masih online
                await mikrotikService.disconnectUser(
                    router,
                    voucher.username
                );

                // Hapus user hotspot
                await mikrotikService.deleteVoucher(
                    router,
                    voucher.username
                );

                // Update database
                await voucherModel.markExpired(voucher.id);

                // Log activity
                await activityModel.add(
                    "fa-clock",
                    `Voucher ${voucher.username} expired otomatis`
                );

                console.log(
                    `[AUTO-EXPIRED] ${voucher.username}`
                );

            } catch (err) {

                console.log(
                    "Gagal expire",
                    voucher.username,
                    err.message
                );

            }

        }

    } catch (err) {

        console.log(err.message);

    }

};
