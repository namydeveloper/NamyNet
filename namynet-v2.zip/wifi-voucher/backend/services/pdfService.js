const PDFDocument = require("pdfkit");
const fs = require("fs");
const path = require("path");
const QRCode = require("qrcode");

const PAGE = {
    width: 595.28,
    height: 841.89,
    margin: 20
};

const CARD = {
    width: 175,
    height: 145,
    gapX: 10,
    gapY: 12,
    cols: 3
};

const COLOR = {
    primary: "#0D6EFD",
    primaryLight: "#EAF4FF",
    border: "#BFD8FF",
    text: "#1F2937",
    gray: "#6B7280",
    success: "#16A34A",
    orange: "#F59E0B",
    white: "#FFFFFF"
};

function formatPrice(price){

    if(price==null) return "-";

    return "Rp" + Number(price).toLocaleString("id-ID");

}

function formatDuration(minute){

    if(!minute) return "-";

    if(minute>=60){

        const h=Math.floor(minute/60);

        const m=minute%60;

        if(m===0){

            return h+" Jam";

        }

        return h+" Jam "+m+" Menit";

    }

    return minute+" Menit";

}

function drawHeader(doc,x,y,w){

    doc.roundedRect(x,y,w,30,8)
        .fill(COLOR.primary);

    doc
        .fillColor(COLOR.white)
        .fontSize(12)
        .font("Helvetica-Bold")
        .text("NAMYNET",x,y+6,{
            width:w,
            align:"center"
        });

    doc
        .fontSize(8)
        .font("Helvetica")
        .text("WIFI VOUCHER",x,y+18,{
            width:w,
            align:"center"
        });

}

function drawFooter(doc,x,y,w){

    doc
        .fillColor(COLOR.gray)
        .fontSize(6)
        .font("Helvetica")
        .text(
            "Hubungkan ke WiFi • Buka Browser • Login",
            x,
            y,
            {
                width:w,
                align:"center"
            }
        );

}
async function drawVoucherCard(doc,v,x,y){

    doc
        .roundedRect(x,y,CARD.width,CARD.height,8)
        .fillAndStroke(COLOR.white,COLOR.border);

    drawHeader(doc,x,y,CARD.width);

    doc
        .fillColor(COLOR.gray)
        .fontSize(7)
        .font("Helvetica")
        .text("KODE VOUCHER",x,y+38,{
            width:CARD.width,
            align:"center"
        });

    doc
        .fillColor(COLOR.primary)
        .font("Helvetica-Bold")
        .fontSize(22)
        .text(v.code,x,y+52,{
            width:CARD.width,
            align:"center"
        });

    doc
        .fillColor(COLOR.text)
        .fontSize(8)
        .font("Helvetica-Bold")
        .text("Paket",x+10,y+92);

    doc
        .font("Helvetica")
        .text(v.package_name || v.profile,x+55,y+92);

    doc
        .font("Helvetica-Bold")
        .text("Harga",x+10,y+106);

    doc
        .font("Helvetica")
        .text(formatPrice(v.price),x+55,y+106);

    doc
        .font("Helvetica-Bold")
        .text("Durasi",x+10,y+120);

    doc
        .font("Helvetica")
        .text(formatDuration(v.duration),x+55,y+120);

        // ==============================
    // QR CODE
    // ==============================

    try {

        const hotspotUrl = "http://10.100.0.1/login";

        const qrData =
            hotspotUrl +
            "?username=" +
            encodeURIComponent(v.username || v.code) +
            "&password=" +
            encodeURIComponent(v.password || v.code);

        const qrBuffer = await QRCode.toBuffer(qrData);

        const qrSize = 46;
        const qrX = x + CARD.width - qrSize - 10;
        const qrY = y + 82;

        doc.image(qrBuffer, qrX, qrY, {
            width: qrSize,
            height: qrSize
        });

        doc
            .fillColor(COLOR.gray)
            .fontSize(5)
            .font("Helvetica")
            .text(
                "SCAN TO LOGIN",
                qrX,
                qrY + qrSize + 1,
                {
                    width: qrSize,
                    align: "center"
                }
            );

    } catch (err) {

        console.log("QR Error:", err.message);

    }

    drawFooter(doc, x, y + 136, CARD.width);

}
function drawMemberCard(doc,v,x,y){

    doc
        .roundedRect(x,y,CARD.width,CARD.height,8)
        .fillAndStroke(COLOR.white,COLOR.border);

    drawHeader(doc,x,y,CARD.width);

    doc
        .fillColor(COLOR.gray)
        .fontSize(7)
        .font("Helvetica")
        .text("MEMBER ACCOUNT",x,y+38,{
            width:CARD.width,
            align:"center"
        });

    doc
        .fillColor(COLOR.text)
        .font("Helvetica-Bold")
        .fontSize(9)
        .text("Username",x+10,y+60);

    doc
        .font("Helvetica")
        .fontSize(12)
        .text(v.username,x+10,y+74);

    doc
        .font("Helvetica-Bold")
        .fontSize(9)
        .text("Password",x+10,y+95);

    doc
        .font("Helvetica")
        .fontSize(12)
        .text(v.password,x+10,y+109);

    drawFooter(doc,x,y+136,CARD.width);

}
exports.generateVoucherPdf = async (vouchers) => {

    return new Promise(async (resolve, reject) => {

        const dir = path.join(__dirname, "..", "uploads", "pdf");

        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        const filename = "voucher-" + Date.now() + ".pdf";
        const filepath = path.join(dir, filename);

        const doc = new PDFDocument({
            size: "A4",
            margin: PAGE.margin
        });

        const stream = fs.createWriteStream(filepath);

        doc.pipe(stream);

        let col = 0;
        let row = 0;
       
        for (let index = 0; index < vouchers.length; index++) {

    const v = vouchers[index];

    const x =
        PAGE.margin +
        (CARD.width + CARD.gapX) * col;

    const y =
        PAGE.margin +
        (CARD.height + CARD.gapY) * row;

    if ((v.type || "voucher") === "member") {

        drawMemberCard(doc, v, x, y);

    } else {

        await drawVoucherCard(doc, v, x, y);

    }

    col++;

    if (col >= CARD.cols) {

        col = 0;
        row++;

    }

    if (row >= 3 && index < vouchers.length - 1) {

        doc.addPage();

        row = 0;
        col = 0;

    }

}


        doc.end();

        stream.on("finish", () => {

            resolve({
                filename,
                filepath
            });

        });

        stream.on("error", reject);

    });

};
