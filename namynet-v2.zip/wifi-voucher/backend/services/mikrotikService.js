const MikroTikAPI = require("../mikrotik/api");

// ===============================
// TEST CONNECTION
// ===============================
exports.testConnection = async (router) => {

    const api = new MikroTikAPI(router);

    try {

        const info = await api.routerInfo();
           
        console.log("================================");
        console.log("RESOURCE:", info.resource);
        console.log("CPU RAW:", info.resource["cpu-load"]);
        console.log("================================");

        const totalMemory = Number(info.resource["total-memory"] || 0);
        const freeMemory = Number(info.resource["free-memory"] || 0);
        const usedMemory = totalMemory - freeMemory;

        const memoryUsage = totalMemory > 0
            ? ((usedMemory / totalMemory) * 100).toFixed(2)
            : 0;

        const totalDisk = Number(info.resource["total-hdd-space"] || 0);
        const freeDisk = Number(info.resource["free-hdd-space"] || 0);

        return {

            success: true,
            online: true,

            identity: info.identity.name || "-",

            version: info.resource.version || "-",

            uptime: info.resource.uptime || "-",

            architecture: info.resource["architecture-name"] || "-",

            platform: info.resource.platform || "-",

            board: info.resource["board-name"] || "-",

            model: info.board.model || "-",

            serial: info.board["serial-number"] || "-",

            cpu: {

                name: info.resource.cpu || "-",

                load: Number(info.resource["cpu-load"] || 0),

                count: Number(info.resource["cpu-count"] || 0),

                frequency: Number(info.resource["cpu-frequency"] || 0)

            },

            memory: {

                total: totalMemory,

                free: freeMemory,

                used: usedMemory,

                usage: Number(memoryUsage)

            },

            storage: {

                total: totalDisk,

                free: freeDisk

            },

            firmware: {

                current: info.board["current-firmware"] || "-",

                factory: info.board["factory-firmware"] || "-"

            }

        };

    } catch (err) {

        return {

            success: false,
            online: false,
            message: err.message

        };

    }

};

// ===============================
// CREATE VOUCHER
// ===============================
exports.createVoucher = async (router, data) => {

    const api = new MikroTikAPI(router);

    return await api.createVoucher(

        data.username,
        data.password,
        data.profile

    );

};

// ===============================
// HOTSPOT USERS
// ===============================
exports.hotspotUsers = async (router) => {

    const api = new MikroTikAPI(router);

    return await api.hotspotUsers();

};

// ===============================
// HOTSPOT ACTIVE
// ===============================
exports.hotspotActive = async (router) => {

    const api = new MikroTikAPI(router);

    return await api.hotspotActive();

};

// ===============================
// DELETE VOUCHER
// ===============================
exports.deleteVoucher = async (router, username) => {

    const api = new MikroTikAPI(router);

    return await api.deleteVoucher(username);

};

// ===============================
// DISCONNECT USER
// ===============================
exports.disconnectUser = async (router, username) => {

    const api = new MikroTikAPI(router);

    return await api.disconnectUser(username);

};

// ===============================
// CREATE HOTSPOT USER
// ===============================
exports.createHotspotUser = async (router, data) => {

    const api = new MikroTikAPI(router);

    return await api.createHotspotUser(

        data.username,
        data.password,
        data.profile

    );

};
