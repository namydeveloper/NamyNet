// =======================================
// NAMYNET SSH ACTIVATION SERVICE
// =======================================

const sshAccountModel = require("../models/sshAccountModel");
const packageModel = require("../models/packageModel");
const sshServerModel = require("../models/sshServerModel");
const sshService = require("./sshService");

async function activate(server_id, username) {
console.log("[ACTIVATE]");
console.log("SERVER :", server_id);
console.log("USER   :", username);
    const account = await sshAccountModel.findByUsername(
    username,
    server_id
);
console.log("[ACCOUNT]", account);

    if (!account) {
        return;
    }

    if (account.status !== "unused") {
        return;
    }

    const pkg = await packageModel.findById(account.package_id);
console.log("[PACKAGE]", pkg);
    if (!pkg) {
        return;
    }

    const server = await sshServerModel.findById(account.server_id);
console.log("[SERVER]", server);
    if (!server) {
        return;
    }

    const duration = Number(pkg.duration || 0);

    const firstLogin = new Date();

    const expiredAt = new Date(firstLogin);

    expiredAt.setMinutes(
        expiredAt.getMinutes() + duration
    );

    const expireLinux =
        expiredAt.toISOString().slice(0,10);

    const result = await sshService.execCommand(
        server,
        `usermod -e ${expireLinux} ${username}`
    );

    if (!result.success) {

        console.log("Gagal update expire linux");

        return;

    }
console.log("[UPDATE DATABASE]");
    await sshAccountModel.update(account.id,{
        ...account,
        status:"active",
        first_login:firstLogin,
        expired_at:expiredAt
    });
console.log("[SUCCESS] ACCOUNT ACTIVATED");
    console.log("--------------------------------");
    console.log("SSH ACCOUNT ACTIVATED");
    console.log("Username :",username);
    console.log("Expired  :",expiredAt);
    console.log("--------------------------------");

}

module.exports = {

    activate

};
