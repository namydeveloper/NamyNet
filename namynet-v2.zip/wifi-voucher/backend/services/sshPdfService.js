// =======================================
// NAMYNET SSH PDF SERVICE
// =======================================

const PDFDocument = require("pdfkit");

// =======================================
// CONFIG
// =======================================

const PAGE = {
    margin: 30,
    cardWidth: 255,
    cardHeight: 155,
    gap: 15
};

const COLOR = {
    primary: "#2563EB",
    dark: "#111827",
    gray: "#6B7280",
    border: "#D1D5DB",
    white: "#FFFFFF"
};

// =======================================
// HEADER
// =======================================

function drawHeader(doc, x, y, width) {

    doc
        .roundedRect(x, y, width, 26, 5)
        .fill(COLOR.primary);

    doc
        .fillColor(COLOR.white)
        .font("Helvetica-Bold")
        .fontSize(12)
        .text(
            "NAMYNET SSH ACCOUNT",
            x,
            y + 7,
            {
                width,
                align: "center"
            }
        );

}

// =======================================
// ROW
// =======================================

function row(doc, label, value, x, y) {

    doc
        .fillColor(COLOR.gray)
        .font("Helvetica-Bold")
        .fontSize(8)
        .text(label, x, y);

    doc
        .fillColor(COLOR.dark)
        .font("Helvetica")
        .fontSize(9)
        .text(
            value ?? "-",
            x + 65,
            y
        );

}

// =======================================
// DATE
// =======================================

function formatDate(date) {

    if (!date) return "-";

    return new Date(date)
        .toLocaleString("id-ID");

}
// =======================================
// DRAW CARD
// =======================================

function drawCard(doc, account, x, y) {

    doc
        .roundedRect(
            x,
            y,
            PAGE.cardWidth,
            PAGE.cardHeight,
            8
        )
        .lineWidth(1)
        .strokeColor(COLOR.border)
        .stroke();

    drawHeader(
        doc,
        x,
        y,
        PAGE.cardWidth
    );

    let top = y + 36;

    row(doc, "Username", account.username, x + 10, top);
    top += 14;

    row(doc, "Password", account.password, x + 10, top);
    top += 14;

    row(doc, "Server", account.server_name, x + 10, top);
    top += 14;

    row(doc, "SSH", account.ssh_port, x + 10, top);
    top += 14;

    row(doc, "Dropbear", account.dropbear_port, x + 10, top);
    top += 14;

    row(doc, "SSL", account.ssl_port, x + 10, top);
    top += 14;
         row(doc, "UDPGW", account.udp_port, x + 10, top);

// beri jarak sebelum Expired
top += 14;

row(
    doc,
    "Expired",
    formatDate(account.expired_at),
    x + 10,
    top
);

// STATUS

const badgeX = x + PAGE.cardWidth - 78;
const badgeY = y + PAGE.cardHeight - 34;

doc
    .roundedRect(
        badgeX,
        badgeY,
        68,
        18,
        4
    )
    .fill(
        account.status === "active"
            ? "#16A34A"
            : "#DC2626"
    );

doc
    .fillColor("#FFFFFF")
    .font("Helvetica-Bold")
    .fontSize(8)
    .text(
        (account.status || "-").toUpperCase(),
        badgeX,
        badgeY + 5,
        {
            width: 68,
            align: "center"
        }
    );
}

// =======================================
// GENERATE PDF
// =======================================

async function generate(accounts, res) {

    const doc = new PDFDocument({

        size: "A4",
        margin: PAGE.margin

    });

    res.setHeader(
        "Content-Type",
        "application/pdf"
    );

    res.setHeader(
        "Content-Disposition",
        'attachment; filename="ssh-accounts.pdf"'
    );

    doc.pipe(res);

    const startX = PAGE.margin;
    const startY = PAGE.margin;

    let x = startX;
    let y = startY;

    accounts.forEach((account, index) => {

        drawCard(
            doc,
            account,
            x,
            y
        );

        // kolom kedua
        if (x === startX) {

            x = startX + PAGE.cardWidth + PAGE.gap;

        } else {

            x = startX;
            y += PAGE.cardHeight + PAGE.gap;

        }

        // halaman baru jika penuh
        if (
            y + PAGE.cardHeight >
            doc.page.height - PAGE.margin
            &&
            index < accounts.length - 1
        ) {

            doc.addPage();

            x = startX;
            y = startY;

        }

    });

    doc.end();

}

// =======================================
// EXPORT
// =======================================

module.exports = {

    generate

};
