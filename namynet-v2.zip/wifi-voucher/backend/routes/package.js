const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");
const controller = require("../controllers/packageController");

router.get("/", auth, controller.index);

router.get("/:id", auth, controller.show);

router.post("/", auth, controller.store);

router.put("/:id", auth, controller.update);

router.delete("/:id", auth, controller.destroy);

module.exports = router;
