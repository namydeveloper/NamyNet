const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");

const chart = require("../controllers/chartController");

router.get("/sales", auth, chart.salesChart);

module.exports = router;
