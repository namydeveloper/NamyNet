const express = require("express");
const router = express.Router();

const homeController = require("../controllers/homeController");

const authRoute = require("./auth");
const dashboardRoute = require("./dashboard");
const routerRoute = require("./router");
const packageRoute = require("./package");
const voucherRoute = require("./voucher");
const chartRoute = require("./chart");
const activityRoute = require("./activity");
const hotspotRoute = require("./hotspotRoutes");
const statisticsRoute = require("./statisticsRoutes");
const settingsRoutes = require("./settingsRoutes");
const sshServerRoutes = require("./sshServerRoutes");
const sshAccountRoutes = require("./sshAccountRoutes");
const sshDeviceRoutes = require("./sshDeviceRoutes");
const websocketRoutes=require("./websocketRoutes");
// Home
router.get("/", homeController.index);

// API
router.use("/api", authRoute);
router.use("/api/dashboard", dashboardRoute);
router.use("/api/routers", routerRoute);
router.use("/api/packages", packageRoute);
router.use("/api/vouchers", voucherRoute);
router.use("/api/chart", chartRoute);
router.use("/api/activity", activityRoute);
router.use("/api/hotspot", hotspotRoute);
router.use("/api/statistics", statisticsRoute);
router.use("/api/settings", settingsRoutes);
router.use("/api/ssh/servers", sshServerRoutes);
router.use("/api/ssh/accounts", sshAccountRoutes);
router.use("/api/ssh/device", sshDeviceRoutes);
router.use("/api/websocket", websocketRoutes);
module.exports = router;
