const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");

const controller = require("../controllers/voucherController");

router.get("/", auth, controller.list);

router.get("/:id/pdf", auth, controller.printPdf);

router.post("/generate", auth, controller.generate);

router.post("/used", controller.markUsed);

router.delete("/:id", auth, controller.deleteVoucher);

router.delete("/", auth, controller.deleteAllVoucher);

module.exports = router;
