const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");
const dashboard = require("../controllers/dashboardController");

router.get("/", auth, dashboard.index);

module.exports = router;
