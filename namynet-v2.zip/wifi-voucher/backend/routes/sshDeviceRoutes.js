// =======================================
// NAMYNET SSH DEVICE ROUTES
// =======================================

const express = require("express");
const router = express.Router();

const controller = require("../controllers/sshDeviceController");

router.get("/online", controller.online);

router.post("/kick/:pid", controller.kick);

module.exports = router;
