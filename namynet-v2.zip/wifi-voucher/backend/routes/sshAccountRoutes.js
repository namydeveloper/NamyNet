const express = require("express");
const router = express.Router();

const controller = require("../controllers/sshAccountController");

// =======================================
// PDF EXPORT (HARUS DI ATAS :id)
// =======================================

router.get("/pdf", controller.exportPdf);

// =======================================

router.get("/", controller.index);
router.get("/:id", controller.show);

router.post("/", controller.store);

router.post("/:id/password", controller.changePassword);
router.post("/:id/renew", controller.renew);
router.post("/:id/suspend", controller.suspend);
router.post("/:id/activate", controller.activate);

router.delete("/:id", controller.destroy);

module.exports = router;
