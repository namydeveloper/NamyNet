const express = require("express");

const router = express.Router();

const controller = require("../controllers/websocketController");

router.get("/status",controller.status);
router.get("/stats", controller.stats);

router.post("/start",controller.start);

router.post("/stop",controller.stop);

router.post("/restart",controller.restart);

module.exports = router;
