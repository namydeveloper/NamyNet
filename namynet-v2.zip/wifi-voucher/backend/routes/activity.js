const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");

const activity = require("../controllers/activityController");

router.get("/", auth, activity.index);

router.delete("/", auth, activity.clear);

module.exports = router;
