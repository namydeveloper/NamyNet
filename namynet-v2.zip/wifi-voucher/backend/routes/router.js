const express = require("express");

const router = express.Router();

const auth = require("../middleware/auth");
const controller = require("../controllers/routerController");

// ======================================
// GET ALL ROUTER
// GET /api/routers
// ======================================
router.get(
    "/",
    auth,
    controller.index
);

// ======================================
// CREATE ROUTER
// POST /api/routers
// ======================================
router.post(
    "/",
    auth,
    controller.store
);
// DETAIL ROUTER
router.get(
    "/:id",
    auth,
    controller.show
);
// ======================================
// UPDATE ROUTER
// PUT /api/routers/:id
// ======================================
router.put(
    "/:id",
    auth,
    controller.update
);

// ======================================
// DELETE ROUTER
// DELETE /api/routers/:id
// ======================================
router.delete(
    "/:id",
    auth,
    controller.destroy
);

// ======================================
// TEST CONNECTION
// POST /api/routers/test/:id
// ======================================
router.post(
    "/test/:id",
    auth,
    controller.test
);

// ======================================
// REFRESH ROUTER
// POST /api/routers/refresh
// ======================================
router.post(
    "/refresh",
    auth,
    controller.refreshRouter
);

module.exports = router;
