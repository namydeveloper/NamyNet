const express = require("express");
const router = express.Router();

const controller = require("../controllers/sshServerController");

router.get("/", controller.index);
router.get("/:id", controller.show);
router.post("/", controller.store);
router.put("/:id", controller.update);
router.delete("/:id", controller.destroy);

router.get("/:id/test", controller.test);
router.get("/:id/system", controller.system);
module.exports = router;
