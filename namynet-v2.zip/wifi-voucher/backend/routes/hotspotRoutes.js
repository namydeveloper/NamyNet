const express = require("express");
const router = express.Router();

const hotspotController = require("../controllers/hotspotController");

router.get("/users", hotspotController.users);
router.post("/disconnect", hotspotController.disconnect);
router.post("/create", hotspotController.create);
router.post("/delete", hotspotController.deleteUser);
module.exports = router;
