// =======================================
// NAMYNET SETTINGS ROUTES
// =======================================

const express = require("express");
const router = express.Router();

const settingsController = require("../controllers/settingsController");

// ===============================
// GET
// ===============================

router.get("/", settingsController.getSettings);

// ===============================
// SAVE
// ===============================

router.post("/router", settingsController.saveRouter);

router.post("/voucher", settingsController.saveVoucher);

router.post("/application", settingsController.saveApplication);

router.post("/domain", settingsController.saveDomain);

// ===============================
// ROUTER
// ===============================

router.post("/test-router", settingsController.testRouter);

// ===============================
// MAINTENANCE
// ===============================

router.post("/sync", settingsController.sync);

router.post("/backup", settingsController.backup);

router.delete("/clear-log", settingsController.clearLog);

router.post("/restart", settingsController.restart);

// ===============================

module.exports = router;

