const packageModel = require("../models/packageModel");

exports.index = async (req, res) => {

    try {

        const data = await packageModel.getAll();

        res.json({
            success: true,
            data
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};

exports.store = async (req, res) => {

    try {

        const id = await packageModel.create(req.body);

        res.json({
            success: true,
            message: "Paket berhasil ditambahkan",
            id
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};

exports.show = async (req, res) => {

    try {

        const data = await packageModel.findById(req.params.id);

        if (!data) {

            return res.status(404).json({
                success: false,
                message: "Paket tidak ditemukan"
            });

        }

        res.json({
            success: true,
            data
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};

exports.update = async (req, res) => {

    try {

        await packageModel.update(req.params.id, req.body);

        res.json({
            success: true,
            message: "Paket berhasil diupdate"
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};

exports.destroy = async (req, res) => {

    try {

        await packageModel.remove(req.params.id);

        res.json({
            success: true,
            message: "Paket berhasil dihapus"
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
