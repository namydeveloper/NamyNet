// =======================================
// NAMYNET WEBSOCKET CONTROLLER
// =======================================
const http = require("http");

const systemService = require("../services/systemService");

const SERVICE = "namynet-websocket";

exports.status = async (req, res) => {

    try{

        const data = await systemService.getStatus(SERVICE);

        res.json({
            success:true,
            data
        });

    }catch(err){

        res.status(500).json({
            success:false,
            message:err.message
        });

    }

};

exports.start = async (req,res)=>{

    const data = await systemService.start(SERVICE);

    res.json({
        success:true,
        data
    });

};

exports.stop = async (req,res)=>{

    const data = await systemService.stop(SERVICE);

    res.json({
        success:true,
        data
    });

};

exports.restart = async (req,res)=>{

    const data = await systemService.restart(SERVICE);

    res.json({
        success:true,
        data
    });

};
exports.stats = async (req, res) => {

    const request = http.get("http://127.0.0.1:8881/websocket/stats", (response) => {

        let body = "";

        response.on("data", chunk => {
            body += chunk;
        });

        response.on("end", () => {

            try {

                return res.json(JSON.parse(body));

            } catch (err) {

                return res.status(500).json({
                    success: false,
                    message: "Invalid response from WebSocket Engine"
                });

            }

        });

    });

    request.setTimeout(3000, () => {

        request.destroy();

        return res.status(504).json({
            success: false,
            message: "WebSocket Engine timeout"
        });

    });

    request.on("error", (err) => {

        return res.status(500).json({
            success: false,
            message: err.message
        });

    });

};
