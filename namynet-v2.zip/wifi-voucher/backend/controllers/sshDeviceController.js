const sessionModel = require("../models/sshSessionModel");
const serverModel = require("../models/sshServerModel");
const accountModel = require("../models/sshAccountModel");
const sshService = require("../services/sshService");

// =======================================
// ONLINE DEVICE
// =======================================

exports.online = async (req, res) => {

    const devices = await sessionModel.getAllOnlineDevices();

    res.json({

        success: true,

        data: devices

    });

};

// =======================================
// KICK DEVICE
// =======================================

exports.kick = async (req, res) => {

    try {

        const pid = req.params.pid;

        const session = await sessionModel.findByPid(pid);

        if (!session) {

            return res.json({

                success: false,

                message: "Session tidak ditemukan"

            });

        }

        const account = await accountModel.findById(session.account_id);

        if (!account) {

            return res.json({

                success: false,

                message: "Account tidak ditemukan"

            });

        }

        const server = await serverModel.findById(account.server_id);

        if (!server) {

            return res.json({

                success: false,

                message: "Server tidak ditemukan"

            });

        }

        const result = await sshService.execCommand(

            server,

            `kill ${pid}`

        );

        if (!result.success) {

            return res.json({

                success: false,

                message: result.error || "Gagal kick device"

            });

        }

        await sessionModel.forceOffline(pid);

        res.json({

            success: true,

            message: "Device berhasil di-kick"

        });

    } catch (err) {

        res.json({

            success: false,

            message: err.message

        });

    }

};
