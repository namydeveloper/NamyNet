// =======================================
// NAMYNET SSH ACCOUNT CONTROLLER
// =======================================

const sshAccountModel = require("../models/sshAccountModel");
const sshAccountService = require("../services/sshAccountService");
const sshPdfService = require("../services/sshPdfService");
// =======================================
// GET ALL
// =======================================

exports.index = async (req, res) => {

    try {

        const rows = await sshAccountModel.getAll();

        res.json({

            success: true,
            data: rows

        });

    } catch (err) {

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};

// =======================================
// GET DETAIL
// =======================================

exports.show = async (req, res) => {

    try {

        const row = await sshAccountModel.findById(req.params.id);

        if (!row) {

            return res.status(404).json({

                success: false,
                message: "Account tidak ditemukan"

            });

        }

        res.json({

            success: true,
            data: row

        });

    } catch (err) {

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};

// =======================================
// CREATE
// =======================================

exports.store = async (req, res) => {

    try {

        const result = await sshAccountService.createAccount(req.body);

        res.json({

            success: true,
            message: "SSH Account berhasil dibuat",
            data: result

        });

    } catch (err) {

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};

// =======================================
// DELETE
// =======================================

exports.destroy = async (req, res) => {

    try {

        const result = await sshAccountService.deleteAccount(req.params.id);

        res.json({

            success: true,
            message: "SSH Account berhasil dihapus",
            data: result

        });

    } catch (err) {

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
// =======================================
// CHANGE PASSWORD
// =======================================

exports.changePassword = async (req, res) => {

    try {

        const { password } = req.body;

        if (!password) {

            return res.status(400).json({

                success: false,
                message: "Password wajib diisi"

            });

        }

        const result = await sshAccountService.changePassword(

            req.params.id,
            password

        );

        res.json({

            success: true,
            message: "Password berhasil diubah",
            data: result

        });

    } catch (err) {

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
// =======================================
// RENEW ACCOUNT
// =======================================

exports.renew = async (req, res) => {

    try {

        const { package_id } = req.body;

        if (!package_id) {

            return res.status(400).json({

                success: false,
                message: "Package wajib dipilih"

            });

        }

        const result = await sshAccountService.renewAccount(

            req.params.id,
            package_id

        );

        res.json({

            success: true,
            message: "SSH Account berhasil diperpanjang",
            data: result

        });

    } catch (err) {

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
// =======================================
// SUSPEND ACCOUNT
// =======================================

async function suspend(req, res) {

    try {

        const result = await sshAccountService.suspendAccount(req.params.id);

        res.json({
            success: true,
            message: "SSH Account berhasil disuspend",
            data: result
        });

    } catch (err) {

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

}

// =======================================
// ACTIVATE ACCOUNT
// =======================================

async function activate(req, res) {

    try {

        const result = await sshAccountService.activateAccount(req.params.id);

        res.json({
            success: true,
            message: "SSH Account berhasil diaktifkan",
            data: result
        });

    } catch (err) {

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

}
// =======================================
// EXPORT PDF
// =======================================

exports.exportPdf = async (req, res) => {

    try {

        const accounts = await sshAccountModel.getAll();

        await sshPdfService.generate(
            accounts,
            res
        );

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
exports.suspend = suspend;
exports.activate = activate;
