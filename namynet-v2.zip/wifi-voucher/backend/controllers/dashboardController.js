const dashboardModel = require("../models/dashboardModel");
const routerModel = require("../models/routerModel");
const voucherModel = require("../models/voucherModel");
const mikrotikService = require("../services/mikrotikService");


exports.index = async (req, res) => {

    try {

        let onlineUser = 0;
        let routerOnline = 0;

        const routers = await routerModel.getAll();

        for (const router of routers) {

            try {

                const active = await mikrotikService.hotspotActive(router);

                routerOnline++;
                onlineUser += active.length;

                

            } catch (e) {

                console.log("Router offline :", router.name);

            }

        }

        // Ambil ulang dashboard setelah sinkronisasi
        const dashboard = await dashboardModel.getDashboard();

        dashboard.userOnline = onlineUser;
        dashboard.routerOnline = routerOnline;

        res.json({
            success: true,
            data: dashboard
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};

