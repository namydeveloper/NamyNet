const routerModel = require("../models/routerModel");
const voucherModel = require("../models/voucherModel");
const mikrotikService = require("../services/mikrotikService");

// ===============================
// GET ALL ROUTER
// ===============================
exports.index = async (req, res) => {

    try {

        const routers = await routerModel.getAll();

        const data = await Promise.all(

            routers.map(async (router) => {

                const status = await mikrotikService.testConnection(router);
    
                    console.log(
    "LIST ROUTER CPU:",
    router.name,
    status.cpu?.load
);

                return {

                    id: router.id,

                    name: router.name,

                    host: router.host,

                    port: router.port,

                    username: router.username,

                    is_active: router.is_active,

                    online: status.success,

                    identity: status.identity || "-",

                    version: status.version || "-",

                    model: status.model || "-",

                    uptime: status.uptime || "-",

                    cpu: status.cpu?.load || 0,

                    memory: status.memory?.usage || 0

                };

            })

        );

        res.json({

            success: true,

            data

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// ===============================
// CREATE ROUTER
// ===============================
exports.store = async (req, res) => {

    try {

        const id = await routerModel.create(req.body);

        res.json({

            success: true,
            message: "Router berhasil ditambahkan",
            id

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};

// ===============================
// UPDATE ROUTER
// ===============================
exports.update = async (req, res) => {

    try {

        const router = await routerModel.findById(req.params.id);

        if (!router) {

            return res.status(404).json({

                success: false,
                message: "Router tidak ditemukan"

            });

        }

        await routerModel.update(req.params.id, req.body);

        res.json({

            success: true,
            message: "Router berhasil diupdate"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};

// ===============================
// DELETE ROUTER
// ===============================
exports.destroy = async (req, res) => {

    try {

        const router = await routerModel.findById(req.params.id);

        if (!router) {

            return res.status(404).json({

                success: false,
                message: "Router tidak ditemukan"

            });

        }

        await routerModel.delete(req.params.id);

        res.json({

            success: true,
            message: "Router berhasil dihapus"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};

// ===============================
// TEST CONNECTION
// ===============================
exports.test = async (req, res) => {

    try {

        const router = await routerModel.findById(req.params.id);

        if (!router) {

            return res.status(404).json({

                success: false,
                message: "Router tidak ditemukan"

            });

        }

        const result = await mikrotikService.testConnection(router);
console.log(
    "TEST ROUTER CPU:",
    result.cpu?.load
);
        res.json(result);

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
// ===============================
// DETAIL ROUTER
// ===============================
exports.show = async (req, res) => {

    try {

        const router = await routerModel.findById(req.params.id);

        if (!router) {

            return res.status(404).json({

                success: false,
                message: "Router tidak ditemukan"

            });

        }

        const info = await mikrotikService.testConnection(router);

        res.json({

            success: true,
            data: info

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
exports.refreshRouter = async (req, res) => {

    try {

        const routers = await routerModel.getAll();

        if (!routers.length) {
            return res.status(404).json({
                success: false,
                message: "Router tidak ditemukan"
            });
        }

        const router = routers[0];

        const updated = await voucherModel.refreshRouter(router.id);

        res.json({
            success: true,
            message: "Sinkronisasi berhasil",
            updated
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
