// =======================================
// NAMYNET SSH SERVER CONTROLLER
// =======================================

const sshServerModel = require("../models/sshServerModel");
const sshService = require("../services/sshService");

// ===============================
// GET ALL SSH SERVER
// ===============================
exports.index = async (req, res) => {

    try {

        const servers = await sshServerModel.getAll();

        const data = await Promise.all(

            servers.map(async (server) => {

                let online = false;

                try {

                    const result = await sshService.testConnection(server);

                    online = result.success;

                } catch (e) {

                    online = false;

                }

                return {

                    id: server.id,

                    server_name: server.server_name,

                    host: server.host,

                    ssh_port: server.ssh_port,

                    dropbear_port: server.dropbear_port,

                    ssl_port: server.ssl_port,

                    username: server.username,

                    status: online ? "online" : "offline"

                };

            })

        );

        res.json({

            success: true,

            data

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// ===============================
// CREATE SERVER
// ===============================
exports.store = async (req, res) => {

    try {

        const id = await sshServerModel.create(req.body);

        res.json({

            success: true,

            message: "SSH Server berhasil ditambahkan",

            id

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// ===============================
// UPDATE SERVER
// ===============================
exports.update = async (req, res) => {

    try {

        const server = await sshServerModel.findById(req.params.id);

        if (!server) {

            return res.status(404).json({

                success: false,

                message: "Server tidak ditemukan"

            });

        }

        await sshServerModel.update(req.params.id, req.body);

        res.json({

            success: true,

            message: "SSH Server berhasil diupdate"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// ===============================
// DELETE SERVER
// ===============================
exports.destroy = async (req, res) => {

    try {

        const server = await sshServerModel.findById(req.params.id);

        if (!server) {

            return res.status(404).json({

                success: false,

                message: "Server tidak ditemukan"

            });

        }

        await sshServerModel.delete(req.params.id);

        res.json({

            success: true,

            message: "SSH Server berhasil dihapus"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// ===============================
// DETAIL SERVER
// ===============================
exports.show = async (req, res) => {

    try {

        const server = await sshServerModel.findById(req.params.id);

        if (!server) {

            return res.status(404).json({

                success: false,

                message: "Server tidak ditemukan"

            });

        }

        res.json({

            success: true,

            data: server

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// ===============================
// TEST CONNECTION
// ===============================
exports.test = async (req, res) => {

    try {

        const server = await sshServerModel.findById(req.params.id);

        if (!server) {

            return res.status(404).json({

                success: false,

                message: "Server tidak ditemukan"

            });

        }

        const result = await sshService.testConnection(server);

        res.json(result);

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
// =======================================
// GET SYSTEM INFO
// =======================================

exports.system = async (req, res) => {

    try {

        const server = await sshServerModel.findById(req.params.id);

        if (!server) {

            return res.status(404).json({

                success: false,

                message: "Server tidak ditemukan"

            });

        }

        const result = await sshService.getSystemInfo(server);

        res.json(result);

    } catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
