const routerModel = require("../models/routerModel");
const voucherModel = require("../models/voucherModel");
const mikrotikService = require("../services/mikrotikService");

exports.users = async (req, res) => {

    try {

        const routerId = parseInt(req.query.router_id);

        if (!routerId) {
            return res.status(400).json({
                success: false,
                message: "router_id wajib diisi"
            });
        }

        const router = await routerModel.findById(routerId);

        if (!router) {
            return res.status(404).json({
                success: false,
                message: "Router tidak ditemukan"
            });
        }

        const users = await mikrotikService.hotspotUsers(router);
        const active = await mikrotikService.hotspotActive(router);

        const activeMap = {};

        active.forEach(item => {
            activeMap[item.user] = item;
        });

        const result = users.map(user => {

            const online = activeMap[user.name];

            return {

                username: user.name,
                password: user.password || "",
                profile: user.profile || "",
                comment: user.comment || "",

                status: online ? "online" : "offline",

                ip: online ? online.address : "",
                mac: online ? online["mac-address"] : "",
                uptime: online ? online.uptime : "",
                loginBy: online ? online["login-by"] : "",

                bytesIn: online ? online["bytes-in"] : 0,
                bytesOut: online ? online["bytes-out"] : 0

            };

        });

        res.json({
            success: true,
            data: result
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};

exports.disconnect = async (req, res) => {

    try {

        const { router_id, username } = req.body;

        if (!router_id || !username) {

            return res.status(400).json({
                success: false,
                message: "router_id dan username wajib diisi"
            });

        }

        const router = await routerModel.findById(router_id);

        if (!router) {

            return res.status(404).json({
                success: false,
                message: "Router tidak ditemukan"
            });

        }

        await mikrotikService.disconnectUser(router, username);

        res.json({
            success: true,
            message: "User berhasil didisconnect"
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
exports.create = async (req, res) => {

    try {

        const { router_id, username, password, profile } = req.body;

        if (!router_id || !username || !password || !profile) {

            return res.status(400).json({
                success: false,
                message: "Semua field wajib diisi"
            });

        }

        const router = await routerModel.findById(router_id);

        if (!router) {

            return res.status(404).json({
                success: false,
                message: "Router tidak ditemukan"
            });

        }

        await mikrotikService.createHotspotUser(router, {

            username,
            password,
            profile

        });

        res.json({

            success: true,
            message: "Hotspot User berhasil dibuat"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
// ======================================
// DELETE HOTSPOT USER
// ======================================
exports.deleteUser = async (req, res) => {

    try {

        const { router_id, username } = req.body;

        if (!router_id || !username) {

            return res.status(400).json({
                success: false,
                message: "router_id dan username wajib diisi"
            });

        }

        const router = await routerModel.findById(router_id);

        if (!router) {

            return res.status(404).json({
                success: false,
                message: "Router tidak ditemukan"
            });

        }

        // Hapus dari MikroTik
        await mikrotikService.deleteVoucher(
            router,
            username
        );

        // Hapus dari database
        await voucherModel.deleteByUsername(username);

        res.json({

            success: true,
            message: "User berhasil dihapus"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
