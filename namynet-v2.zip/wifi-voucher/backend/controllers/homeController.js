exports.index = async (req, res) => {

    res.json({
        success: true,
        application: "WiFi Voucher",
        version: "1.0.0",
        developer: "Namy Dev"
    });

};
