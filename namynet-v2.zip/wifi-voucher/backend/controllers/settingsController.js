// =======================================
// NAMYNET SETTINGS CONTROLLER
// =======================================

const os = require("os");
const settingsModel = require("../models/settingsModel");
const mikrotikService = require("../services/mikrotikService");

// =======================================
// GET SETTINGS
// =======================================

exports.getSettings = async (req, res) => {

    try {

        const settings = await settingsModel.getSettings();
        const router = await settingsModel.getRouter();

        res.json({

            success: true,

            data: {

                hostname: os.hostname(),

                serverIp: getServerIP(),

                nodeVersion: process.version,

                pm2Status: "Running",

                uptime: formatUptime(os.uptime()),

                routerName: router ? router.name : "",

                routerIp: router ? router.host : "",

                routerUser: router ? router.username : "",

                routerPort: router ? router.port : 8728,
                
                domain: settings.domain || "",

                loginUrl: settings.login_url || "",

                redirectUrl: settings.redirect_url || "",

                httpsEnable: Number(settings.https_enable || 0),

                voucherPrefix: settings.voucher_prefix || "NM",

                voucherLength: Number(settings.voucher_length || 6),

                expiredDay: Number(settings.expired_day || 30),

                autoDelete: Number(settings.auto_delete || 1),

                autoSync: Number(settings.auto_sync || 1),

                appName: settings.app_name || "NamyNet",

                companyName: settings.company_name || "Namy Dev",

                timezone: settings.timezone || "Asia/Jakarta"

            }

        });

    }

    catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// =======================================
// SAVE ROUTER
// =======================================

exports.saveRouter = async (req, res) => {

    try {

        await settingsModel.saveRouter(req.body);

        res.json({

            success: true,

            message: "Pengaturan router berhasil disimpan."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// =======================================
// SAVE VOUCHER
// =======================================

exports.saveVoucher = async (req, res) => {

    try {

        await settingsModel.saveVoucher(req.body);

        res.json({

            success: true,

            message: "Pengaturan voucher berhasil disimpan."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// =======================================
// SAVE APPLICATION
// =======================================

exports.saveApplication = async (req, res) => {

    try {

        await settingsModel.saveApplication(req.body);

        res.json({

            success: true,

            message: "Pengaturan aplikasi berhasil disimpan."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
// =======================================
// SAVE DOMAIN
// =======================================

exports.saveDomain = async (req, res) => {

    try {

        await settingsModel.saveDomain(req.body);

        res.json({

            success: true,

            message: "Pengaturan Domain Hotspot berhasil disimpan."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
// =======================================
// TEST ROUTER
// =======================================

exports.testRouter = async (req, res) => {
      const { ip, username, password, port } = req.body || {};

    if (!ip || !username) {
    return res.status(400).json({
        success: false,
        message: "Data router tidak lengkap."
    });
}
    try {

        const result = await mikrotikService.testConnection({

    host: ip,

    username: username,

    password: password,

    port: Number(port)

});

        res.json({

    success: result.success,

    message: result.success
        ? "Koneksi MikroTik berhasil."
        : (result.message || "Koneksi MikroTik gagal."),

    data: result

});

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
// =======================================
// SYNC MIKROTIK
// =======================================

exports.sync = async (req, res) => {

    try {

        res.json({

            success: true,

            message: "Sinkronisasi berhasil."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// =======================================
// BACKUP DATABASE
// =======================================

exports.backup = async (req, res) => {

    try {

        res.json({

            success: true,

            message: "Backup database berhasil."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// =======================================
// CLEAR LOG
// =======================================

exports.clearLog = async (req, res) => {

    try {

        res.json({

            success: true,

            message: "Log berhasil dibersihkan."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

// =======================================
// RESTART BACKEND
// =======================================

exports.restart = async (req, res) => {

    try {

        res.json({

            success: true,

            message: "Backend berhasil direstart."

        });

    }

    catch (err) {

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
// =======================================
// HELPER
// =======================================

function getServerIP() {

    const nets = os.networkInterfaces();

    for (const name of Object.keys(nets)) {

        for (const net of nets[name]) {

            if (

                net.family === "IPv4" &&

                !net.internal

            ) {

                return net.address;

            }

        }

    }

    return "-";

}

function formatUptime(seconds) {

    const day = Math.floor(seconds / 86400);

    const hour = Math.floor((seconds % 86400) / 3600);

    const minute = Math.floor((seconds % 3600) / 60);

    return `${day} Hari ${hour} Jam ${minute} Menit`;

}

