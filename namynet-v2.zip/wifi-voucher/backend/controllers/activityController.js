const activityModel = require("../models/activityModel");

exports.index = async (req, res) => {

    try {

        const data = await activityModel.latest(10);

        res.json({
            success: true,
            data
        });

    } catch (err) {

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
exports.clear = async (req, res) => {

    try {

        const total = await activityModel.clear();

        if (total === 0) {

            return res.json({

                success: false,
                message: "Belum ada aktivitas untuk dihapus."

            });

        }

        res.json({

            success: true,
            message: total + " aktivitas berhasil dihapus."

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
