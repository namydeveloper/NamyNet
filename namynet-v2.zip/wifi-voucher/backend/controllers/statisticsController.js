const statisticsModel = require("../models/statisticsModel");
const routerModel = require("../models/routerModel");
const mikrotikService = require("../services/mikrotikService");

exports.index = async (req, res) => {

    try {

        const summary = await statisticsModel.getSummary();
        const income = await statisticsModel.getIncome();
        const voucher = await statisticsModel.getVoucherStats();

        let routerOnline = 0;
        let onlineUsers = 0;

        const routers = await routerModel.getAll();

        for (const router of routers) {

            try {

                const active = await mikrotikService.hotspotActive(router);

                routerOnline++;
                onlineUsers += active.length;

            } catch (err) {

                console.log("Router offline :", router.name);

            }

        }

        summary.routerOnline = routerOnline;
        summary.routerOffline = summary.routers - routerOnline;
        summary.onlineUsers = onlineUsers;

        res.json({

            success: true,

            data: {

                summary,
                income,
                voucher

            }

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,
            message: err.message

        });

    }

};
