const db = require("../config/database");

exports.salesChart = async (req, res) => {

    try {

        const [rows] = await db.query(`
            SELECT
                DATE(v.used_at) AS tanggal,
                COUNT(*) AS total
            FROM vouchers v
            WHERE
                v.status='used'
                AND v.used_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            GROUP BY DATE(v.used_at)
            ORDER BY DATE(v.used_at)
        `);

        const labels = [];
        const values = [];

        for(let i=6;i>=0;i--){

            const d = new Date();

            d.setDate(d.getDate()-i);

            const key = d.toISOString().slice(0,10);

            const item = rows.find(r =>
                r.tanggal.toISOString().slice(0,10)===key
            );

            labels.push(
                d.toLocaleDateString("id-ID",{
                    weekday:"short"
                })
            );

            values.push(item ? item.total : 0);

        }

        res.json({

            success:true,

            labels,

            values

        });

    } catch(err){

        res.status(500).json({

            success:false,

            message:err.message

        });

    }

};
