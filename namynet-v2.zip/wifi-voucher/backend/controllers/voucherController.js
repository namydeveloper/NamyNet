const packageModel = require("../models/packageModel");
const routerModel = require("../models/routerModel");
const voucherModel = require("../models/voucherModel");
const mikrotikService = require("../services/mikrotikService");
const pdfService = require("../services/pdfService");


function generateCode(prefix = "Nm") {

    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";

    let code = prefix;

    for (let i = 0; i < 4; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return code;
}

exports.generate = async (req,res)=>{

    try{

        const {
            router_id,
            package_id,
            qty,
            prefix="NM"
        } = req.body;

        const router = await routerModel.findById(router_id);

        if(!router){

            return res.status(404).json({
                success:false,
                message:"Router tidak ditemukan"
            });

        }

        const pkg = await packageModel.findById(package_id);

        if(!pkg){

            return res.status(404).json({
                success:false,
                message:"Paket tidak ditemukan"
            });

        }

        const result = [];

        for (let i = 1; i <= qty; i++) {

        const code = generateCode(prefix);

            await mikrotikService.createVoucher(router,{
                username:code,
                password:code,
                profile:pkg.profile
            });

            await voucherModel.create({

                code,
                username:code,
                password:code,
                profile:pkg.profile,
                package_id:pkg.id,
                router_id:router.id

            });

            result.push({

    type: "voucher",

    code: code,

    username: code,

    password: code,

    profile: pkg.profile,

    package_name: pkg.name,

    price: pkg.price,

    duration: pkg.duration,

    created_at: new Date()

});

        }

        const pdf = await pdfService.generateVoucherPdf(result);

res.json({

    success: true,
    total: result.length,
    data: result,

    pdf: {

        filename: pdf.filename,

        url: "/uploads/pdf/" + pdf.filename

    }

});

    }catch(err){

        console.error(err);

        res.status(500).json({

            success:false,
            message:err.message

        });

    }

};
exports.list = async (req, res) => {

    try {

        const data = await voucherModel.getAll();

        res.json({
            success: true,
            total: data.length,
            data
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
exports.deleteVoucher = async (req, res) => {

    try {

        const id = req.params.id;

        const voucher = await voucherModel.findById(id);

        if (!voucher) {

            return res.status(404).json({
                success: false,
                message: "Voucher tidak ditemukan"
            });

        }

        const router = await routerModel.findById(voucher.router_id);

        if (!router) {

            return res.status(404).json({
                success: false,
                message: "Router tidak ditemukan"
            });

        }

        // Putuskan user yang sedang online
await mikrotikService.disconnectUser(
    router,
    voucher.username
);

// Hapus user dari Hotspot User
await mikrotikService.deleteVoucher(
    router,
    voucher.username
);

// Hapus dari database
await voucherModel.deleteById(id);

        res.json({

            success: true,

            message: "Voucher berhasil dihapus"

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

exports.deleteAllVoucher = async (req, res) => {

    try {

        const total = await voucherModel.deleteAll();

        res.json({
            success: true,
            deleted: total
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
exports.markUsed = async (req, res) => {

    try {

        const { username } = req.body;

        if (!username) {

            return res.status(400).json({
                success: false,
                message: "Username wajib diisi"
            });

        }

        const total = await voucherModel.markAsUsed(username);

        res.json({

            success: true,

            updated: total

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
exports.printPdf = async (req, res) => {

    try {

        const id = req.params.id;

        const voucher = await voucherModel.findDetailById(id);

        if (!voucher) {

            return res.status(404).json({
                success: false,
                message: "Voucher tidak ditemukan"
            });

        }

        const pdf = await pdfService.generateVoucherPdf([{

            code: voucher.code,
            username: voucher.username,
            password: voucher.password,
            profile: voucher.profile,
            package_name: voucher.package_name,
            price: voucher.price,
            duration: voucher.duration,
            type: voucher.type

        }]);

        res.json({

            success: true,

            pdf: {

                filename: pdf.filename,

                url: "/uploads/pdf/" + pdf.filename

            }

        });

    } catch (err) {

        console.error(err);

        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};

