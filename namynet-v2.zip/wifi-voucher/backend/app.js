require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const morgan = require("morgan");
const app = express();
const cron = require("node-cron");
const syncVoucherService = require("./services/syncVoucherService");
const expiredVoucherService = require("./services/expiredVoucherService");
const sshExpiredService = require("./services/sshExpiredService");
require("./services/sshLoginWatcher");
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(morgan("dev"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const path = require("path");

app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const routes = require("./routes");

app.use("/", routes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log("==================================");
    console.log(" WiFi Voucher Server Running");
    console.log(" Port :", PORT);
    console.log("==================================");
});

cron.schedule("*/30 * * * * *", async () => {

    try {

        await syncVoucherService.sync();
        await expiredVoucherService.run();
        await sshExpiredService.checkExpired();
    } catch (err) {

        console.error("[CRON]", err);

    }

});
