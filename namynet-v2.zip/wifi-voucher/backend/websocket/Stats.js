// =======================================
// NAMYNET ENGINE STATS
// =======================================

const os = require("os");
const ConnectionStore = require("./ConnectionStore");

class Stats {

    get() {

        const memory = process.memoryUsage();

        const load = os.loadavg();

        const conn = ConnectionStore.getStats();

        return {

            uptime: process.uptime(),

            onlineClients: conn.onlineClients,

            totalConnections: conn.totalConnections,

            memory,

            nodeVersion: process.version,

            pid: process.pid,

            cpuLoad: load[0],

            totalMemory: os.totalmem(),

            usedMemory: os.totalmem() - os.freemem()

        };

    }

}

module.exports = new Stats();
