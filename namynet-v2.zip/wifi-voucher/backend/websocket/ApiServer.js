// =======================================
// NAMYNET ENGINE API SERVER
// =======================================

const http = require("http");
const Stats = require("./Stats");
const ConnectionStore = require("./ConnectionStore");

class ApiServer {

    start(port = 8881) {

        this.server = http.createServer((req, res) => {

            res.setHeader("Access-Control-Allow-Origin", "*");
            res.setHeader("Content-Type", "application/json");

            // ==========================
            // ENGINE STATS
            // ==========================
            if (req.url === "/websocket/stats") {

                 return res.end(
    JSON.stringify({
        success: true,
        data: Stats.get()
    }, null, 2)
);

 }

// ==========================
// ACTIVE CONNECTIONS
// ==========================
if (
    req.url === "/ws-api/connections" ||
    req.url === "/connections"
) {

    const clean = (c) => ({

        id: c.id,
        ip: c.ip,
        method: c.method,
        url: c.url,
        host: c.host,
        realHost: c.realHost,
        username: c.username,
        server: c.server,
        status: c.status,
        connectedAt: c.connectedAt,
        disconnectedAt: c.disconnectedAt,
        duration: c.duration,
        rx: c.rx,
        tx: c.tx

    });

    return res.end(
        JSON.stringify(
            {
                active: ConnectionStore.getActive().map(clean),
                history: ConnectionStore.getHistory().map(clean)
            },
            null,
            2
        )
    );

}

// ==========================
// LIVE LOG
// ==========================
if (
    req.url === "/ws-api/logs" ||
    req.url === "/logs"
) {

    const Logger = require("./Logger");

    return res.end(
        JSON.stringify(
            Logger.getLogs(),
            null,
            2
        )
    );

}
// ==========================
// CLEAR LOG
// ==========================
if (
    req.url === "/ws-api/logs/clear" ||
    req.url === "/logs/clear"
) {

    const Logger = require("./Logger");

    Logger.clear();

    return res.end(
        JSON.stringify({
            success: true
        })
    );

}

            // ==========================
            // NOT FOUND
            // ==========================
            res.statusCode = 404;

            res.end(
                JSON.stringify({
                    success: false,
                    message: "Endpoint not found"
                })
            );

        });

        this.server.listen(port, () => {

            console.log(
                `API Server listening on ${port}`
            );

        });

    }

}

module.exports = new ApiServer();
