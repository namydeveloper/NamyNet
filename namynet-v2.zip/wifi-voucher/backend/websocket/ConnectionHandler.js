const Logger = require("./Logger");
const HeaderParser = require("./HeaderParser");
const Tunnel = require("./Tunnel");
const ConnectionStore = require("./ConnectionStore");
class ConnectionHandler {

    constructor(socket) {

        this.socket = socket;
        this.connected = false;
        Logger.info(
            `Client Connected : ${socket.remoteAddress}:${socket.remotePort}`
        );
        let client = null;
       socket.on("data", (buffer) => {

    if (this.connected)
        return;

    this.connected = true;

    Logger.info(`Receive ${buffer.length} bytes`);

    const request = HeaderParser.parse(buffer);

    Logger.info(
    JSON.stringify(request, null, 2)
    );

    client = ConnectionStore.add(socket, request);

    Tunnel.connect(socket, request);

});

        socket.on("close", () => {
             ConnectionStore.remove(socket);
            Logger.info("Client Disconnected");

        });

        socket.on("error", (err) => {

            Logger.error(err.message);

        });

    }

}

module.exports = ConnectionHandler;
