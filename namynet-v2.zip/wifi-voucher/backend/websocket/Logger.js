// =====================================
// NamyNet Universal Tunnel Engine
// Logger V2
// =====================================

class Logger {

    constructor() {

        this.logs = [];
        this.maxLogs = 500;

    }

    push(level, message) {

        const item = {
            time: Date.now(),
            level,
            message
        };

        this.logs.unshift(item);

        if (this.logs.length > this.maxLogs) {
            this.logs.pop();
        }

        console.log(
            `[${new Date(item.time).toISOString()}] ${level} ${message}`
        );

    }

    info(message) {

        this.push("INFO", message);

    }

    warn(message) {

        this.push("WARN", message);

    }

    error(message) {

        this.push("ERROR", message);

    }

    getLogs() {

        return this.logs;

    }

    clear() {

        this.logs = [];

    }

}

module.exports = new Logger();
