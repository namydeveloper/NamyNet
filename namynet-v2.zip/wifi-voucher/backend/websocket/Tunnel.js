const net = require("net");
const Logger = require("./Logger");
const config = require("./config.json");

class Tunnel {

    connect(client, request) {

        let target = config.defaultHost;

        if (request.headers["x-real-host"]) {
            target = request.headers["x-real-host"];
        }

        const parts = target.split(":");

        const host = parts[0];
        const port = parseInt(parts[1] || 22);

        Logger.info(`Tunnel => ${host}:${port}`);

        const remote = net.connect(port, host, () => {

            Logger.info("Target Connected");

            client.write(config.response);

            client.pipe(remote);
            remote.pipe(client);

        });

        remote.on("error", (err) => {

            Logger.error(err.message);

            client.destroy();

        });

        client.on("error", () => {

            remote.destroy();

        });

    }

}

module.exports = new Tunnel();
