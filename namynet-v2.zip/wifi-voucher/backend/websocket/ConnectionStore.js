// =======================================
// NAMYNET CONNECTION STORE
// =======================================

const { randomUUID } = require("crypto");

class ConnectionStore {

    constructor() {

        this.active = [];
        this.history = [];
        this.totalConnections = 0;

    }

    add(socket, request = {}) {

        const client = {

            id: randomUUID(),

            socket,

            ip:
                socket.remoteAddress
                    ?.replace("::ffff:", "") || "Unknown",

            method: request.method || "-",

            url: request.path || "-",

            host:
                request.headers?.host || "-",

            realHost:
                request.headers?.["x-real-host"] ||
                "127.0.0.1:22",

            username: null,

            server: null,

            connectedAt: Date.now(),

            disconnectedAt: null,

            duration: 0,

            status: "ONLINE",

            rx: 0,

            tx: 0

        };

        this.active.push(client);

        this.totalConnections++;

        return client;

    }

    remove(socket) {

        const index = this.active.findIndex(

            c => c.socket === socket

        );

        if (index === -1)
            return;

        const client = this.active[index];

        client.status = "OFFLINE";

        client.disconnectedAt = Date.now();

        client.duration =
            client.disconnectedAt -
            client.connectedAt;

        this.active.splice(index, 1);

        this.history.unshift(client);

        if (this.history.length > 100) {

            this.history.pop();

        }

    }

    getActive() {

        return this.active.map(c => ({

            ip: c.ip,

            method: c.method,

            url: c.url,

            host: c.host,

            realHost: c.realHost,

            username: c.username,

            server: c.server,

            connectedAt: c.connectedAt,

            status: c.status,

            rx: c.rx,

            tx: c.tx

        }));

    }

    getHistory() {

        return this.history;

    }

    getStats() {

        return {

            onlineClients:
                this.active.length,

            totalConnections:
                this.totalConnections

        };

    }

}

module.exports = new ConnectionStore();
