class HeaderParser {

    parse(buffer) {

        const text = buffer.toString();

        const lines = text.split("\r\n");

        const first = lines.shift();

        const parts = first.split(" ");

        const headers = {};

        for (const line of lines) {

            if (!line.includes(":"))
                continue;

            const index = line.indexOf(":");

            const key = line
                .substring(0, index)
                .trim()
                .toLowerCase();

            const value = line
                .substring(index + 1)
                .trim();

            headers[key] = value;

        }

        return {

            method: parts[0] || "",

            path: parts[1] || "",

            version: parts[2] || "",

            headers

        };

    }

}

module.exports = new HeaderParser();
