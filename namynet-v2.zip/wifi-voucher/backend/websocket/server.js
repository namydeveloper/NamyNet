// =====================================
// NamyNet Universal Tunnel Engine
// =====================================

const net = require("net");

const config = require("./config.json");
const Logger = require("./Logger");
const ConnectionHandler = require("./ConnectionHandler");
const ApiServer = require("./ApiServer");
const server = net.createServer((socket) => {

    new ConnectionHandler(socket);

});

server.listen(config.port, config.host, () => {

    Logger.info("====================================");
    Logger.info("NamyNet Universal Tunnel Engine");
    Logger.info(`Listening : ${config.host}:${config.port}`);
    Logger.info("====================================");

    ApiServer.start(8881);

});
