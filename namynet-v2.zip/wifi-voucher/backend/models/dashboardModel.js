const db = require("../config/database");

exports.getDashboard = async () => {

    const [[routers]] = await db.query(
        "SELECT COUNT(*) total FROM routers"
    );

    const [[packages]] = await db.query(
        "SELECT COUNT(*) total FROM packages"
    );

    const [[vouchers]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers"
    );

    const [[used]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers WHERE status='used'"
    );

    const [[unused]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers WHERE status='unused'"
    );
    const [[expired]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers WHERE status='expired'"
    );
     const [[income]] = await db.query(`
SELECT
IFNULL(SUM(p.price),0) total
FROM vouchers v
JOIN packages p
ON p.id=v.package_id
WHERE v.status='used'
AND DATE(v.used_at)=CURDATE()
`);

    return {

    routers: routers.total,

    packages: packages.total,

    vouchers: vouchers.total,

    used: used.total,

    unused: unused.total,

    income: Number(income.total),

    userOnline: 0,

    routerOnline: 0

};
};
