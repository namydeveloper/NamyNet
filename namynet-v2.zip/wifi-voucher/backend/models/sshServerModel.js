// =======================================
// NAMYNET SSH SERVER MODEL
// =======================================

const db = require("../config/database");

// =======================================
// GET ALL SSH SERVER
// =======================================

async function getAll() {

    const [rows] = await db.query(

        `SELECT *
         FROM ssh_servers
         ORDER BY id DESC`

    );

    return rows;

}

// =======================================
// GET SSH SERVER BY ID
// =======================================

async function getById(id) {

    const [rows] = await db.query(

        `SELECT *
         FROM ssh_servers
         WHERE id = ?`,

        [id]

    );

    return rows[0];

}

// =======================================
// CREATE SSH SERVER
// =======================================

async function create(data) {

    const [result] = await db.query(

        `INSERT INTO ssh_servers
        (
            server_name,
            host,
            ssh_port,
            dropbear_port,
            ssl_port,
            username,
            password,
            status
        )
        VALUES
        (
            ?,?,?,?,?,?,?,?
        )`,

        [
            data.server_name,
            data.host,
            data.ssh_port,
            data.dropbear_port,
            data.ssl_port,
            data.username,
            data.password,
            data.status
        ]

    );

    return result.insertId;

}

// =======================================
// UPDATE SSH SERVER
// =======================================

async function update(id, data) {

    await db.query(

        `UPDATE ssh_servers
        SET
            server_name=?,
            host=?,
            ssh_port=?,
            dropbear_port=?,
            ssl_port=?,
            username=?,
            password=?,
            status=?
        WHERE id=?`,

        [

            data.server_name,
            data.host,
            data.ssh_port,
            data.dropbear_port,
            data.ssl_port,
            data.username,
            data.password,
            data.status,
            id

        ]

    );

}

// =======================================
// UPDATE STATUS
// =======================================

async function updateStatus(id, status) {

    await db.query(

        `UPDATE ssh_servers
         SET status = ?
         WHERE id = ?`,

        [status, id]

    );

}

// =======================================
// DELETE SSH SERVER
// =======================================

async function remove(id) {

    await db.query(

        `DELETE FROM ssh_servers
         WHERE id = ?`,

        [id]

    );

}

// =======================================

module.exports = {

    getAll,
    findById: getById,
    create,
    update,
    updateStatus,
    delete: remove

};
