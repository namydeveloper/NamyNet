const db = require("../config/database");

exports.add = async (icon, title, description = null) => {

    await db.query(
        `INSERT INTO activity_logs (icon, title, description)
         VALUES (?,?,?)`,
        [icon, title, description]
    );

};

exports.latest = async (limit = 10) => {

    const [rows] = await db.query(
        `SELECT *
         FROM activity_logs
         ORDER BY created_at DESC
         LIMIT ?`,
        [Number(limit)]
    );

    return rows;

};
exports.count = async () => {

    const [rows] = await db.query(
        "SELECT COUNT(*) AS total FROM activity_logs"
    );

    return rows[0].total;

};

exports.clear = async () => {

    const total = await exports.count();

    if (total === 0) {

        return 0;

    }

    await db.query("TRUNCATE TABLE activity_logs");

    return total;

};
