const db = require("../config/database");

exports.getSummary = async () => {

    const [[routers]] = await db.query(
        "SELECT COUNT(*) total FROM routers"
    );

    const [[packages]] = await db.query(
        "SELECT COUNT(*) total FROM packages"
    );

    const [[vouchers]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers"
    );

    const [[used]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers WHERE status='used'"
    );

    const [[unused]] = await db.query(
        "SELECT COUNT(*) total FROM vouchers WHERE status='unused'"
    );

    const [[expired]] = await db.query(`
        SELECT COUNT(*) total
        FROM vouchers
        WHERE expired_at IS NOT NULL
        AND expired_at < NOW()
    `);

    return {

        routers: Number(routers.total),

        packages: Number(packages.total),

        vouchers: Number(vouchers.total),

        used: Number(used.total),

        unused: Number(unused.total),

        expired: Number(expired.total)

    };

};

exports.getIncome = async () => {

    const [[today]] = await db.query(`
        SELECT IFNULL(SUM(p.price),0) total
        FROM vouchers v
        JOIN packages p
        ON p.id=v.package_id
        WHERE v.status='used'
        AND DATE(v.used_at)=CURDATE()
    `);

    const [[week]] = await db.query(`
        SELECT IFNULL(SUM(p.price),0) total
        FROM vouchers v
        JOIN packages p
        ON p.id=v.package_id
        WHERE v.status='used'
        AND YEARWEEK(v.used_at,1)=YEARWEEK(CURDATE(),1)
    `);

    const [[month]] = await db.query(`
        SELECT IFNULL(SUM(p.price),0) total
        FROM vouchers v
        JOIN packages p
        ON p.id=v.package_id
        WHERE v.status='used'
        AND MONTH(v.used_at)=MONTH(CURDATE())
        AND YEAR(v.used_at)=YEAR(CURDATE())
    `);

    const [[year]] = await db.query(`
        SELECT IFNULL(SUM(p.price),0) total
        FROM vouchers v
        JOIN packages p
        ON p.id=v.package_id
        WHERE v.status='used'
        AND YEAR(v.used_at)=YEAR(CURDATE())
    `);

    return {

        today: Number(today.total),

        week: Number(week.total),

        month: Number(month.total),

        year: Number(year.total)

    };

};

exports.getVoucherStats = async () => {

    const [[today]] = await db.query(`
        SELECT COUNT(*) total
        FROM vouchers
        WHERE DATE(created_at)=CURDATE()
    `);

    const [[week]] = await db.query(`
        SELECT COUNT(*) total
        FROM vouchers
        WHERE YEARWEEK(created_at,1)=YEARWEEK(CURDATE(),1)
    `);

    const [[month]] = await db.query(`
        SELECT COUNT(*) total
        FROM vouchers
        WHERE MONTH(created_at)=MONTH(CURDATE())
        AND YEAR(created_at)=YEAR(CURDATE())
    `);

    return {

        today: Number(today.total),

        week: Number(week.total),

        month: Number(month.total)

    };

};
