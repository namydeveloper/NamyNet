const db = require("../config/database");

exports.create = async (data) => {

    const {
        code,
        username,
        password,
        profile,
        package_id,
        router_id
    } = data;

    const [result] = await db.query(
        `INSERT INTO vouchers
        (
            code,
            username,
            password,
            profile,
            package_id,
            router_id
        )
        VALUES (?,?,?,?,?,?)`,
        [
            code,
            username,
            password,
            profile,
            package_id,
            router_id
        ]
    );

    return result.insertId;

};

exports.getAll = async () => {

    const [rows] = await db.query(`
        SELECT
            v.*,
            p.name AS package_name,
            r.name AS router_name
        FROM vouchers v
        LEFT JOIN packages p
            ON p.id=v.package_id
        LEFT JOIN routers r
            ON r.id=v.router_id
        ORDER BY v.id DESC
    `);

    return rows;

};
exports.findById = async (id) => {

    const [rows] = await db.query(
        "SELECT * FROM vouchers WHERE id=? LIMIT 1",
        [id]
    );

    return rows.length ? rows[0] : null;

};

exports.deleteById = async (id) => {

    const [result] = await db.query(
        "DELETE FROM vouchers WHERE id=?",
        [id]
    );

    return result.affectedRows;

};

exports.deleteAll = async () => {

    const [result] = await db.query(
        "DELETE FROM vouchers"
    );

    return result.affectedRows;

};
exports.markAsUsed = async (username) => {

    const [result] = await db.query(`
        UPDATE vouchers v
        JOIN packages p ON p.id = v.package_id
        SET
            v.status = 'used',
            v.used_at = NOW(),
            v.expired_at = DATE_ADD(NOW(), INTERVAL p.duration MINUTE)
        WHERE
            v.username = ?
            AND v.status = 'unused'
    `, [username]);

    return result.affectedRows;

};
exports.getExpiredVouchers = async () => {

    const [rows] = await db.query(`
        SELECT *
        FROM vouchers
        WHERE
            status='used'
            AND is_active=1
            AND expired_at IS NOT NULL
            AND expired_at <= NOW()
    `);

    return rows;

};

exports.markExpired = async (id) => {

    await db.query(`
        UPDATE vouchers
        SET
            status='expired',
            is_active=0
        WHERE id=?
    `,[id]);

};
exports.existsCode = async (code) => {

    const [rows] = await db.query(
        "SELECT id FROM vouchers WHERE code=? LIMIT 1",
        [code]
    );

    return rows.length > 0;

};
exports.findDetailById = async (id) => {

    const [rows] = await db.query(`
        SELECT
            v.*,
            p.name AS package_name,
            p.price,
            p.duration,
            r.name AS router_name
        FROM vouchers v
        LEFT JOIN packages p
            ON p.id = v.package_id
        LEFT JOIN routers r
            ON r.id = v.router_id
        WHERE v.id = ?
        LIMIT 1
    `,[id]);

    return rows.length ? rows[0] : null;

};
// ===========================================
// Refresh Router Voucher
// ===========================================
exports.refreshRouter = async (routerId) => {

    const sql = `
        UPDATE vouchers
        SET router_id = ?
        WHERE router_id NOT IN (
            SELECT id FROM routers
        )
    `;

    const [result] = await db.query(sql, [routerId]);

    return result.affectedRows;

};
// ===========================================
// DELETE VOUCHER BY USERNAME
// ===========================================
exports.deleteByUsername = async (username) => {

    const [result] = await db.query(
        "DELETE FROM vouchers WHERE username=?",
        [username]
    );

    return result.affectedRows;

};
