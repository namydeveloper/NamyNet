// =======================================
// NAMYNET SSH ACCOUNT MODEL V2
// =======================================

const db = require("../config/database");

// =======================================
// GET ALL
// =======================================

async function getAll() {

    const [rows] = await db.query(`

        SELECT

            a.*,

            m.name,

            s.server_name,

            p.name AS package_name,

            p.duration

        FROM ssh_accounts a

        LEFT JOIN members m
            ON m.id = a.member_id

        LEFT JOIN ssh_servers s
            ON s.id = a.server_id

        LEFT JOIN packages p
            ON p.id = a.package_id

        ORDER BY a.id DESC

    `);

    return rows;

}

// =======================================
// GET BY ID
// =======================================

async function findById(id){

    const [rows]=await db.query(

        `SELECT *

        FROM ssh_accounts

        WHERE id=?`,

        [id]

    );

    return rows[0];

}
// =======================================
// GET BY USERNAME
// =======================================

async function findByUsername(username, server_id){

    const [rows] = await db.query(

        `SELECT *

         FROM ssh_accounts

         WHERE username=?
           AND server_id=?
         LIMIT 1`,

        [
            username,
            server_id
        ]

    );

    return rows[0];

}
// =======================================
// CREATE
// =======================================

async function create(data){

    const [result] = await db.query(

`INSERT INTO ssh_accounts(

member_id,
server_id,
package_id,
username,
password,
ssh_port,
dropbear_port,
ssl_port,
udp_port,
status,
first_login,
expired_at

)

VALUES(

?,?,?,?,?,?,?,?,?,?,?,?

)`,

[
data.member_id,
data.server_id,
data.package_id,
data.username,
data.password,
data.ssh_port,
data.dropbear_port,
data.ssl_port,
data.udp_port,
data.status,
data.first_login,
data.expired_at
]

    );

    return result.insertId;

}

// =======================================
// UPDATE
// =======================================

async function update(id,data){

    await db.query(

`UPDATE ssh_accounts

SET

member_id=?,
server_id=?,
package_id=?,
username=?,
password=?,
ssh_port=?,
dropbear_port=?,
ssl_port=?,
udp_port=?,
status=?,
first_login=?,
expired_at=?

WHERE id=?`,

[
data.member_id,
data.server_id,
data.package_id,
data.username,
data.password,
data.ssh_port,
data.dropbear_port,
data.ssl_port,
data.udp_port,
data.status,
data.first_login,
data.expired_at,
id
]

);

}

// =======================================
// STATUS
// =======================================

async function updateStatus(id,status){

    await db.query(

`UPDATE ssh_accounts

SET status=?

WHERE id=?`,

[status,id]

);

}

// =======================================
// DELETE
// =======================================

async function remove(id){

    await db.query(

`DELETE

FROM ssh_accounts

WHERE id=?`,

[id]

);

}
// =======================================
// EXPIRED ACCOUNT
// =======================================

async function expiredAccounts() {

    const [rows] = await db.query(

        `SELECT *

         FROM ssh_accounts

         WHERE status='active'

         AND expired_at<=NOW()`

    );

    return rows;

}

// =======================================
// SET EXPIRED
// =======================================

async function setExpired(id){

    await db.query(

        `UPDATE ssh_accounts

         SET status='expired'

         WHERE id=?`,

        [id]

    );

}
// =======================================
// RENEW ACCOUNT
// =======================================

async function renew(id, expired_at) {

    await db.query(

        `UPDATE ssh_accounts

         SET

            status='active',

            expired_at=?

         WHERE id=?`,

        [

            expired_at,
            id

        ]

    );

}

module.exports={

getAll,
findById,
findByUsername,
create,
update,
updateStatus,
expiredAccounts,
setExpired,
renew,
delete:remove

};
