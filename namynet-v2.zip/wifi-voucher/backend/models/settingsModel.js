// =======================================
// NAMYNET SETTINGS MODEL
// =======================================

const db = require("../config/database");

// ================================
// GET SETTINGS
// ================================

async function getSettings() {

    const [rows] = await db.query(

        "SELECT setting_key, setting_value FROM settings"

    );

    const settings = {};

    for (const row of rows) {

        switch (row.setting_key) {

    case "voucher_length":
    case "expired_day":
    case "auto_delete":
    case "auto_sync":

        settings[row.setting_key] = Number(row.setting_value);
        break;

    default:

        settings[row.setting_key] = row.setting_value;

}

    }

    return settings;

}

// ================================
// SAVE ROUTER
// ================================

async function saveRouter(data) {

    await db.query(

        `UPDATE settings SET

            router_name=?,
            router_ip=?,
            router_username=?,
            router_password=?,
            router_port=?

        WHERE id=1`,

        [

            data.routerName,
            data.routerIp,
            data.routerUser,
            data.routerPass,
            data.routerPort

        ]

    );

}

// ================================
// SAVE VOUCHER
// ================================

async function saveVoucher(data) {

    const settings = [

        ["voucher_prefix", data.voucherPrefix],
        ["voucher_length", data.voucherLength],
        ["expired_day", data.expiredDay],
        ["auto_delete", data.autoDelete ? 1 : 0],
        ["auto_sync", data.autoSync ? 1 : 0]

    ];

    for (const [key, value] of settings) {

        await db.query(

            `INSERT INTO settings (setting_key, setting_value)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE
             setting_value = VALUES(setting_value)`,

            [key, value]

        );

    }

}

// ================================
// SAVE APPLICATION
// ================================

async function saveApplication(data) {

    const settings = [

        ["app_name", data.appName],
        ["company_name", data.companyName],
        ["timezone", data.timezone]

    ];

    for (const [key, value] of settings) {

        await db.query(

            `INSERT INTO settings (setting_key, setting_value)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE
             setting_value = VALUES(setting_value)`,

            [key, value]

        );

    }

}
// ================================
// SAVE DOMAIN
// ================================

async function saveDomain(data) {

    const settings = [

        ["domain", data.domain],
        ["login_url", data.loginUrl],
        ["redirect_url", data.redirectUrl],
        ["https_enable", data.httpsEnable ? 1 : 0]

    ];

    for (const [key, value] of settings) {

        await db.query(

            `INSERT INTO settings (setting_key, setting_value)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE
             setting_value = VALUES(setting_value)`,

            [key, value]

        );

    }

}
// ================================
// GET ROUTER
// ================================

async function getRouter() {

    const [rows] = await db.query(
        "SELECT * FROM routers WHERE is_active=1 LIMIT 1"
    );

    return rows.length ? rows[0] : null;

}

// ================================
// SAVE ROUTER
// ================================

async function saveRouter(data) {

    await db.query(

        `UPDATE routers SET
            name=?,
            host=?,
            username=?,
            password=?,
            port=?
        WHERE is_active=1`,

        [
            data.routerName,
            data.routerIp,
            data.routerUser,
            data.routerPass,
            data.routerPort
        ]

    );

}
module.exports = {

    getSettings,
    getRouter,

    saveRouter,

    saveVoucher,

    saveApplication,

    saveDomain

};
