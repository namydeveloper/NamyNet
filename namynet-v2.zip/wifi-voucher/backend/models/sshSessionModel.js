// =======================================
// NAMYNET SSH SESSION MODEL
// =======================================

const db = require("../config/database");

async function getAccountByUsername(username, server_id) {

    const [rows] = await db.query(`
        SELECT
            id,
            server_id
        FROM ssh_accounts
        WHERE username=?
          AND server_id=?
        LIMIT 1
    `,[
        username,
        server_id
    ]);

    return rows.length ? rows[0] : null;

}

async function createSession(data) {

    await db.query(`
        INSERT INTO ssh_sessions
(
    account_id,
    server_id,
    username,
    pid,
    ip,
    login_time,
    status
)
        VALUES
(
    ?,
    ?,
    ?,
    ?,
    ?,
    NOW(),
    'online'
)
    `, [
    data.account_id,
    data.server_id,
    data.username,
    data.pid,
    data.ip
]
);

}

async function closeSession(pid) {

    await db.query(`
        UPDATE ssh_sessions
        SET
            status='offline',
            logout_time=NOW()
        WHERE pid=?
          AND status='online'
    `, [pid]);

}
// =======================================
// FORCE OFFLINE BY PID
// =======================================

async function forceOffline(pid) {

    await db.query(`
        UPDATE ssh_sessions
        SET
            status='offline',
            logout_time=NOW()
        WHERE pid=?
    `,[pid]);

}
async function findByPid(pid) {

    const [rows] = await db.query(
        "SELECT * FROM ssh_sessions WHERE pid=? LIMIT 1",
        [pid]
    );

    return rows.length ? rows[0] : null;
}

async function getOnlineSessions() {

    const [rows] = await db.query(`
        SELECT *
        FROM ssh_sessions
        WHERE status='online'
    `);

    return rows;
}

async function countOnlineSessions() {

    const [rows] = await db.query(`
        SELECT COUNT(*) total
        FROM ssh_sessions
        WHERE status='online'
    `);

    return rows[0].total;
}

async function countUserOnline(username) {

    const [rows] = await db.query(`
        SELECT COUNT(*) total
        FROM ssh_sessions
        WHERE username=?
          AND status='online'
    `, [username]);

    return rows[0].total;
}
// =======================================
// GET USER ONLINE SESSIONS
// =======================================

async function getUserOnlineSessions(username, server_id) {

    const [rows] = await db.query(`
        SELECT
            id,
            account_id,
            server_id,
            username,
            pid,
            ip,
            login_time
        FROM ssh_sessions
        WHERE username=?
          AND server_id=?
          AND status='online'
        ORDER BY login_time ASC
    `,[
        username,
        server_id
    ]);

    return rows;

}

// =======================================
// GET USER ONLINE COUNT
// =======================================

async function getUserOnlineCount(username, server_id) {

    const [rows] = await db.query(`
        SELECT COUNT(*) total
        FROM ssh_sessions
        WHERE username=?
          AND server_id=?
          AND status='online'
    `,[
        username,
        server_id
    ]);

    return rows[0].total;

}
// =======================================
// GET ALL ONLINE DEVICES
// =======================================

async function getAllOnlineDevices() {

    const [rows] = await db.query(`
        SELECT
            s.id,
            s.username,
            s.ip,
            s.pid,
            s.login_time,
            a.device_limit
        FROM ssh_sessions s
        LEFT JOIN ssh_accounts a
            ON a.id = s.account_id
        WHERE s.status='online'
        ORDER BY s.login_time DESC
    `);

    return rows;

}
// =======================================
// GET ONLINE SESSIONS BY SERVER + USER
// =======================================

async function getOnlineSessionsByUser(server_id, username) {

    const [rows] = await db.query(`
        SELECT
            id,
            account_id,
            server_id,
            username,
            pid,
            ip,
            login_time
        FROM ssh_sessions
        WHERE server_id=?
          AND username=?
          AND status='online'
        ORDER BY login_time ASC
    `,[
        server_id,
        username
    ]);

    return rows;

}
module.exports = {

    getAccountByUsername,
    createSession,
    closeSession,
    forceOffline,
    findByPid,
    getOnlineSessions,
    countOnlineSessions,
    countUserOnline,

    getUserOnlineSessions,
    getUserOnlineCount,
    getOnlineSessionsByUser,
    getAllOnlineDevices

};
