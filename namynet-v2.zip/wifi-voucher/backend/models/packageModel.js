const db = require("../config/database");

exports.getAll = async () => {

    const [rows] = await db.query(`
        SELECT
            id,
            name,
            profile,
            price,
            duration,
            quota,
            created_at
        FROM packages
        ORDER BY id DESC
    `);

    return rows;

};

exports.create = async (data) => {

    const {
        name,
        profile,
        price,
        duration,
        quota
    } = data;

    const [result] = await db.query(
        `INSERT INTO packages
        (name, profile, price, duration, quota)
        VALUES (?, ?, ?, ?, ?)`,
        [
            name,
            profile,
            price,
            duration,
            quota
        ]
    );

    return result.insertId;

};

exports.findById = async (id) => {

    const [rows] = await db.query(
        "SELECT * FROM packages WHERE id=? LIMIT 1",
        [id]
    );

    if (rows.length === 0) {
        return null;
    }

    return rows[0];

};

exports.update = async (id, data) => {

    const {
        name,
        profile,
        price,
        duration,
        quota
    } = data;

    await db.query(
        `UPDATE packages
        SET
            name=?,
            profile=?,
            price=?,
            duration=?,
            quota=?
        WHERE id=?`,
        [
            name,
            profile,
            price,
            duration,
            quota,
            id
        ]
    );

};

exports.remove = async (id) => {

    await db.query(
        "DELETE FROM packages WHERE id=?",
        [id]
    );

};
