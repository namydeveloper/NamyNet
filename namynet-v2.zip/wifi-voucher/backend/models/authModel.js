const db = require("../config/database");

exports.findByUsername = async (username) => {

    const [rows] = await db.query(
        "SELECT * FROM admins WHERE username = ? LIMIT 1",
        [username]
    );

    if (rows.length === 0) {
        return null;
    }

    return rows[0];
};
