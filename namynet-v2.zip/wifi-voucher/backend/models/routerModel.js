const db = require("../config/database");

// ===============================
// GET ALL ROUTER
// ===============================
exports.getAll = async () => {

    const [rows] = await db.query(`
        SELECT
            id,
            name,
            host,
            port,
            username,
            password,
            is_active,
            created_at
        FROM routers
        ORDER BY id DESC
    `);

    return rows;

};

// ===============================
// FIND BY ID
// ===============================
exports.findById = async (id) => {

    const [rows] = await db.query(
        "SELECT * FROM routers WHERE id = ? LIMIT 1",
        [id]
    );

    return rows.length ? rows[0] : null;

};

// ===============================
// CREATE ROUTER
// ===============================
exports.create = async (data) => {

    const {
        name,
        host,
        port,
        username,
        password,
        is_active
    } = data;

    const [result] = await db.query(
        `INSERT INTO routers
        (name, host, port, username, password, is_active)
        VALUES (?, ?, ?, ?, ?, ?)`,
        [
            name,
            host,
            port,
            username,
            password,
            is_active ?? 1
        ]
    );

    return result.insertId;

};

// ===============================
// UPDATE ROUTER
// ===============================
exports.update = async (id, data) => {

    const {
        name,
        host,
        port,
        username,
        password,
        is_active
    } = data;

    await db.query(
        `UPDATE routers
        SET
            name = ?,
            host = ?,
            port = ?,
            username = ?,
            password = ?,
            is_active = ?
        WHERE id = ?`,
        [
            name,
            host,
            port,
            username,
            password,
            is_active,
            id
        ]
    );

};

// ===============================
// DELETE ROUTER
// ===============================
exports.delete = async (id) => {

    await db.query(
        "DELETE FROM routers WHERE id = ?",
        [id]
    );

};

// ===============================
// ACTIVE ROUTER
// ===============================
exports.getActive = async () => {

    const [rows] = await db.query(
        "SELECT * FROM routers WHERE is_active = 1 ORDER BY id ASC"
    );

    return rows;

};
