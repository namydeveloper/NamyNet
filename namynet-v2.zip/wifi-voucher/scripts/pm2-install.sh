#!/bin/bash

set -e

APP_DIR="/opt/wifi-voucher/backend"
APP_NAME="wifi-voucher"

echo "==================================="
echo " PM2 Installer"
echo "==================================="

cd "$APP_DIR"

echo "Menghapus process lama (jika ada)..."
pm2 delete "$APP_NAME" >/dev/null 2>&1 || true

echo "Menjalankan aplikasi..."
pm2 start app.js --name "$APP_NAME"

echo "Menyimpan konfigurasi..."
pm2 save

echo "Mengaktifkan auto start..."

STARTUP_CMD=$(pm2 startup systemd -u root --hp /root | tail -n 1)

echo "Menjalankan:"
echo "$STARTUP_CMD"

eval "$STARTUP_CMD"

pm2 save

echo ""
echo "==================================="
echo " PM2 BERHASIL DIKONFIGURASI"
echo "==================================="

pm2 status
