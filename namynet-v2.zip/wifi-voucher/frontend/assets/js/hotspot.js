// ======================================
// NAMYNET HOTSPOT USER
// ======================================

// ===============================
// AUTH
// ===============================

if (!localStorage.getItem("token")) {

    location.href = "login.html";

}

// Nama Admin

document.getElementById("adminName").innerHTML =
    localStorage.getItem("username") || "Admin";

// ===============================
// LOGOUT
// ===============================

function logout() {

    if (confirm("Yakin ingin logout?")) {

        localStorage.removeItem("token");
        localStorage.removeItem("username");
        localStorage.removeItem("name");

        location.href = "login.html";

    }

}

// ===============================
// JAM DIGITAL
// ===============================

function updateClock() {

    const now = new Date();

    const hari = now.getDate();
    const bulan = now.getMonth() + 1;
    const tahun = now.getFullYear();

    const jam = String(now.getHours()).padStart(2, "0");
    const menit = String(now.getMinutes()).padStart(2, "0");
    const detik = String(now.getSeconds()).padStart(2, "0");

    document.getElementById("clock").innerHTML =
        `${hari}/${bulan}/${tahun} | ${jam}:${menit}:${detik}`;

}

updateClock();

setInterval(updateClock, 1000);

// ===============================
// FORMAT BYTE
// ===============================

function formatBytes(bytes) {

    bytes = Number(bytes || 0);

    if (bytes < 1024) {

        return bytes + " B";

    }

    if (bytes < 1024 * 1024) {

        return (bytes / 1024).toFixed(1) + " KB";

    }

    if (bytes < 1024 * 1024 * 1024) {

        return (bytes / 1024 / 1024).toFixed(1) + " MB";

    }

    return (bytes / 1024 / 1024 / 1024).toFixed(1) + " GB";

}

// ===============================
// LOAD ROUTER
// ===============================

async function loadRouters() {

    try {

        const result = await apiRequest("/routers");

        const select = document.getElementById("routerSelect");

        select.innerHTML = "";

        if (!result || !result.success) {

            select.innerHTML =
                `<option value="">Router tidak tersedia</option>`;

            return;

        }

        result.data.forEach(router => {

            select.innerHTML += `
                <option value="${router.id}">
                    ${router.name}
                </option>
            `;

        });

        // ===============================
        // UPDATE ROUTER
        // ===============================

        document.getElementById("routerCount").innerHTML =
            result.data.length;

    } catch (err) {

        console.error(err);

    }

}

// ===============================
// LOAD HOTSPOT USER
// ===============================

async function loadUsers() {

    try {

        const routerId =
            document.getElementById("routerSelect").value;

        if (!routerId) return;

        const result =
            await apiRequest("/hotspot/users?router_id=" + routerId);

        const table =
            document.getElementById("userTable");

        table.innerHTML = "";

        if (!result || !result.success) {

            table.innerHTML = `
            <tr>
                <td colspan="9">
                    Gagal mengambil data
                </td>
            </tr>
            `;

            return;

        }

        // ===============================
        // UPDATE USER STATISTIK
        // ===============================

        const totalUser = result.data.length;

        const onlineUser = result.data.filter(
            user => user.status === "online"
        ).length;

        const offlineUser = totalUser - onlineUser;

        document.getElementById("totalUser").innerHTML = totalUser;
        document.getElementById("onlineUser").innerHTML = onlineUser;
        document.getElementById("offlineUser").innerHTML = offlineUser;

        if (result.data.length === 0) {

            table.innerHTML = `
            <tr>
                <td colspan="9">
                    Tidak ada Hotspot User
                </td>
            </tr>
            `;

            return;

        }

        result.data.forEach(user => {

            const status =
                user.status === "online"

                ? `<span class="badge online">
                        Online
                   </span>`

                : `<span class="badge offline">
                        Offline
                   </span>`;

            table.innerHTML += `

<tr>

<td>

<div class="voucher-code">

<i class="fa-solid fa-user"></i>

<span>${user.username}</span>

</div>

</td>

<td>${user.profile || "-"}</td>

<td>${status}</td>

<td>${user.ip || "-"}</td>

<td>${user.mac || "-"}</td>

<td>${user.uptime || "-"}</td>

<td>${formatBytes(user.bytesOut)}</td>

<td>${formatBytes(user.bytesIn)}</td>

<td>

<button
class="disconnect"
onclick="disconnectUser('${user.username}')"
${user.status === "offline" ? "disabled" : ""}>
Disconnect
</button>

<button
class="delete"
onclick="deleteUser('${user.username}')">
Hapus
</button>

</td>

</tr>

`;

        });

    } catch (err) {

        console.error(err);

    }

}

// ===============================
// DISCONNECT
// ===============================

async function disconnectUser(username){

    if(!confirm("Disconnect user " + username + " ?"))

        return;

    const result = await apiRequest("/hotspot/disconnect",{

        method:"POST",

        body:JSON.stringify({

            router_id:
            document.getElementById("routerSelect").value,

            username

        })

    });

    if(result.success){

        loadUsers();

    }else{

        alert(result.message);

    }

}
// ===============================
// DELETE USER
// ===============================
async function deleteUser(username){

    if(!confirm("Hapus user " + username + " ?")){
        return;
    }

    const result = await apiRequest("/hotspot/delete",{

        method:"POST",

        body:JSON.stringify({

            router_id:
            document.getElementById("routerSelect").value,

            username

        })

    });

    if(result.success){

        alert("User berhasil dihapus");

        loadUsers();

    }else{

        alert(result.message);

    }

}
// ===============================
// SEARCH
// ===============================

document.getElementById("search").addEventListener("keyup", function () {

    const keyword = this.value.toUpperCase();

    document.querySelectorAll("#userTable tr").forEach(row => {

        row.style.display =
            row.innerText.toUpperCase().includes(keyword)
            ? ""
            : "none";

    });

});

// ===============================
// ROUTER CHANGE
// ===============================

document.getElementById("routerSelect").addEventListener("change", function () {

    loadUsers();

});

// ===============================
// INIT
// ===============================

async function init() {

    await loadRouters();

    await loadUsers();

}

init();

// ===============================
// AUTO REFRESH
// ===============================

setInterval(async () => {

    await loadUsers();

}, 10000);
