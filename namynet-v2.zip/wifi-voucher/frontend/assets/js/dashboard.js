// ===============================
// NAMYNET DASHBOARD JWT
// ===============================

// Cek token
if (!localStorage.getItem("token")) {
    location.href = "login.html";
}


// Nama Admin
document.getElementById("adminName").innerHTML =
    localStorage.getItem("username") || "Admin";


// Logout
function logout(){

    if(confirm("Yakin ingin logout?")){

        localStorage.removeItem("token");
        localStorage.removeItem("username");

        location.href="login.html";

    }

}


// ===============================
// JAM DIGITAL
// ===============================

function updateClock() {

    const now = new Date();

    const hari = now.getDate();
    const bulan = now.getMonth() + 1;
    const tahun = now.getFullYear();

    const jam = String(now.getHours()).padStart(2, "0");
    const menit = String(now.getMinutes()).padStart(2, "0");
    const detik = String(now.getSeconds()).padStart(2, "0");

    document.getElementById("clock").innerHTML =
        `${hari}/${bulan}/${tahun} | ${jam}:${menit}:${detik}`;

}

updateClock();
setInterval(updateClock, 1000);


// ===============================
// LOAD DASHBOARD DATA
// ===============================

async function loadDashboard(){

    try {

        const result = await apiRequest("/dashboard");


        if(!result || !result.success){

            console.log("Dashboard gagal dimuat");
            return;

        }


        const data = result.data;


        document.getElementById("totalVoucher").innerHTML =
            data.vouchers;


        document.getElementById("routerOnline").innerHTML =
        data.routerOnline;


        document.getElementById("todayIncome").innerHTML =
            "Rp " + Number(data.income).toLocaleString("id-ID");


        document.getElementById("userOnline").innerHTML =
        data.userOnline;


    }
    catch(err){

        console.error(err);

    }

}


loadDashboard();


// ===============================
// AUTO REFRESH 30 DETIK
// ===============================

setInterval(loadDashboard,30000);



// ===============================
// CHART
// ===============================

async function loadChart(){

    const result = await apiRequest("/chart/sales");

    if(!result.success) return;

    new Chart(document.getElementById("salesChart"),{

        type:"line",

        data:{

            labels:result.labels,

            datasets:[{

                label:"Voucher Terjual",

                data:result.values,

                fill:true,

                tension:.4

            }]

        },

        options:{

            responsive:true

        }

    });

}

loadChart();
// ===============================
// LOAD ACTIVITY
// ===============================

async function loadActivity() {

    const result = await apiRequest("/activity");

    if (!result || !result.success) return;

    const list = document.getElementById("activityList");

    list.innerHTML = "";

if (result.data.length === 0) {

    list.innerHTML = `
        <li style="text-align:center;padding:25px;color:#888;">
            <i class="fa-solid fa-inbox" style="font-size:24px;"></i>
            <br><br>
            Belum ada aktivitas.
        </li>
    `;

    return;

}

    result.data.forEach(item => {

        list.innerHTML += `
            <li>
                <i class="fa-solid ${item.icon}"></i>
                ${item.title}
                <br>
                <small>${new Date(item.created_at).toLocaleString("id-ID")}</small>
            </li>
        `;

    });

}

loadActivity();
// ===============================
// CLEAR ACTIVITY
// ===============================

async function clearActivity() {

    const result = await Swal.fire({

        title: "Hapus Aktivitas?",
        text: "Semua aktivitas akan dihapus dan tidak dapat dikembalikan.",
        icon: "warning",

        showCancelButton: true,

        confirmButtonText: "Ya, Hapus",

        cancelButtonText: "Batal",

        confirmButtonColor: "#dc3545"

    });

    if (!result.isConfirmed) return;

    try {

        const res = await apiRequest("/activity", {

            method: "DELETE"

        });

        if (res.success) {

            await Swal.fire({

                icon: "success",
                title: "Berhasil",
                text: res.message,
                timer: 1500,
                showConfirmButton: false

            });

            loadActivity();

        } else {

            await Swal.fire({

                icon: "info",
                title: "Tidak Ada Aktivitas",
                text: res.message

            });

        }

    } catch (err) {

        console.error(err);

        await Swal.fire({

            icon: "error",
            title: "Error",
            text: err.message

        });

    }

}
