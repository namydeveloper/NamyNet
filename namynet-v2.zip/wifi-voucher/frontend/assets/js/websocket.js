// =======================================
// NAMYNET WEBSOCKET MANAGER V2
// =======================================

const $ = (id) => document.getElementById(id);

const statusText = $("statusText");
const uptime = $("uptime");
const online = $("online");
const total = $("total");
const memory = $("memory");
const nodeVersion = $("nodeVersion");
const pid = $("pid");
const memoryBar = $("memoryBar");
const memoryPercent = $("memoryPercent");
const lastRefresh = $("lastRefresh");
const cpuLoad = $("cpuLoad");
const totalRam = $("totalRam");
const usedRam = $("usedRam");
const engineHealth = $("engineHealth");

const btnStart = $("btnStart");
const btnStop = $("btnStop");
const btnRestart = $("btnRestart");
const btnRefresh = $("btnRefresh");

const sidebar = $("sidebar");
const overlay = $("overlay");
const menuToggle = $("menuToggle");

// =======================================
// SIDEBAR
// =======================================

if (menuToggle) {
    menuToggle.onclick = () => {
        sidebar.classList.toggle("open");
        overlay.classList.toggle("show");
    };
}

if (overlay) {
    overlay.onclick = () => {
        sidebar.classList.remove("open");
        overlay.classList.remove("show");
    };
}

// =======================================
// CLOCK
// =======================================

function updateClock() {

    const clock = $("clock");

    if (!clock) return;

    clock.textContent =
        new Date().toLocaleTimeString("id-ID");

}

updateClock();

setInterval(updateClock, 1000);

// =======================================
// ADMIN
// =======================================

const adminName =
    localStorage.getItem("adminName") ||
    localStorage.getItem("username") ||
    "Admin";

if ($("adminName")) {

    $("adminName").textContent = adminName;

}

// =======================================
// LOGOUT
// =======================================

window.logout = function () {

    localStorage.removeItem("token");

    location.href = "index.html";

};

// =======================================
// FORMAT
// =======================================

function formatUptime(sec) {

    sec = Math.floor(sec || 0);

    const day = Math.floor(sec / 86400);

    sec %= 86400;

    const hour = Math.floor(sec / 3600);

    sec %= 3600;

    const min = Math.floor(sec / 60);

    sec %= 60;

    let text = "";

    if (day) text += day + "d ";

    if (hour) text += hour + "h ";

    if (min) text += min + "m ";

    text += sec + "s";

    return text;

}
function formatDuration(ms){

    const sec=Math.floor(ms/1000);

    const h=String(Math.floor(sec/3600)).padStart(2,"0");

    const m=String(Math.floor((sec%3600)/60)).padStart(2,"0");

    const s=String(sec%60).padStart(2,"0");

    return `${h}:${m}:${s}`;

}

function formatMemory(bytes) {

    return ((bytes || 0) / 1024 / 1024).toFixed(2) + " MB";

}

function formatGB(bytes) {

    return ((bytes || 0) / 1024 / 1024 / 1024).toFixed(2) + " GB";

}

// =======================================
// BUTTON
// =======================================

function lockButtons(state) {

    [btnStart, btnStop, btnRestart, btnRefresh].forEach(btn => {

        if (btn) btn.disabled = state;

    });

}

// =======================================
// STATUS
// =======================================

async function loadStatus() {

    try {

        const res = await apiRequest("/websocket/status");

        if (res.success && res.data.running) {

            statusText.innerHTML = "🟢 Running";
            statusText.className = "card-value running";

        } else {

            statusText.innerHTML = "🔴 Stopped";
            statusText.className = "card-value stopped";

        }

    } catch (e) {

        console.error(e);

        statusText.innerHTML = "⚪ Offline";
        statusText.className = "card-value stopped";

    }

}

// =======================================
// LOAD STATS
// =======================================

async function loadStats() {

    try {

        const res = await apiRequest("/websocket/stats");

        if (!res.success) return;

        const d = res.data;

        uptime.textContent = formatUptime(d.uptime);

        online.textContent = d.onlineClients || 0;

        total.textContent = d.totalConnections || 0;

        memory.textContent = formatMemory(d.memory.rss);

        nodeVersion.textContent = d.nodeVersion;

        pid.textContent = d.pid;

        if (cpuLoad)
            cpuLoad.textContent =
                Number(d.cpuLoad || 0).toFixed(2);

        if (totalRam)
            totalRam.textContent =
                formatGB(d.totalMemory);

        if (usedRam)
            usedRam.textContent =
                formatGB(d.usedMemory);

        if (d.totalMemory) {

            const percent = Math.round(

                (d.memory.rss / d.totalMemory) * 100

            );

            memoryBar.style.width = percent + "%";

            memoryPercent.textContent = percent + "%";

        }

        if (engineHealth) {

            if (d.cpuLoad < 1) {

                engineHealth.innerHTML = "🟢 Excellent";

                engineHealth.className =
                    "card-value running";

            } else if (d.cpuLoad < 2) {

                engineHealth.innerHTML = "🟡 Warning";

                engineHealth.className =
                    "card-value";

            } else {

                engineHealth.innerHTML = "🔴 Critical";

                engineHealth.className =
                    "card-value stopped";

            }

        }

        lastRefresh.textContent =
            new Date().toLocaleTimeString("id-ID");

    } catch (err) {

        console.error("Load Stats Error:", err);

    }

}

// =======================================
// REFRESH
// =======================================

async function refresh() {

    await Promise.all([

        loadStatus(),

        loadStats()

    ]);

}

// =======================================
// ACTION
// =======================================

async function sendAction(action) {

    lockButtons(true);

    try {

        await apiRequest("/websocket/" + action, {

            method: "POST"

        });

    } catch (e) {

        console.error(e);

    }

    setTimeout(async () => {

        await refresh();

        lockButtons(false);

    }, 1500);

}

// =======================================
// BUTTON EVENT
// =======================================

if (btnStart)
    btnStart.onclick = () => sendAction("start");

if (btnStop)
    btnStop.onclick = () => sendAction("stop");

if (btnRestart)
    btnRestart.onclick = () => sendAction("restart");

if (btnRefresh)
    btnRefresh.onclick = refresh;

// =======================================
// INIT
// =======================================

refresh();

setInterval(refresh, 5000);
// =======================================
// LIVE LOG
// =======================================

const liveLog = $("liveLog");
const logCount = $("logCount");
const btnClearLog = $("btnClearLog");

async function loadLogs() {

    try {

        const res = await fetch("/ws-api/logs");

        const logs = await res.json();

        liveLog.innerHTML = "";

        logs.forEach(log => {

            const div = document.createElement("div");

            let cls = "log-info";

            if (log.level === "WARN")
                cls = "log-warn";

            if (log.level === "ERROR")
                cls = "log-error";

            div.className = "log-item " + cls;

            div.innerHTML =
                "[" +
                new Date(log.time).toLocaleTimeString("id-ID") +
                "] <b>" +
                log.level +
                "</b> - " +
                log.message;

            liveLog.appendChild(div);

        });

        logCount.innerHTML = logs.length + " Log";

// Cek apakah user sedang berada di bawah
const autoScroll =
    liveLog.scrollTop + liveLog.clientHeight >=
    liveLog.scrollHeight - 20;

// Hanya scroll jika user memang berada di bawah
if (autoScroll) {
    liveLog.scrollTop = liveLog.scrollHeight;
}

    } catch (e) {

        console.error(e);

    }

}

if(btnClearLog){

    btnClearLog.onclick = async () => {

    try {

        await fetch("/ws-api/logs/clear");

        liveLog.innerHTML = "";

        logCount.innerHTML = "0 Log";

    } catch (e) {

        console.error(e);

    }

};

}

setInterval(loadLogs,1000);

loadLogs();
// =======================================
// LIVE CONNECTIONS
// =======================================

async function loadConnections() {

    try {

        const res = await fetch("/ws-api/connections");
        const json = await res.json();

        const list = document.getElementById("connectionList");
        const history = document.getElementById("historyList");

        if (!list || !history) return;

        // ==========================
        // ACTIVE CONNECTIONS
        // ==========================

        list.innerHTML = "";

        if (json.active.length === 0) {

            list.innerHTML = `
                <div class="empty">
                    Tidak ada koneksi.
                </div>
            `;

        } else {

            json.active.forEach(client => {

                const duration = Math.floor(
                    (Date.now() - client.connectedAt) / 1000
                );

                const h = String(Math.floor(duration / 3600)).padStart(2, "0");
                const m = String(Math.floor((duration % 3600) / 60)).padStart(2, "0");
                const s = String(duration % 60).padStart(2, "0");

                list.innerHTML += `

                    <div class="connection-card">

                        <div class="connection-title">
                            🟢 ONLINE
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">IP</span>
                            <span class="connection-value">${client.ip}</span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Method</span>
                            <span class="connection-value">${client.method}</span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">URL</span>
                            <span class="connection-value">${client.url}</span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Host</span>
                            <span class="connection-value">${client.host}</span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Real Host</span>
                            <span class="connection-value">${client.realHost}</span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Connected</span>
                            <span class="connection-value">
                                ${new Date(client.connectedAt).toLocaleString()}
                            </span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Duration</span>
                            <span class="connection-value">
                                ${h}:${m}:${s}
                            </span>
                        </div>

                    </div>

                `;

            });

        }

        // ==========================
        // HISTORY
        // ==========================

        history.innerHTML = "";

        if (json.history.length === 0) {

            history.innerHTML = `
                <div class="empty">
                    Belum ada riwayat.
                </div>
            `;

        } else {

            json.history.slice(0, 20).forEach(client => {

                history.innerHTML += `

                    <div class="connection-card">

                        <div class="connection-title">
                            🔴 OFFLINE
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">IP</span>
                            <span class="connection-value">${client.ip}</span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Duration</span>
                            <span class="connection-value">
                                ${formatDuration(client.duration)}
                            </span>
                        </div>

                        <div class="connection-row">
                            <span class="connection-label">Disconnected</span>
                            <span class="connection-value">
                                ${new Date(client.disconnectedAt).toLocaleString()}
                            </span>
                        </div>

                    </div>

                `;

            });

        }

    } catch (err) {

        console.error("Load Connections Error:", err);

    }

}

setInterval(loadConnections, 1000);

loadConnections();

setInterval(loadConnections,1000);

loadConnections();
