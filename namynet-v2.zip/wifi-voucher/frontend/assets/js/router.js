// ==========================================
// NAMYNET ROUTER MANAGER
// ==========================================

let routers = [];
let editId = null;

// ==========================================
// INIT
// ==========================================

document.addEventListener("DOMContentLoaded", () => {

    loadRouters();

    updateClock();

    setInterval(updateClock,1000);

    //setInterval(loadRouters,30000);

    document
        .getElementById("searchRouter")
        .addEventListener("keyup",searchRouter);

    document
        .getElementById("btnSaveRouter")
        .addEventListener("click",saveRouter);

});

// ==========================================
// CLOCK
// ==========================================

function updateClock(){

    const now = new Date();

    const hari = String(now.getDate()).padStart(2,"0");
    const bulan = String(now.getMonth()+1).padStart(2,"0");
    const tahun = now.getFullYear();

    const jam = String(now.getHours()).padStart(2,"0");
    const menit = String(now.getMinutes()).padStart(2,"0");
    const detik = String(now.getSeconds()).padStart(2,"0");

    const el = document.getElementById("clock");

    if(el){

        el.innerHTML =
            `${hari}/${bulan}/${tahun} ${jam}:${menit}:${detik}`;

    }

}

// ==========================================
// LOGOUT
// ==========================================

function logout(){

    localStorage.removeItem("token");

    location.href="login.html";

}

// ==========================================
// LOAD ROUTER
// ==========================================

async function loadRouters(){

    showLoading();

    const result = await apiRequest("/routers");

    hideLoading();

    if(!result || !result.success){

        return;

    }

    routers = result.data || [];

    renderRouters(routers);

}

// ==========================================
// RENDER TABLE
// ==========================================

function renderRouters(data){

    const tbody = document.getElementById("routerTable");

    tbody.innerHTML = "";

    let total = 0;
    let online = 0;
    let offline = 0;

    data.forEach(router=>{

        total++;

        if(router.online){

            online++;

        }else{

            offline++;

        }

        tbody.innerHTML += `

<tr>

<td>${router.name}</td>

<td>${router.identity || "-"}</td>

<td>${router.host}</td>

<td>${router.version || "-"}</td>

<td>${router.cpu || 0}%</td>

<td>${router.memory || 0}%</td>

<td>

<span class="badge ${router.online ? "online":"offline"}">

${router.online ? "Online":"Offline"}

</span>

</td>

<td>

<div class="action">

<button
class="btn-detail"
onclick="detailRouter(${router.id})">

<i class="fa-solid fa-circle-info"></i>

</button>

<button
class="btn-test"
onclick="testRouter(${router.id})">

<i class="fa-solid fa-plug"></i>

</button>

<button
class="btn-edit"
onclick="editRouter(${router.id})">

<i class="fa-solid fa-pen"></i>

</button>

<button
class="btn-delete"
onclick="deleteRouter(${router.id})">

<i class="fa-solid fa-trash"></i>

</button>

</div>

</td>

</tr>

`;

    });

    if(data.length===0){

        tbody.innerHTML=`

<tr>

<td colspan="8" style="text-align:center;padding:40px;">

Tidak ada Router

</td>

</tr>

`;

    }

    document.getElementById("totalRouter").innerText = total;

document.getElementById("routerOnline").innerText = online;

document.getElementById("routerOffline").innerText = offline;


// ===============================
// ROUTER HEALTH
// ===============================

let health = "Excellent";
let healthClass = "health-good";
let text = "Semua router sehat";

if (offline > 0) {

    health = "Critical";
    healthClass = "health-danger";
    text = "Ada router offline";

} else {

    const highLoad = data.some(router =>
        Number(router.cpu || 0) >= 70 ||
        Number(router.memory || 0) >= 80
    );

    if (highLoad) {

        health = "Warning";
        healthClass = "health-warning";
        text = "CPU / Memory tinggi";

    }

}

document.getElementById("routerHealth").innerHTML =
`<span class="${healthClass}">${health}</span>`;

document.getElementById("healthText").innerText = text;
}

// ==========================================
// SEARCH
// ==========================================

function searchRouter(){

    const keyword=this.value.toLowerCase();

    const filtered=routers.filter(router=>{

        return(

            router.name.toLowerCase().includes(keyword)

            ||

            router.host.toLowerCase().includes(keyword)

            ||

            (router.identity||"")
            .toLowerCase()
            .includes(keyword)

        );

    });

    renderRouters(filtered);

}

// ==========================================
// SHOW LOADING
// ==========================================

function showLoading(){

    const el=document.getElementById("loading");

    if(el){

        el.style.display="flex";

    }

}

// ==========================================
// HIDE LOADING
// ==========================================

function hideLoading(){

    const el=document.getElementById("loading");

    if(el){

        el.style.display="none";

    }

}
// ==========================================
// OPEN MODAL
// ==========================================

function openRouterModal(){

    editId = null;

    document.getElementById("modalTitle").innerText="Tambah Router";

    document.getElementById("routerName").value="";
    document.getElementById("routerHost").value="";
    document.getElementById("routerPort").value="8728";
    document.getElementById("routerUsername").value="";
    document.getElementById("routerPassword").value="";
    document.getElementById("routerActive").checked=true;

    document.getElementById("routerModal").style.display="flex";

}

// ==========================================
// CLOSE MODAL
// ==========================================

function closeRouterModal(){

    document.getElementById("routerModal").style.display="none";

}

// ==========================================
// SAVE ROUTER
// ==========================================

async function saveRouter(){

    const body={

        name:document.getElementById("routerName").value.trim(),

        host:document.getElementById("routerHost").value.trim(),

        port:Number(document.getElementById("routerPort").value),

        username:document.getElementById("routerUsername").value.trim(),

        password:document.getElementById("routerPassword").value,

        is_active:document.getElementById("routerActive").checked?1:0

    };

    if(body.name===""){

        Swal.fire("Error","Nama Router wajib diisi","warning");

        return;

    }

    if(body.host===""){

        Swal.fire("Error","Host wajib diisi","warning");

        return;

    }

    showLoading();

    let result;

    if(editId===null){

        result=await apiRequest("/routers",{

            method:"POST",

            body:JSON.stringify(body)

        });

    }else{

        result=await apiRequest("/routers/"+editId,{

            method:"PUT",

            body:JSON.stringify(body)

        });

    }

    hideLoading();

    if(!result.success){

        Swal.fire("Error",result.message,"error");

        return;

    }

    Swal.fire({

        icon:"success",

        title:"Berhasil",

        text:result.message,

        timer:1500,

        showConfirmButton:false

    });

    closeRouterModal();

    loadRouters();

}

// ==========================================
// EDIT ROUTER
// ==========================================

function editRouter(id){

    const router=routers.find(r=>r.id===id);

    if(!router){

        return;

    }

    editId=id;

    document.getElementById("modalTitle").innerText="Edit Router";

    document.getElementById("routerName").value=router.name;
    document.getElementById("routerHost").value=router.host;
    document.getElementById("routerPort").value=router.port;
    document.getElementById("routerUsername").value=router.username;
    document.getElementById("routerPassword").value="";
    document.getElementById("routerActive").checked=router.is_active==1;

    document.getElementById("routerModal").style.display="flex";

}

// ==========================================
// DELETE ROUTER
// ==========================================

async function deleteRouter(id){

    const ok=await Swal.fire({

        title:"Hapus Router?",

        text:"Router akan dihapus.",

        icon:"warning",

        showCancelButton:true,

        confirmButtonText:"Ya",

        cancelButtonText:"Batal"

    });

    if(!ok.isConfirmed){

        return;

    }

    showLoading();

    const result=await apiRequest("/routers/"+id,{

        method:"DELETE"

    });

    hideLoading();

    if(!result.success){

        Swal.fire("Error",result.message,"error");

        return;

    }

    Swal.fire({

        icon:"success",

        title:"Berhasil",

        text:result.message,

        timer:1500,

        showConfirmButton:false

    });

    loadRouters();

}
// ==========================================
// TEST ROUTER
// ==========================================

async function testRouter(id){

    showLoading();

    const result = await apiRequest("/routers/test/" + id,{
        method:"POST"
    });

    hideLoading();

    if(!result.success){

        Swal.fire({
            icon:"error",
            title:"Router Offline",
            text:result.message || "Tidak dapat terhubung"
        });

        return;
    }

    document.getElementById("detailModal").style.display="flex";

    document.getElementById("routerDetail").innerHTML=`

<div class="router-info">

<div class="router-status">

<i class="fa-solid fa-circle-check"></i>

<span>Router Online</span>

</div>

<div class="info-card">

<i class="fa-solid fa-server"></i>

<div>

<h4>Identity</h4>

<p>${result.identity}</p>

</div>

</div>

<div class="info-card">

<i class="fa-solid fa-code"></i>

<div>

<h4>Version</h4>

<p>${result.version}</p>

</div>

</div>

<div class="info-card">

<i class="fa-solid fa-microchip"></i>

<div>

<h4>Model</h4>

<p>${result.model}</p>

</div>

</div>

<div class="info-card">

<i class="fa-solid fa-gauge-high"></i>

<div>

<h4>CPU Load</h4>

<p>${result.cpu.load}%</p>

<div class="progress">

<div class="progress-bar"
style="width:${result.cpu.load}%"></div>

</div>

</div>

</div>

<div class="info-card">

<i class="fa-solid fa-memory"></i>

<div>

<h4>Memory</h4>

<p>${result.memory.usage}%</p>

<div class="progress">

<div class="progress-bar"
style="width:${result.memory.usage}%"></div>

</div>

</div>

</div>

<div class="info-card">

<i class="fa-solid fa-clock"></i>

<div>

<h4>Uptime</h4>

<p>${result.uptime}</p>

</div>

</div>

<div style="text-align:center;margin-top:35px;">

<button
class="btn-ok"
onclick="closeDetailModal()">

OK

</button>

</div>

</div>

`;

}

// ==========================================
// DETAIL ROUTER
// ==========================================

async function detailRouter(id){

    document.getElementById("detailModal").style.display="flex";

    document.getElementById("routerDetail").innerHTML=`

    <div class="loading">

        <i class="fa-solid fa-spinner fa-spin"></i>

        Memuat Detail...

    </div>

    `;

    const result = await apiRequest("/routers/" + id);

    if(!result.success){

        document.getElementById("routerDetail").innerHTML=

        "<p>Gagal memuat data.</p>";

        return;

    }

    const r = result.data;

    document.getElementById("routerDetail").innerHTML=`

<div class="detail-grid">

<div class="detail-item">

<h4>Identity</h4>

<p>${r.identity}</p>

</div>

<div class="detail-item">

<h4>Version</h4>

<p>${r.version}</p>

</div>

<div class="detail-item">

<h4>Model</h4>

<p>${r.model}</p>

</div>

<div class="detail-item">

<h4>Board</h4>

<p>${r.board}</p>

</div>

<div class="detail-item">

<h4>Architecture</h4>

<p>${r.architecture}</p>

</div>

<div class="detail-item">

<h4>Platform</h4>

<p>${r.platform}</p>

</div>

<div class="detail-item">

<h4>CPU</h4>

<p>${r.cpu.name}</p>

<div class="progress">

<div
class="progress-bar"
style="width:${r.cpu.load}%">

</div>

</div>

</div>

<div class="detail-item">

<h4>Memory</h4>

<p>${r.memory.usage}%</p>

<div class="progress">

<div
class="progress-bar"
style="width:${r.memory.usage}%">

</div>

</div>

</div>

<div class="detail-item">

<h4>Storage</h4>

<p>

${Math.round(r.storage.free/1024/1024)}

MB Free

</p>

</div>

<div class="detail-item">

<h4>Firmware</h4>

<p>

${r.firmware.current}

</p>

</div>

<div class="detail-item">

<h4>Serial Number</h4>

<p>

${r.serial}

</p>

</div>

<div class="detail-item">

<h4>Uptime</h4>

<p>

${r.uptime}

</p>

</div>

</div>

`;

}

// ==========================================
// CLOSE DETAIL
// ==========================================

function closeDetailModal(){

    document.getElementById("detailModal").style.display="none";

}

// ==========================================
// CLOSE MODAL CLICK OUTSIDE
// ==========================================

window.onclick=function(event){

    if(event.target===document.getElementById("routerModal")){

        closeRouterModal();

    }

    if(event.target===document.getElementById("detailModal")){

        closeDetailModal();

    }

};

// ==========================================
// ESC KEY
// ==========================================

document.addEventListener("keydown",e=>{

    if(e.key==="Escape"){

        closeRouterModal();

        closeDetailModal();

    }

});
// ==========================================
// TOGGLE PASSWORD
// ==========================================

function togglePassword() {

    const input = document.getElementById("routerPassword");
    const icon = document.getElementById("passwordIcon");

    if (!input || !icon) return;

    if (input.type === "password") {

        input.type = "text";

        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");

    } else {

        input.type = "password";

        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");

    }

}
// ==========================================
// END
// ==========================================
