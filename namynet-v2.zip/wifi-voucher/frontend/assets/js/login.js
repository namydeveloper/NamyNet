if (localStorage.getItem("token")) {
    location.href = "dashboard.html";
}

async function login() {

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const error = document.getElementById("error");

    error.innerHTML = "";

    if (!username || !password) {
        error.innerHTML = "Username dan Password wajib diisi";
        return;
    }

    try {

        const result = await apiRequest("/login", {
            method: "POST",
            body: JSON.stringify({
                username,
                password
            })
        });

        if (!result || !result.success) {
            error.innerHTML = result?.message || "Login gagal";
            return;
        }

        localStorage.setItem("token", result.token);
        localStorage.setItem("username", result.user.username);
        localStorage.setItem("name", result.user.name);

        location.href = "dashboard.html";

    } catch (err) {

        error.innerHTML = "Tidak dapat terhubung ke server.";

    }

}

document.addEventListener("keydown", function(e){

    if(e.key === "Enter"){
        login();
    }

});
