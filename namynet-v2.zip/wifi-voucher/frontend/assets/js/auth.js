function isLoggedIn() {

    return !!localStorage.getItem("token");

}

function requireLogin() {

    if (!isLoggedIn()) {

        location.href = "login.html";

    }

}

function logout() {

    localStorage.clear();

    location.href = "login.html";

}
