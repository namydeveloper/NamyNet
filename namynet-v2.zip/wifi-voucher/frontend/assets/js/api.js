const API_BASE = "/api";

async function apiRequest(path, options = {}) {

    const token = localStorage.getItem("token");

    const headers = {
        "Content-Type": "application/json",
        ...(options.headers || {})
    };

    if (token) {
        headers.Authorization = "Bearer " + token;
    }

    const response = await fetch(API_BASE + path, {
        ...options,
        headers
    });

    let data = {};

    try {
        data = await response.json();
    } catch (_) {}

    if (response.status === 401) {
        localStorage.clear();
        location.href = "login.html";
        return;
    }

    return data;
}
