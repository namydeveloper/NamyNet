// =======================================
// NAMYNET SETTINGS V2
// =======================================

const el = (id) => document.getElementById(id);

// =======================================
// SIDEBAR
// =======================================

function initSidebar() {

    const sidebar = el("sidebar");
    const overlay = el("overlay");
    const menuToggle = el("menuToggle");

    if (menuToggle) {

        menuToggle.addEventListener("click", () => {

            sidebar.classList.toggle("open");
            overlay.classList.toggle("show");

        });

    }

    if (overlay) {

        overlay.addEventListener("click", () => {

            sidebar.classList.remove("open");
            overlay.classList.remove("show");

        });

    }

}

// =======================================
// DIGITAL CLOCK
// =======================================

function updateClock() {

    const clock = el("clock");

    if (!clock) return;

    const now = new Date();

    const hari = String(now.getDate()).padStart(2, "0");
    const bulan = String(now.getMonth() + 1).padStart(2, "0");
    const tahun = now.getFullYear();

    const jam = String(now.getHours()).padStart(2, "0");
    const menit = String(now.getMinutes()).padStart(2, "0");
    const detik = String(now.getSeconds()).padStart(2, "0");

    clock.innerHTML =
        `${hari}/${bulan}/${tahun} | ${jam}:${menit}:${detik}`;

}

// =======================================
// LOGIN
// =======================================

function initAdmin() {

    const token = localStorage.getItem("token");

    if (!token) {

        location.href = "login.html";
        return;

    }

    const admin = el("adminName");

    if (admin) {

        admin.innerHTML =
            localStorage.getItem("username") || "Admin";

    }

}

// =======================================
// LOGOUT
// =======================================

function logout() {

    Swal.fire({

        title: "Logout ?",

        text: "Yakin ingin keluar dari NamyNet?",

        icon: "question",

        showCancelButton: true,

        confirmButtonText: "Logout",

        cancelButtonText: "Batal"

    }).then(result => {

        if (!result.isConfirmed) return;

        localStorage.clear();

        location.href = "login.html";

    });

}

// =======================================
// LOADING SETTINGS
// =======================================

async function loadSettings() {

    try {

        const res = await apiRequest("/settings");

        if (!res.success) {

            throw new Error(res.message);

        }

        const data = res.data;

        // SERVER

        el("hostname").value = data.hostname || "";
        el("serverIp").value = data.serverIp || "";
        el("nodeVersion").value = data.nodeVersion || "";
        el("pm2Status").value = data.pm2Status || "";
        el("uptime").value = data.uptime || "";

        // ROUTER

        el("routerName").value = data.routerName || "";
        el("routerIp").value = data.routerIp || "";
        el("routerUser").value = data.routerUser || "";
        el("routerPass").value = "";
        el("routerPort").value = data.routerPort || 8728;

        // DOMAIN HOTSPOT

        el("domain").value =
        data.domain || "";

        el("loginUrl").value =
        data.loginUrl || "";

        el("redirectUrl").value =
        data.redirectUrl || "";

        el("httpsEnable").checked =
        data.httpsEnable == 1;

        // APP

        el("appName").value =
            data.appName || "NamyNet";

        el("companyName").value =
            data.companyName || "";

        el("timezone").value =
            data.timezone || "Asia/Jakarta";

    }

    catch (err) {

        console.error(err);

        Swal.fire({

            icon: "error",

            title: "Settings",

            text: err.message

        });

    }

}
// =======================================
// TEST KONEKSI MIKROTIK
// =======================================

async function testConnection() {

    try {

        const result = await apiRequest("/settings/test-router", {

            method: "POST",

            body: JSON.stringify({

                ip: el("routerIp").value,

                username: el("routerUser").value,

                password: el("routerPass").value,

                port: Number(el("routerPort").value)

            })

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Test Connection",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Router",

            text: err.message

        });

    }

}

// =======================================
// SIMPAN ROUTER
// =======================================

async function saveRouter() {

    try {

        const result = await apiRequest("/settings/router", {

            method: "POST",

            body: JSON.stringify({

                routerName: el("routerName").value,

                routerIp: el("routerIp").value,

                routerUser: el("routerUser").value,

                routerPass: el("routerPass").value,

                routerPort: Number(el("routerPort").value)

            })

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Router",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Router",

            text: err.message

        });

    }

}

// DOMAIN HOTSPOT

async function saveDomainSettings() {

    try {

        const result = await apiRequest("/settings/domain", {

            method: "POST",

            body: JSON.stringify({

                domain: el("domain").value,

                loginUrl: el("loginUrl").value,

                redirectUrl: el("redirectUrl").value,

                httpsEnable: el("httpsEnable").checked

            })

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Domain Hotspot",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Domain",

            text: err.message

        });

    }

}

// =======================================
// SIMPAN APLIKASI
// =======================================

async function saveApplication() {

    try {

        const result = await apiRequest("/settings/application", {

            method: "POST",

            body: JSON.stringify({

                appName: el("appName").value,

                companyName: el("companyName").value,

                timezone: el("timezone").value

            })

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Aplikasi",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Aplikasi",

            text: err.message

        });

    }

}

// =======================================
// EVENT BUTTON
// =======================================

function initButtons() {

    if (el("btnTest")) {

        el("btnTest").addEventListener("click", testConnection);

    }

    if (el("btnSaveRouter")) {

        el("btnSaveRouter").addEventListener("click", saveRouter);

    }

    if (el("btnSaveApp")) {

        el("btnSaveApp").addEventListener("click", saveApplication);

    }

}
// =======================================
// SYNC MIKROTIK
// =======================================

async function syncRouter() {

    try {

        const result = await apiRequest("/settings/sync", {

            method: "POST"

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Sinkronisasi",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Sync",

            text: err.message

        });

    }

}

// =======================================
// BACKUP DATABASE
// =======================================

async function backupDatabase() {

    try {

        const result = await apiRequest("/settings/backup", {

            method: "POST"

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Backup",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Backup",

            text: err.message

        });

    }

}

// =======================================
// CLEAR LOG
// =======================================

async function clearLog() {

    const confirm = await Swal.fire({

        title: "Hapus Log?",

        text: "Semua log aktivitas akan dihapus.",

        icon: "warning",

        showCancelButton: true,

        confirmButtonText: "Ya",

        cancelButtonText: "Batal"

    });

    if (!confirm.isConfirmed) return;

    try {

        const result = await apiRequest("/settings/clear-log", {

            method: "DELETE"

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Log",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Log",

            text: err.message

        });

    }

}

// =======================================
// RESTART BACKEND
// =======================================

async function restartBackend() {

    const confirm = await Swal.fire({

        title: "Restart Backend?",

        text: "Service NamyNet akan direstart.",

        icon: "question",

        showCancelButton: true,

        confirmButtonText: "Restart",

        cancelButtonText: "Batal"

    });

    if (!confirm.isConfirmed) return;

    try {

        const result = await apiRequest("/settings/restart", {

            method: "POST"

        });

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: "Restart",

            text: result.message

        });

    }

    catch (err) {

        Swal.fire({

            icon: "error",

            title: "Restart",

            text: err.message

        });

    }

}

// =======================================
// MAINTENANCE BUTTON
// =======================================

function initMaintenance() {

    if (el("btnSync")) {

        el("btnSync").addEventListener("click", syncRouter);

    }

    if (el("btnBackup")) {

        el("btnBackup").addEventListener("click", backupDatabase);

    }

    if (el("btnClearLog")) {

        el("btnClearLog").addEventListener("click", clearLog);

    }

    if (el("btnRestart")) {

        el("btnRestart").addEventListener("click", restartBackend);

    }

}

// =======================================
// START
// =======================================

document.addEventListener("DOMContentLoaded", async () => {

    initAdmin();

    initSidebar();

    initButtons();

    initMaintenance();

    updateClock();

    setInterval(updateClock, 1000);

    await loadSettings();

});

console.log("NamyNet Settings V2 Loaded");
