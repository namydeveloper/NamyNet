// =======================================
// NAMYNET STATISTICS V2
// =======================================

let salesChart = null;

// ===============================
// FORMAT RUPIAH
// ===============================

function rupiah(number) {

    return "Rp " + Number(number || 0).toLocaleString("id-ID");

}

// ===============================
// ELEMENT
// ===============================

const el = (id) => document.getElementById(id);

// ===============================
// LOADING
// ===============================

function showLoading() {

    const loading = el("loading");

    if (loading) {

        loading.style.display = "flex";

    }

}

function hideLoading() {

    const loading = el("loading");

    if (loading) {

        loading.style.display = "none";

    }

}

// ===============================
// LAST UPDATE
// ===============================

function updateLastUpdate() {

    const last = el("lastUpdate");

    if (!last) return;

    last.innerHTML = new Date().toLocaleString("id-ID");

}

// ===============================
// LOAD STATISTICS
// ===============================

async function loadStatistics() {

    try {

        showLoading();

        const result = await apiRequest("/statistics");

        if (!result || !result.success) {

            throw new Error(result?.message || "Gagal mengambil statistik");

        }

        const summary = result.data.summary;
        const income = result.data.income;
        const voucher = result.data.voucher;

        // ===========================
        // SUMMARY
        // ===========================

        el("routers").textContent = summary.routers;
        el("routerOnline").textContent = summary.routerOnline;
        el("onlineUsers").textContent = summary.onlineUsers;

        el("packages").textContent = summary.packages;

        el("vouchers").textContent = summary.vouchers;
        el("used").textContent = summary.used;
        el("unused").textContent = summary.unused;
        el("expired").textContent = summary.expired;

        // ===========================
        // INCOME
        // ===========================

        el("incomeToday").textContent = rupiah(income.today);
        el("incomeWeek").textContent = rupiah(income.week);
        el("incomeMonth").textContent = rupiah(income.month);
        el("incomeYear").textContent = rupiah(income.year);

        // ===========================
        // VOUCHER
        // ===========================

        el("voucherToday").textContent = voucher.today;
        el("voucherWeek").textContent = voucher.week;
        el("voucherMonth").textContent = voucher.month;

        updateLastUpdate();

    } catch (err) {

        console.error(err);

        Swal.fire({

            icon: "error",

            title: "Statistics",

            text: err.message

        });

    } finally {

        hideLoading();

    }

}
// ===============================
// LOAD SALES CHART
// ===============================

async function loadSalesChart() {

    try {

        const result = await apiRequest("/chart/sales");

        if (!result || !result.success) {

            throw new Error(result?.message || "Gagal memuat grafik.");

        }

        const canvas = el("salesChart");

        if (!canvas) return;

        const ctx = canvas.getContext("2d");

        // Hapus chart lama
        if (salesChart) {

            salesChart.destroy();

            salesChart = null;

        }

        salesChart = new Chart(ctx, {

            type: "bar",

            data: {

                labels: result.labels,

                datasets: [

                    {

                        label: "Voucher Terjual",

                        data: result.values,

                        borderWidth: 2,

                        borderRadius: 8,

                        maxBarThickness: 45

                    }

                ]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                animation: {

                    duration: 700

                },

                plugins: {

                    legend: {

                        display: false

                    },

                    tooltip: {

                        callbacks: {

                            label(context) {

                                return " " + context.raw + " Voucher";

                            }

                        }

                    }

                },

                scales: {

                    y: {

                        beginAtZero: true,

                        ticks: {

                            precision: 0,

                            stepSize: 1

                        },

                        grid: {

                            display: true

                        }

                    },

                    x: {

                        grid: {

                            display: false

                        }

                    }

                }

            }

        });

    }

    catch (err) {

        console.error("Chart Error :", err);

    }

}

// ===============================
// REFRESH
// ===============================

async function refreshStatistics() {

    await loadStatistics();

    await loadSalesChart();

}
// ===============================
// SIDEBAR
// ===============================

function initSidebar() {

    const sidebar = el("sidebar");
    const overlay = el("overlay");
    const menuToggle = el("menuToggle");

    if (menuToggle) {

        menuToggle.addEventListener("click", () => {

            sidebar.classList.toggle("open");
            overlay.classList.toggle("show");

        });

    }

    if (overlay) {

        overlay.addEventListener("click", () => {

            sidebar.classList.remove("open");
            overlay.classList.remove("show");

        });

    }

}

// ===============================
// DIGITAL CLOCK
// ===============================

function updateClock() {

    const clock = el("clock");

    if (!clock) return;

    const now = new Date();

    const hari = String(now.getDate()).padStart(2, "0");
    const bulan = String(now.getMonth() + 1).padStart(2, "0");
    const tahun = now.getFullYear();

    const jam = String(now.getHours()).padStart(2, "0");
    const menit = String(now.getMinutes()).padStart(2, "0");
    const detik = String(now.getSeconds()).padStart(2, "0");

    clock.innerHTML =
        `${hari}/${bulan}/${tahun} | ${jam}:${menit}:${detik}`;

}

// ===============================
// ADMIN
// ===============================

function initAdmin() {

    if (!localStorage.getItem("token")) {

        location.href = "login.html";
        return;

    }

    const admin = el("adminName");

    if (admin) {

        admin.innerHTML =
            localStorage.getItem("username") || "Admin";

    }

}

// ===============================
// LOGOUT
// ===============================

function logout() {

    Swal.fire({

        title: "Logout ?",

        text: "Yakin ingin keluar dari NamyNet?",

        icon: "question",

        showCancelButton: true,

        confirmButtonText: "Logout",

        cancelButtonText: "Batal"

    }).then(result => {

        if (!result.isConfirmed) return;

        localStorage.clear();

        location.href = "login.html";

    });

}

// ===============================
// START
// ===============================

document.addEventListener("DOMContentLoaded", async () => {

    initAdmin();

    initSidebar();

    updateClock();

    setInterval(updateClock, 1000);

    await refreshStatistics();

    // Refresh statistik setiap 15 detik

    setInterval(async () => {

        await refreshStatistics();

    }, 15000);

});

console.log("NamyNet Statistics V2 Loaded");
