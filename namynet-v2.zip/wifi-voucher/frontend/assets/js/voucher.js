// =================================
// NAMYNET VOUCHER MANAGER JWT
// =================================


// Cek Token

if(!localStorage.getItem("token")){

    location.href="login.html";

}


// Nama Admin

document.getElementById("adminName").innerHTML =
localStorage.getItem("username") || "Admin";



// Logout

function logout(){

    if(confirm("Yakin ingin logout?")){

        localStorage.removeItem("token");
        localStorage.removeItem("username");
        localStorage.removeItem("name");

        location.href="login.html";

    }

}


// Delete
async function deleteVoucher(id){

    if(!confirm("Hapus voucher ini?")) return;

    const result = await apiRequest("/vouchers/"+id,{
        method:"DELETE"
    });

    if(result.success){

        loadVoucher();

    }else{

        alert(result.message || "Gagal menghapus voucher");

    }

}
// ===============================
// JAM DIGITAL
// ===============================

function updateClock() {

    const now = new Date();

    const hari = now.getDate();
    const bulan = now.getMonth() + 1;
    const tahun = now.getFullYear();

    const jam = String(now.getHours()).padStart(2, "0");
    const menit = String(now.getMinutes()).padStart(2, "0");
    const detik = String(now.getSeconds()).padStart(2, "0");

    document.getElementById("clock").innerHTML =
        `${hari}/${bulan}/${tahun} | ${jam}:${menit}:${detik}`;

}

updateClock();
setInterval(updateClock, 1000);

async function loadRouters(){

    const res = await apiRequest("/routers");

    const select = document.getElementById("routerSelect");

    select.innerHTML = "";

    if(!res.success) return;

    res.data.forEach(r=>{

        select.innerHTML += `
            <option value="${r.id}">
                ${r.name}
            </option>
        `;

    });

}

async function loadPackages(){

    const res=await apiRequest("/packages");

    const select=document.getElementById("packageSelect");

    select.innerHTML="";

    res.data.forEach(p=>{

        select.innerHTML+=`
        <option value="${p.id}">
            ${p.name}
        </option>
        `;

    });

}

// Load Voucher

async function loadVoucher(){


    try{


        const result = await apiRequest("/vouchers");


        if(!result || !result.success){

            alert("Gagal mengambil data voucher");

            return;

        }



        const table =
        document.getElementById("voucherTable");


        table.innerHTML="";



        let total=0;
        let ready=0;
        let used=0;
        let expired = 0;


        result.data.forEach(v=>{


            total++;


            if(v.status==="unused"){

                ready++;

            }


            if(v.status==="used"){

                used++;

            }
             if (v.status === "expired") {
              expired++;
            }


            const statusBadge = {

    unused: '<span class="badge ready"><i class="fa-solid fa-circle-check"></i> Belum Digunakan</span>',

    used: '<span class="badge countdown" data-expired="'+(v.expired_at || '')+'">⏳ Menghitung...</span>',

    expired: '<span class="badge expired"><i class="fa-solid fa-circle-xmark"></i> Expired</span>'

};

table.innerHTML += `

<tr>

<td>

<div class="voucher-code">

<i class="fa-solid fa-ticket"></i>

<span>${v.code}</span>

</div>

</td>

<td>

${v.package_name || "-"}

</td>

<td>

${statusBadge[v.status] || "-"}

</td>

<td class="action">

<button
class="print"
title="PDF Voucher"
onclick="printVoucher(${v.id})">

<i class="fa-solid fa-file-pdf"></i>

</button>

<button
class="delete"
title="Hapus Voucher"
onclick="deleteVoucher(${v.id})">

<i class="fa-solid fa-trash"></i>

</button>

</td>

</tr>

`;


        });



        document.getElementById("totalVoucher").innerHTML=total;

        document.getElementById("activeVoucher").innerHTML=ready;

        document.getElementById("usedVoucher").innerHTML=used;
        
        document.getElementById("expiredVoucher").innerHTML = expired;


    }
    catch(err){

        console.log(err);

    }


}





// Search

document
.getElementById("searchVoucher")
.addEventListener("keyup",function(){


    let filter=this.value.toUpperCase();


    document
    .querySelectorAll("#voucherTable tr")
    .forEach(row=>{


        row.style.display =
        row.innerText.toUpperCase()
        .includes(filter)
        ?
        ""
        :
        "none";


    });



});






async function printVoucher(id){

    try{

        const result = await apiRequest("/vouchers/" + id + "/pdf");

        if(result.success){

            window.open(result.pdf.url, "_blank");

        }else{

            alert(result.message || "Gagal membuat PDF");

        }

    }catch(err){

        console.error(err);

        alert("Terjadi kesalahan.");

    }

}


// Load Router & Package saat halaman dibuka
loadRouters();
loadPackages();

document.getElementById("saveGenerate").onclick = async () => {

    const body = {

        router_id: document.getElementById("routerSelect").value,
        package_id: document.getElementById("packageSelect").value,
        qty: parseInt(document.getElementById("qty").value),
        prefix: document.getElementById("prefix").value

    };

    const result = await apiRequest("/vouchers/generate", {

        method: "POST",
        body: JSON.stringify(body)

    });

    if(result.success){

        await loadVoucher();

        if(result.pdf){

            if(confirm("Voucher berhasil dibuat.\n\nBuka PDF sekarang?")){

                window.open(result.pdf.url, "_blank");

            }

        }else{

            alert("Voucher berhasil dibuat.");

        }

    }else{

        alert(result.message || "Generate gagal.");

    }

};



// ===================================
// COUNTDOWN STATUS
// ===================================

function updateCountdown() {

    document.querySelectorAll(".countdown").forEach(el => {

        const expired = el.dataset.expired;

        if (!expired) return;

        const end = new Date(expired).getTime();
        const now = new Date().getTime();

        let diff = end - now;

        if (diff <= 0) {

            el.className = "badge expired";
            el.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Expired';

            return;
        }

        const days = Math.floor(diff / 86400000);
        diff %= 86400000;

        const hours = Math.floor(diff / 3600000);
        diff %= 3600000;

        const minutes = Math.floor(diff / 60000);
        diff %= 60000;

        const seconds = Math.floor(diff / 1000);

        let text = "";

        if (days > 0) {

            text += days + " Hari ";

        }

        text +=
            String(hours).padStart(2, "0") + ":" +
            String(minutes).padStart(2, "0") + ":" +
            String(seconds).padStart(2, "0");

        el.innerHTML =
            '<i class="fa-solid fa-hourglass-half"></i> ' + text;

    });

}

loadVoucher().then(() => {

    updateCountdown();

    setInterval(updateCountdown, 1000);

});

