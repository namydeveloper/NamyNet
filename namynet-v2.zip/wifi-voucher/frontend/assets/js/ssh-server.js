// ======================================
// NAMYNET SSH SERVER
// ======================================

// ===============================
// AUTH
// ===============================

if (!localStorage.getItem("token")) {

    location.href = "index.html";

}

// ===============================
// API
// ===============================

const API = "/api/ssh/servers";

let serverList = [];

// ===============================
// INIT
// ===============================

document.addEventListener("DOMContentLoaded", () => {

    loadServers();

    startClock();

    const search = document.getElementById("searchServer");

if (search) {

    search.value = "";

    search.setAttribute("autocomplete", "off");

    search.setAttribute(
        "name",
        "server_search_" + Date.now()
    );

    search.addEventListener("keyup", searchServer);

}

    const refresh = document.getElementById("btnRefresh");

    if (refresh) {

        refresh.addEventListener("click", loadServers);

    }

});

// ===============================
// LOAD SERVER
// ===============================

async function loadServers() {

    try {

        showLoading(true);

        const res = await fetch(API, {

            headers: {

                Authorization: "Bearer " + localStorage.getItem("token")

            }

        });

        const data = await res.json();

        serverList = Array.isArray(data)
            ? data
            : (data.data || []);

        renderTable(serverList);

        updateStatistic(serverList);

    } catch (err) {

        console.error(err);

        Swal.fire(

            "Error",

            "Gagal memuat SSH Server",

            "error"

        );

    } finally {

        showLoading(false);

    }

}

// ===============================
// TABLE
// ===============================

function renderTable(list) {

    const tbody = document.getElementById("serverTable");

    if (!list.length) {

        tbody.innerHTML = `

        <tr>

            <td colspan="6" class="empty">

                <i class="fa-solid fa-server"></i>

                <br>

                Belum ada SSH Server

            </td>

        </tr>

        `;

        return;

    }

    tbody.innerHTML = "";

    list.forEach(server => {

        tbody.innerHTML += `

        <tr>

            <td>${server.server_name}</td>

            <td class="host-text">${server.host}</td>

            <td class="port">${server.ssh_port}</td>

            <td class="username">${server.username}</td>

            <td>

                <span class="status ${server.status}">

                    ${server.status === "online"

                        ? "🟢 Online"

                        : "🔴 Offline"}

                </span>

            </td>

            <td>

                <div class="action-group">

                    <button
                        class="btn-info"
                        onclick="showInfo(${server.id})">

                        <i class="fa-solid fa-circle-info"></i>

                    </button>

                    <button
                        class="btn-test"
                        onclick="testServer(${server.id})">

                        <i class="fa-solid fa-plug"></i>

                    </button>

                    <button
                        class="btn-edit"
                        onclick="editServer(${server.id})">

                        <i class="fa-solid fa-pen"></i>

                    </button>

                    <button
                        class="btn-delete"
                        onclick="deleteServer(${server.id})">

                        <i class="fa-solid fa-trash"></i>

                    </button>

                </div>

            </td>

        </tr>

        `;

    });

}

// ===============================
// SEARCH
// ===============================

function searchServer() {

    const keyword = document
        .getElementById("searchServer")
        .value
        .toLowerCase();

    const result = serverList.filter(server =>

        server.server_name.toLowerCase().includes(keyword) ||

        server.host.toLowerCase().includes(keyword) ||

        server.username.toLowerCase().includes(keyword)

    );

    renderTable(result);

}

// ===============================
// STATISTIC
// ===============================

function updateStatistic(list) {

    document.getElementById("totalServer").innerText = list.length;

    document.getElementById("serverOnline").innerText =

        list.filter(x => x.status === "online").length;

    document.getElementById("serverOffline").innerText =

        list.filter(x => x.status !== "online").length;

    document.getElementById("totalAccount").innerText = "-";

}

// ===============================
// LOADING
// ===============================

function showLoading(show) {

    document.getElementById("loading").style.display =

        show ? "flex" : "none";

}

// ===============================
// CLOCK
// ===============================

function startClock() {

    setInterval(() => {

        document.getElementById("clock").innerHTML =

            new Date().toLocaleString("id-ID");

    }, 1000);

}

// ===============================
// ACTION (NEXT PART)
// ===============================

// ===============================
// SERVER INFO
// ===============================

async function showInfo(id) {

    try {

        showLoading(true);

        const res = await fetch(

            API + "/" + id + "/system",

            {

                headers: {

                    Authorization:
                        "Bearer " +
                        localStorage.getItem("token")

                }

            }

        );

        const data = await res.json();

        if (!res.ok || !data.success) {

            throw new Error(

                data.message || "Gagal mengambil informasi server"

            );

        }

        const info = data.data || data;

        Swal.fire({

            title: "Informasi VPS",

            width: 650,

            html: `

<div style="text-align:left;line-height:1.9">

<b>🖥 Hostname</b><br>
${info.hostname || "-"}

<hr>

<b>🌍 Operating System</b><br>
${info.os || "-"}

<hr>

<b>⚙ Kernel</b><br>
${info.kernel || "-"}

<hr>

<b>🔥 CPU</b><br>
${info.cpu || "-"}

<hr>

<b>💾 RAM</b><br>
${info.ram || "-"}

<hr>

<b>📦 Disk</b><br>
${info.disk || "-"}

<hr>

<b>⏱ Uptime</b><br>
${info.uptime || "-"}

</div>

            `,

            confirmButtonText: "Tutup"

        });

    }

    catch(err){

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally{

        showLoading(false);

    }

}

// ===============================
// TEST CONNECTION
// ===============================

async function testServer(id) {

    try {

        showLoading(true);

        const res = await fetch(

            API + "/" + id + "/test",

            {

                headers: {

                    Authorization:

                        "Bearer " +

                        localStorage.getItem("token")

                }

            }

        );

        const result = await res.json();

        if (!res.ok) {

            throw new Error(

                result.message || "Test gagal"

            );

        }

        Swal.fire({

            icon: result.success ? "success" : "error",

            title: result.success

                ? "SSH Connected"

                : "SSH Failed",

            text: result.message ||

                  (result.success

                    ? "Koneksi SSH berhasil"

                    : "Koneksi SSH gagal")

        });

        loadServers();

    }

    catch(err){

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally{

        showLoading(false);

    }

}

// ===============================
// EDIT SERVER
// ===============================

async function editServer(id) {

    try {

        showLoading(true);

        const res = await fetch(

            API + "/" + id,

            {

                headers: {

                    Authorization:

                        "Bearer " +

                        localStorage.getItem("token")

                }

            }

        );

        const result = await res.json();

        if (!res.ok || !result.success) {

            throw new Error(

                result.message || "Gagal mengambil data"

            );

        }

        const server = result.data;

        editId = server.id;

        document.getElementById("modalTitle").innerText =
            "Edit SSH Server";

        document.getElementById("serverName").value =
            server.server_name;

        document.getElementById("serverHost").value =
            server.host;

        document.getElementById("sshPort").value =
            server.ssh_port;

        document.getElementById("dropbearPort").value =
            server.dropbear_port;

        document.getElementById("sslPort").value =
            server.ssl_port;

        document.getElementById("serverUsername").value =
            server.username;

        document.getElementById("serverPassword").value =
            server.password;

        document.getElementById("serverStatus").checked =
            server.status === "online";

        document.getElementById("serverModal").style.display =
            "flex";

    }

    catch(err){

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally{

        showLoading(false);

    }

}

// ===============================
// DELETE SERVER
// ===============================

async function deleteServer(id) {

    const result = await Swal.fire({

        title: "Hapus Server?",

        text: "Server SSH akan dihapus permanen.",

        icon: "warning",

        showCancelButton: true,

        confirmButtonText: "Ya, Hapus",

        cancelButtonText: "Batal",

        confirmButtonColor: "#ef4444"

    });

    if (!result.isConfirmed) return;

    try {

        showLoading(true);

        const res = await fetch(

            API + "/" + id,

            {

                method: "DELETE",

                headers: {

                    Authorization:
                        "Bearer " +
                        localStorage.getItem("token")

                }

            }

        );

        const data = await res.json();

        if (!res.ok) {

            throw new Error(

                data.message || "Gagal menghapus"

            );

        }

        Swal.fire(

            "Berhasil",

            "Server berhasil dihapus",

            "success"

        );

        loadServers();

    }

    catch (err) {

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        showLoading(false);

    }

}
// ===============================
// MODAL
// ===============================

let editId = null;

function openServerModal() {

    editId = null;

    document.getElementById("modalTitle").innerText =
        "Tambah SSH Server";

    document.getElementById("serverName").value = "";

    document.getElementById("serverHost").value = "";

    document.getElementById("sshPort").value = 22;

    document.getElementById("dropbearPort").value = 80;

    document.getElementById("sslPort").value = 443;

    document.getElementById("serverUsername").value = "";

    document.getElementById("serverPassword").value = "";

    document.getElementById("serverStatus").checked = true;

    document.getElementById("serverModal").style.display =
        "flex";

}

function closeServerModal() {

    document.getElementById("serverModal").style.display = "none";

}
// ===============================
// SAVE SERVER
// ===============================

document.getElementById("btnSaveServer").addEventListener("click", saveServer);

async function saveServer() {

    const body = {

        server_name: document.getElementById("serverName").value.trim(),

        host: document.getElementById("serverHost").value.trim(),

        ssh_port: Number(document.getElementById("sshPort").value),

        dropbear_port: Number(document.getElementById("dropbearPort").value),

        ssl_port: Number(document.getElementById("sslPort").value),

        username: document.getElementById("serverUsername").value.trim(),

        password: document.getElementById("serverPassword").value,

        status: document.getElementById("serverStatus").checked
            ? "online"
            : "offline"

    };

    if (!body.server_name ||
        !body.host ||
        !body.username ||
        !body.password) {

        Swal.fire(
            "Peringatan",
            "Semua field wajib diisi.",
            "warning"
        );

        return;

    }

    try {

        showLoading(true);

        const url = editId
            ? API + "/" + editId
            : API;

        const method = editId
            ? "PUT"
            : "POST";

        const res = await fetch(url, {

            method,

            headers: {

                "Content-Type": "application/json",

                Authorization:
                    "Bearer " +
                    localStorage.getItem("token")

            },

            body: JSON.stringify(body)

        });

        const result = await res.json();

        if (!res.ok) {

            throw new Error(

                result.message || "Gagal"

            );

        }

        Swal.fire(

            "Berhasil",

            editId
                ? "Server berhasil diperbarui"
                : "Server berhasil ditambahkan",

            "success"

        );

        closeServerModal();

        loadServers();

    }

    catch (err) {

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        showLoading(false);

    }

}
