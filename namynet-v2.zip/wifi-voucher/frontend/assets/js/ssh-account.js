// ======================================
// NAMYNET SSH ACCOUNT MANAGER
// Part 2A
// ======================================

// ===============================
// AUTH
// ===============================

if (!localStorage.getItem("token")) {

    location.href = "index.html";

}

// ===============================
// API
// ===============================

const API = window.API_BASE || "/api";

const TOKEN = localStorage.getItem("token");

// ===============================
// ELEMENT
// ===============================

const tableBody = document.getElementById("sshTable");

const totalAccount = document.getElementById("totalAccount");
const totalActive = document.getElementById("totalActive");
const totalExpired = document.getElementById("totalExpired");
const totalOnline = document.getElementById("totalOnline");

const serverSelect = document.getElementById("serverSelect");
const packageSelect = document.getElementById("packageSelect");
const searchInput = document.getElementById("searchSSH");

// ===============================
// DATA
// ===============================

let sshAccounts = [];
let sshServers = [];
let packages = [];
let onlineDevices = [];
// ===============================
// HEADER
// ===============================

function getHeaders() {

    return {

        "Content-Type": "application/json",

        "Authorization": "Bearer " + TOKEN

    };

}

// ===============================
// LOADING
// ===============================

function showLoading() {

    const loading = document.getElementById("loading");

    if (loading) {

        loading.style.display = "flex";

    }

}

function hideLoading() {

    const loading = document.getElementById("loading");

    if (loading) {

        loading.style.display = "none";

    }

}

// ===============================
// LOAD ACCOUNT
// ===============================

async function loadSSHAccounts() {

    try {

        showLoading();

        const res = await fetch(

            API + "/ssh/accounts",

            {

                headers: getHeaders()

            }

        );

        const json = await res.json();

        if (!json.success) {

            throw new Error(json.message);

        }

        sshAccounts = json.data || [];

        await loadOnlineDevices();

        renderStatistics();

        renderTable();

        updateCountdown();

    }

    catch (err) {

        console.error(err);

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        hideLoading();

    }

}
// ===============================
// LOAD ONLINE DEVICES
// ===============================

async function loadOnlineDevices() {

    try {

        const res = await fetch(

            API + "/ssh/device/online",

            {

                headers: getHeaders()

            }

        );

        const json = await res.json();

        if (json.success) {

            onlineDevices = json.data || [];

            totalOnline.textContent = onlineDevices.length;

        }

    } catch (err) {

        console.error(err);

    }

}
// ===============================
// LOAD SERVER
// ===============================

async function loadServers() {

    try {

        const res = await fetch(

            API + "/ssh/servers",

            {

                headers: getHeaders()

            }

        );

        const json = await res.json();

        sshServers = json.data || [];

        serverSelect.innerHTML = "";

        sshServers.forEach(server => {

            serverSelect.innerHTML += `

                <option value="${server.id}">

                    ${server.server_name}

                </option>

            `;

        });

    }

    catch (err) {

        console.error(err);

    }

}

// ===============================
// LOAD PACKAGE
// ===============================

async function loadPackages() {

    try {

        const res = await fetch(

            API + "/packages",

            {

                headers: getHeaders()

            }

        );

        const json = await res.json();

        packages = json.data || [];

        packageSelect.innerHTML = "";

        packages.forEach(pkg => {

            packageSelect.innerHTML += `

                <option value="${pkg.id}">

                    ${pkg.name}

                </option>

            `;

        });

    }

    catch (err) {

        console.error(err);

    }

}
// ===============================
// RENDER STATISTICS
// ===============================

function renderStatistics() {

    totalAccount.textContent = sshAccounts.length;

    const active = sshAccounts.filter(a =>
        String(a.status).toLowerCase() === "active"
    );

    totalActive.textContent = active.length;

    const now = new Date();

    let expired = 0;

    sshAccounts.forEach(acc => {

        if (!acc.expired_at) return;

        if (new Date(acc.expired_at) < now) {

            expired++;

        }

    });

    totalExpired.textContent = expired;

    totalOnline.textContent = onlineDevices.length;

}

// ===============================
// FORMAT DATE
// ===============================

function formatDate(date) {

    if (!date) return "-";

    return new Date(date).toLocaleDateString("id-ID", {

        year: "numeric",
        month: "short",
        day: "numeric"

    });

}

// ===============================
// STATUS BADGE
// ===============================

function statusBadge(status) {

    const s = String(status || "").toLowerCase();

    if (s === "active") {

        return `<span class="badge badge-success">ACTIVE</span>`;

    }

    if (s === "suspend") {

        return `<span class="badge badge-warning">SUSPEND</span>`;

    }

    return `<span class="badge badge-danger">${status}</span>`;

}

// ===============================
// RENDER TABLE
// ===============================

function renderTable(data = sshAccounts) {

    if (!data.length) {

        tableBody.innerHTML = `

            <tr>

                <td colspan="6"
                    style="padding:40px;text-align:center;">

                    Belum ada SSH Account

                </td>

            </tr>

        `;

        return;

    }

    tableBody.innerHTML = "";
     
    let html = "";
   
    data.forEach(acc => {

        html += `

        <tr>

            <td>

                <b>${acc.username}</b>

            </td>

            <td>

                ${acc.server_name || "-"}

            </td>

            <td>

                ${acc.package_name || "-"}

            </td>

            <td>

    <span class="badge countdown"
          data-expired="${acc.expired_at}">
        ⏳ Menghitung...
    </span>

           </td>

            <td>

                ${statusBadge(acc.status)}

            </td>
                       <td>

    <div class="action">

        <button class="btn-detail"
            onclick="showDetail(${acc.id})"
            title="Detail">

            <i class="fa-solid fa-eye"></i>

        </button>

        <button class="btn-password"
            onclick="changePassword(${acc.id})"
            title="Password">

            <i class="fa-solid fa-key"></i>

        </button>
        
        <button class="btn-renew"
    onclick="renewAccount(${acc.id})"
    title="Renew">

    <i class="fa-solid fa-rotate-right"></i>

</button>
        

        <button class="btn-toggle"
            onclick="toggleStatus(${acc.id},'${acc.status}')"
            title="Aktif / Suspend">

            <i class="fa-solid fa-power-off"></i>

        </button>

        <button class="btn-delete"
            onclick="deleteAccount(${acc.id})"
            title="Hapus">

            <i class="fa-solid fa-trash"></i>

        </button>

    </div>

</td>

        </tr>

        `;

    });
    tableBody.innerHTML = html;

    updateCountdown();
}

// ===============================
// SEARCH
// ===============================

if (searchInput) {

    searchInput.addEventListener("keyup", function () {

        const keyword = this.value.toLowerCase();

        const result = sshAccounts.filter(acc =>

            String(acc.username).toLowerCase().includes(keyword) ||

            String(acc.server_name || "")
                .toLowerCase()
                .includes(keyword) ||

            String(acc.package_name || "")
           .toLowerCase()
           .includes(keyword)

        );

        renderTable(result);

    });

}
// ===============================
// GET ACCOUNT BY ID
// ===============================

function getAccount(id) {

    return sshAccounts.find(a => a.id == id);

}

// ===============================
// SHOW DETAIL
// ===============================

async function showDetail(id) {

    const account = getAccount(id);

    if (!account) {

        return Swal.fire(
            "Error",
            "Data tidak ditemukan",
            "error"
        );

    }

    Swal.fire({

        title: account.username,

        html: `

        <table style="width:100%;text-align:left">

            <tr>
                <td><b>Member</b></td>
                <td>${account.name || "-"}</td>
            </tr>

            <tr>
                <td><b>Server</b></td>
                <td>${account.server_name || "-"}</td>
            </tr>

            <tr>
                <td><b>Package</b></td>
               <td>${account.package_name || "-"}</td>
           </tr>

            <tr>
                <td><b>Password</b></td>
                <td>${account.password}</td>
            </tr>

            <tr>
                <td><b>SSH</b></td>
                <td>${account.ssh_port}</td>
            </tr>

            <tr>
                <td><b>Dropbear</b></td>
                <td>${account.dropbear_port}</td>
            </tr>

            <tr>
                <td><b>SSL</b></td>
                <td>${account.ssl_port}</td>
            </tr>

            <tr>
                <td><b>UDP</b></td>
                <td>${account.udp_port}</td>
            </tr>

            <tr>
                <td><b>Expired</b></td>
                <td>${formatDate(account.expired_at)}</td>
            </tr>

            <tr>
                <td><b>Status</b></td>
                <td>${account.status}</td>
            </tr>

        </table>

        `,

        width:600

    });

}

// ===============================
// GENERATE ACCOUNT
// ===============================

async function generateAccount() {

    try {

        showLoading();

        const data = {

    server_id: serverSelect.value,

    package_id: packageSelect.value,

    username: document
        .getElementById("username")
        .value,

    password: document
        .getElementById("password")
        .value

};

        const res = await fetch(

            API + "/ssh/accounts",

            {

                method: "POST",

                headers: getHeaders(),

                body: JSON.stringify(data)

            }

        );

        const json = await res.json();

        if (!json.success) {

            throw new Error(

                json.message || "Generate gagal"

            );

        }

        Swal.fire(

            "Berhasil",

            "SSH Account berhasil dibuat",

            "success"

        );

        document
            .getElementById("generateModal")
            .style.display = "none";

        loadSSHAccounts();

    }

    catch (err) {

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        hideLoading();

    }

}

// ===============================
// REFRESH
// ===============================

function refreshData() {

    loadSSHAccounts();

}
// ===============================
// CHANGE PASSWORD
// ===============================

async function changePassword(id) {

    const account = getAccount(id);

    if (!account) return;

    const result = await Swal.fire({

        title: "Ganti Password",

        input: "text",

        inputValue: account.password,

        inputPlaceholder: "Password baru",

        showCancelButton: true,

        confirmButtonText: "Simpan",

        cancelButtonText: "Batal"

    });

    if (!result.isConfirmed) return;

    try {

        showLoading();

        const res = await fetch(

            API + "/ssh/accounts/" + id + "/password",

            {

                method: "POST",

                headers: getHeaders(),

                body: JSON.stringify({

                    password: result.value

                })

            }

        );

        const json = await res.json();

        if (!json.success) {

            throw new Error(json.message);

        }

        Swal.fire(

            "Berhasil",

            "Password berhasil diubah",

            "success"

        );

        loadSSHAccounts();

    }

    catch (err) {

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        hideLoading();

    }

}

// ===============================
// ACTIVATE / SUSPEND
// ===============================

async function toggleStatus(id, status) {

    const endpoint =

        String(status).toLowerCase() === "active"

        ? "suspend"

        : "activate";

    try {

        showLoading();

        const res = await fetch(

            API + "/ssh/accounts/" + id + "/" + endpoint,

            {

                method: "POST",

                headers: getHeaders()

            }

        );

        const json = await res.json();

        if (!json.success) {

            throw new Error(json.message);

        }

        Swal.fire(

            "Berhasil",

            "Status berhasil diperbarui",

            "success"

        );

        loadSSHAccounts();

    }

    catch (err) {

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        hideLoading();

    }

}

// ===============================
// DELETE
// ===============================

async function deleteAccount(id) {

    const confirm = await Swal.fire({

        title: "Hapus Account?",

        text: "Data tidak bisa dikembalikan.",

        icon: "warning",

        showCancelButton: true,

        confirmButtonText: "Hapus",

        cancelButtonText: "Batal"

    });

    if (!confirm.isConfirmed) return;

    try {

        showLoading();

        const res = await fetch(

            API + "/ssh/accounts/" + id,

            {

                method: "DELETE",

                headers: getHeaders()

            }

        );

        const json = await res.json();

        if (!json.success) {

            throw new Error(json.message);

        }

        Swal.fire(

            "Berhasil",

            "Account berhasil dihapus",

            "success"

        );

        loadSSHAccounts();

    }

    catch (err) {

        Swal.fire(

            "Error",

            err.message,

            "error"

        );

    }

    finally {

        hideLoading();

    }

}

// ===============================
// OPEN MODAL
// ===============================

function openGenerateModal() {

    document.getElementById("generateModal").style.display = "flex";

}

// ===============================
// CLOSE MODAL
// ===============================

function closeGenerateModal() {

    document.getElementById("generateModal").style.display = "none";

}

// ===============================
// AUTO REFRESH
// ===============================

setInterval(() => {

    loadSSHAccounts();

}, 30000);
// ===============================
// GENERATE PASSWORD
// ===============================

function generatePassword() {

    const chars =
        "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";

    let pass = "";

    for (let i = 0; i < 8; i++) {

        pass += chars.charAt(
            Math.floor(Math.random() * chars.length)
        );

    }

    document.getElementById("password").value = pass;

}
// ===============================
// CLOCK INI OK RATA
// ===============================

function updateClock() {

    const el = document.getElementById("clock");

    if (!el) return;

    const now = new Date();

    el.textContent = now.toLocaleString("id-ID", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    });

}

updateClock();
setInterval(updateClock, 1000);
function updateCountdown(){

    const now = new Date().getTime();

    document.querySelectorAll(".countdown").forEach(el=>{

        const expired = el.dataset.expired;

        if(!expired) return;

        const end = new Date(expired).getTime();

        let diff = end - now;

        const row = sshAccounts.find(a => a.expired_at === expired);

        if(diff <= 0){

            el.className = "badge badge-danger";

            el.innerHTML =
                '<i class="fa-solid fa-circle-xmark"></i> Expired';

            if(row && row.status !== "expired"){

                row.status = "expired";

            }

            return;

        }

        if(row){

            row.status = "active";

        }

        const days = Math.floor(diff / 86400000);
        diff %= 86400000;

        const hours = Math.floor(diff / 3600000);
        diff %= 3600000;

        const minutes = Math.floor(diff / 60000);
        diff %= 60000;

        const seconds = Math.floor(diff / 1000);

        el.className =
        days > 7
        ? "badge countdown badge-success"
        : "badge countdown badge-warning";

        let text = "";

        if(days>0){

            text += days + " Hari ";

        }

        text +=
            String(hours).padStart(2,"0")+":"+
            String(minutes).padStart(2,"0")+":"+
            String(seconds).padStart(2,"0");

        el.innerHTML =
            '<i class="fa-solid fa-hourglass-half"></i> ' + text;

    });

    renderStatistics();

}
// ===============================
// EXPORT PDF
// ===============================

function exportSSHPDF(){

    window.open(
        API + "/ssh/accounts/pdf?token=" + TOKEN,
        "_blank"
    );

}
// =======================================
// RENEW ACCOUNT
// =======================================

async function renewAccount(id){

    const package_id = prompt(

        "Masukkan ID Package :"

    );

    if(!package_id){

        return;

    }

    try{
        const res = await fetch(

    API + "/ssh/accounts/" + id + "/renew",

    {

        method: "POST",

        headers: getHeaders(),

        body: JSON.stringify({

            package_id

        })

    }

);

        const json = await res.json();

        alert(json.message);

        if(json.success){

            loadSSHAccounts();

        }

    }catch(err){

        alert(err.message);

    }

}
// ===============================
// START
// ===============================

loadServers();
loadPackages();

loadSSHAccounts();

setInterval(function(){

    updateCountdown();

},1000);

