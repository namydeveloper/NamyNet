/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: wifi_voucher
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(50) DEFAULT 'fa-circle-info',
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES
(1,'fa-wifi','Voucher NMXpzj digunakan',NULL,'2026-07-20 10:19:30'),
(2,'fa-wifi','Voucher NMJL8N digunakan',NULL,'2026-07-20 10:20:30'),
(3,'fa-wifi','Voucher NMjcDE digunakan',NULL,'2026-07-20 10:22:00'),
(4,'fa-wifi','Voucher NMpJGp digunakan',NULL,'2026-07-20 11:43:00'),
(5,'fa-wifi','Voucher NMcAys digunakan',NULL,'2026-07-20 13:41:30'),
(6,'fa-wifi','Voucher NMmM3z digunakan',NULL,'2026-07-20 13:51:00');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES
(1,'Administrator','admin','$2b$10$P2k.HdhZVIXXIzIYn6pqxu91JBTgiJsQdhiKNGCyjoduxeg2gd4rO','2026-07-05 11:42:41');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(30) DEFAULT NULL,
  `fullname` varchar(100) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_services`
--

DROP TABLE IF EXISTS `member_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `service` enum('hotspot','ssh','websocket') DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `expired_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_services`
--

LOCK TABLES `member_services` WRITE;
/*!40000 ALTER TABLE `member_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `router_id` int(11) DEFAULT NULL,
  `status` enum('active','suspended','expired') DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES
(1,'Budi','08123456789','budi@gmail.com','budi001','123456',2,1,'active','2026-07-10 17:33:18','2026-08-31 00:00:00');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `profile` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `quota` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES
(2,'1 Jam Hemat','1jam',1000.00,60,0,'2026-07-09 11:10:21'),
(3,'3 Jam','3jam',2000.00,180,0,'2026-07-09 11:10:21'),
(4,'6 Jam','6jam',3000.00,360,0,'2026-07-09 11:10:21'),
(5,'12 Jam','12jam',4000.00,720,0,'2026-07-09 11:10:21'),
(6,'1 Hari','1hari',5000.00,1440,0,'2026-07-09 11:10:21'),
(7,'7 Hari','7hari',35000.00,10080,0,'2026-07-09 11:10:21'),
(8,'30 Hari','30hari',150000.00,43200,0,'2026-07-09 11:10:21');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routers`
--

DROP TABLE IF EXISTS `routers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `routers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `host` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT 8728,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routers`
--

LOCK TABLES `routers` WRITE;
/*!40000 ALTER TABLE `routers` DISABLE KEYS */;
INSERT INTO `routers` VALUES
(9,'MikroTik Utama','10.100.0.2','admin','Namy1234@mrx',8728,1,'2026-07-14 02:54:46');
/*!40000 ALTER TABLE `routers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_accounts`
--

DROP TABLE IF EXISTS `service_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `service` enum('websocket','ssh','wireguard','vless') DEFAULT 'websocket',
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `ws_port` int(11) DEFAULT 80,
  `wss_port` int(11) DEFAULT 443,
  `ssh_port` int(11) DEFAULT 22,
  `websocket_path` varchar(100) DEFAULT '/',
  `bug_host` varchar(150) DEFAULT NULL,
  `sni` varchar(150) DEFAULT NULL,
  `max_devices` int(11) DEFAULT 1,
  `quota` bigint(20) DEFAULT 0,
  `description` text DEFAULT NULL,
  `status` enum('active','expired','disabled') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `expired_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `server_id` (`server_id`),
  CONSTRAINT `service_accounts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_accounts_ibfk_2` FOREIGN KEY (`server_id`) REFERENCES `service_servers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_accounts`
--

LOCK TABLES `service_accounts` WRITE;
/*!40000 ALTER TABLE `service_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_servers`
--

DROP TABLE IF EXISTS `service_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(100) NOT NULL,
  `host` varchar(150) NOT NULL,
  `domain` varchar(150) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `ws_port` int(11) DEFAULT 80,
  `wss_port` int(11) DEFAULT 443,
  `ssh_port` int(11) DEFAULT 22,
  `websocket_path` varchar(100) DEFAULT '/',
  `location` varchar(100) DEFAULT NULL,
  `provider` varchar(100) DEFAULT NULL,
  `panel_type` enum('namynet','xray','custom') DEFAULT 'namynet',
  `status` enum('online','offline') DEFAULT 'offline',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_servers`
--

LOCK TABLES `service_servers` WRITE;
/*!40000 ALTER TABLE `service_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'voucher_prefix','AH'),
(2,'voucher_length','8'),
(3,'expired_day','8'),
(4,'auto_delete','1'),
(5,'auto_sync','1'),
(6,'app_name','Wifi voucher'),
(7,'company_name','NamyStore'),
(8,'timezone','Asia/Jakarta'),
(37,'domain','login.namystore.com'),
(38,'login_url','https://login.namystore.com'),
(39,'redirect_url','https://google.com'),
(40,'https_enable','1'),
(45,'hotspot_domain',''),
(46,'hotspot_protocol','https'),
(47,'hotspot_redirect',''),
(48,'hotspot_ssl','1');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ssh_accounts`
--

DROP TABLE IF EXISTS `ssh_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ssh_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `server_id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `ssh_port` int(11) DEFAULT 22,
  `dropbear_port` int(11) DEFAULT 80,
  `ssl_port` int(11) DEFAULT 443,
  `udp_port` int(11) DEFAULT 7300,
  `status` enum('unused','active','expired','disabled') DEFAULT 'unused',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `first_login` datetime DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  `device_limit` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `server_id` (`server_id`),
  KEY `fk_ssh_package` (`package_id`),
  CONSTRAINT `fk_ssh_package` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ssh_accounts_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ssh_accounts_ibfk_2` FOREIGN KEY (`server_id`) REFERENCES `ssh_servers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssh_accounts`
--

LOCK TABLES `ssh_accounts` WRITE;
/*!40000 ALTER TABLE `ssh_accounts` DISABLE KEYS */;
INSERT INTO `ssh_accounts` VALUES
(56,NULL,6,6,'Namy','123',22,80,443,7300,'active','2026-07-24 10:30:54','2026-07-24 10:31:23','2026-07-25 10:31:23',1);
/*!40000 ALTER TABLE `ssh_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ssh_servers`
--

DROP TABLE IF EXISTS `ssh_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ssh_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(100) NOT NULL,
  `host` varchar(100) NOT NULL,
  `ssh_port` int(11) DEFAULT 22,
  `dropbear_port` int(11) DEFAULT 80,
  `ssl_port` int(11) DEFAULT 443,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `status` enum('online','offline') DEFAULT 'offline',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssh_servers`
--

LOCK TABLES `ssh_servers` WRITE;
/*!40000 ALTER TABLE `ssh_servers` DISABLE KEYS */;
INSERT INTO `ssh_servers` VALUES
(6,'NamyNet SGP','namystore.com',22,80,443,'root','Ahmad1234@MRX','online','2026-07-18 11:37:38');
/*!40000 ALTER TABLE `ssh_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ssh_sessions`
--

DROP TABLE IF EXISTS `ssh_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ssh_sessions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `server_id` int(11) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `pid` bigint(20) NOT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL,
  `status` enum('online','offline') DEFAULT 'online',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssh_sessions`
--

LOCK TABLES `ssh_sessions` WRITE;
/*!40000 ALTER TABLE `ssh_sessions` DISABLE KEYS */;
INSERT INTO `ssh_sessions` VALUES
(1,48,9,'Aida',1123612,'182.4.39.153','2026-07-22 16:10:13','2026-07-22 16:10:42','offline'),
(2,48,9,'Aida',1123734,'182.4.39.153','2026-07-22 16:11:21','2026-07-22 16:11:43','offline'),
(3,48,9,'Aida',1124630,'182.4.39.153','2026-07-22 16:50:35','2026-07-22 17:02:56','offline'),
(4,48,9,'Aida',1124887,'182.4.39.153','2026-07-22 17:03:11','2026-07-22 17:03:17','offline'),
(5,48,9,'Aida',1125138,'182.4.39.153','2026-07-22 17:15:15','2026-07-22 17:15:25','offline'),
(6,48,9,'Aida',1125404,'182.4.39.153','2026-07-22 17:16:43','2026-07-22 17:21:30','offline'),
(7,48,9,'Aida',1126119,'182.4.39.153','2026-07-22 18:09:00','2026-07-22 18:09:08','offline'),
(8,48,9,'Aida',1126216,'182.4.39.153','2026-07-22 18:11:17','2026-07-22 18:11:39','offline'),
(9,48,9,'Aida',1126339,'182.4.39.153','2026-07-22 18:11:54','2026-07-22 18:12:15','offline'),
(10,48,9,'Aida',1126943,'182.4.39.153','2026-07-22 18:53:25','2026-07-22 19:00:42','offline'),
(11,48,9,'Aida',1127014,'203.17.85.107','2026-07-22 18:53:57','2026-07-22 19:00:12','offline'),
(12,48,9,'Aida',1127176,'182.4.39.153','2026-07-22 19:00:55','2026-07-22 19:02:58','offline'),
(13,48,9,'Aida',1127247,'203.17.85.107','2026-07-22 19:01:00','2026-07-22 19:02:55','offline'),
(14,48,9,'Aida',1138837,'203.17.85.4','2026-07-23 12:08:20','2026-07-23 12:17:54','offline'),
(15,48,9,'Aida',1138899,'203.17.85.4','2026-07-23 12:08:38','2026-07-23 12:08:50','offline'),
(16,48,9,'Aida',1139260,'203.17.85.4','2026-07-23 12:19:57','2026-07-23 12:27:34','offline'),
(17,48,9,'Aida',1139337,'203.17.85.4','2026-07-23 12:20:05','2026-07-23 12:38:34','offline'),
(18,48,9,'Aida',1139776,'203.17.85.4','2026-07-23 12:39:40','2026-07-23 12:44:03','offline'),
(19,48,9,'Aida',1139847,'203.17.85.4','2026-07-23 12:39:52','2026-07-23 12:40:15','offline'),
(20,48,9,'Aida',1139902,'203.17.85.4','2026-07-23 12:41:14','2026-07-23 12:41:35','offline'),
(21,51,6,'Namy',1141503,'203.17.85.4','2026-07-23 13:03:35','2026-07-23 13:04:03','offline'),
(22,51,6,'Namy',1141564,'203.17.85.4','2026-07-23 13:03:50','2026-07-23 13:03:51','offline'),
(23,51,6,'Namy',1141710,'203.17.85.4','2026-07-23 13:04:30','2026-07-23 13:06:48','offline'),
(24,51,6,'Namy',1141770,'203.17.85.4','2026-07-23 13:04:50','2026-07-23 13:04:52','offline'),
(25,51,6,'Namy',1141979,'203.17.85.4','2026-07-23 13:06:49','2026-07-23 13:08:57','offline'),
(26,51,6,'Namy',1142287,'203.17.85.4','2026-07-23 13:09:01','2026-07-23 13:19:22','offline'),
(27,51,6,'Namy',1142378,'203.17.85.4','2026-07-23 13:09:08','2026-07-23 13:09:09','offline'),
(28,51,6,'Namy',1142744,'203.17.85.4','2026-07-23 13:20:25','2026-07-23 13:21:13','offline'),
(29,51,6,'Namy',1142822,'203.17.85.4','2026-07-23 13:20:34','2026-07-23 13:20:35','offline'),
(30,51,6,'Namy',1142976,'203.17.85.4','2026-07-23 13:20:36','2026-07-23 13:20:37','offline'),
(31,51,6,'Namy',1143141,'203.17.85.4','2026-07-23 13:20:38','2026-07-23 13:20:39','offline'),
(32,51,6,'Namy',1143321,'203.17.85.4','2026-07-23 13:20:40','2026-07-23 13:20:41','offline'),
(33,51,6,'Namy',1143501,'203.17.85.4','2026-07-23 13:20:42','2026-07-23 13:20:43','offline'),
(34,51,6,'Namy',1143681,'203.17.85.4','2026-07-23 13:20:44','2026-07-23 13:20:45','offline'),
(35,51,6,'Namy',1143861,'203.17.85.4','2026-07-23 13:20:46','2026-07-23 13:20:47','offline'),
(36,51,6,'Namy',1144042,'203.17.85.4','2026-07-23 13:20:48','2026-07-23 13:20:49','offline'),
(37,51,6,'Namy',1144224,'203.17.85.4','2026-07-23 13:20:50','2026-07-23 13:20:51','offline'),
(38,51,6,'Namy',1144402,'203.17.85.4','2026-07-23 13:20:52','2026-07-23 13:20:53','offline'),
(39,51,6,'Namy',1144609,'203.17.85.4','2026-07-23 13:20:54','2026-07-23 13:20:55','offline'),
(40,51,6,'Namy',1144763,'203.17.85.4','2026-07-23 13:20:56','2026-07-23 13:20:57','offline'),
(41,51,6,'Namy',1144943,'203.17.85.4','2026-07-23 13:20:58','2026-07-23 13:20:59','offline'),
(42,51,6,'Namy',1145123,'203.17.85.4','2026-07-23 13:21:00','2026-07-23 13:21:01','offline'),
(43,51,6,'Namy',1145303,'203.17.85.4','2026-07-23 13:21:02','2026-07-23 13:21:03','offline'),
(44,51,6,'Namy',1145526,'203.17.85.4','2026-07-23 13:21:04','2026-07-23 13:21:05','offline'),
(45,51,6,'Namy',1145663,'203.17.85.4','2026-07-23 13:21:06','2026-07-23 13:21:07','offline'),
(46,51,6,'Namy',1145849,'203.17.85.4','2026-07-23 13:21:08','2026-07-23 13:21:09','offline'),
(47,51,6,'Namy',1146050,'203.17.85.4','2026-07-23 13:21:10','2026-07-23 13:21:11','offline'),
(48,51,6,'Namy',1146203,'203.17.85.4','2026-07-23 13:21:12','2026-07-23 13:21:12','offline'),
(49,51,6,'Namy',1146400,'203.17.85.4','2026-07-23 13:21:14','2026-07-23 13:21:55','offline'),
(50,51,6,'Namy',1146527,'203.17.85.4','2026-07-23 13:21:46','2026-07-23 13:21:47','offline'),
(51,51,6,'Namy',1146698,'203.17.85.4','2026-07-23 13:21:48','2026-07-23 13:21:49','offline'),
(52,51,6,'Namy',1146858,'203.17.85.4','2026-07-23 13:21:50','2026-07-23 13:21:51','offline'),
(53,51,6,'Namy',1147042,'203.17.85.4','2026-07-23 13:21:52','2026-07-23 13:21:53','offline'),
(54,51,6,'Namy',1147205,'203.17.85.4','2026-07-23 13:21:54','2026-07-23 13:21:55','offline'),
(55,51,6,'Namy',1147428,'203.17.85.4','2026-07-23 13:21:56','2026-07-23 13:25:35','offline'),
(56,51,6,'Namy',1147484,'203.17.85.4','2026-07-23 13:23:17','2026-07-23 13:23:18','offline'),
(57,51,6,'Namy',1147631,'203.17.85.4','2026-07-23 13:23:19','2026-07-23 13:23:20','offline'),
(58,51,6,'Namy',1147901,'203.17.85.4','2026-07-23 13:24:00','2026-07-23 13:24:01','offline'),
(59,51,6,'Namy',1148157,'203.17.85.4','2026-07-23 13:25:41','2026-07-23 13:26:08','offline'),
(60,51,6,'Namy',1148249,'203.17.85.4','2026-07-23 13:25:48','2026-07-23 13:25:49','offline'),
(61,51,6,'Namy',1148442,'203.17.85.4','2026-07-23 13:26:43','2026-07-23 13:27:07','offline'),
(62,51,6,'Namy',1148530,'203.17.85.4','2026-07-23 13:28:16','2026-07-23 14:18:01','offline'),
(63,51,6,'Namy',1148667,'203.17.85.4','2026-07-23 13:29:31','2026-07-23 13:29:33','offline'),
(64,51,6,'Namy',1148869,'203.17.85.4','2026-07-23 13:29:34','2026-07-23 13:29:35','offline'),
(65,51,6,'Namy',1149051,'203.17.85.4','2026-07-23 13:29:36','2026-07-23 13:29:37','offline'),
(66,51,6,'Namy',1149189,'203.17.85.4','2026-07-23 13:29:38','2026-07-23 13:29:39','offline'),
(67,51,6,'Namy',1149369,'203.17.85.4','2026-07-23 13:29:40','2026-07-23 13:29:41','offline'),
(68,51,6,'Namy',1149590,'203.17.85.4','2026-07-23 13:29:42','2026-07-23 13:29:43','offline'),
(69,51,6,'Namy',1149729,'203.17.85.4','2026-07-23 13:29:44','2026-07-23 13:29:45','offline'),
(70,51,6,'Namy',1149909,'203.17.85.4','2026-07-23 13:29:46','2026-07-23 13:29:47','offline'),
(71,51,6,'Namy',1150092,'203.17.85.4','2026-07-23 13:29:48','2026-07-23 13:29:49','offline'),
(72,51,6,'Namy',1150312,'203.17.85.4','2026-07-23 13:29:50','2026-07-23 13:29:51','offline'),
(73,51,6,'Namy',1150548,'203.17.85.4','2026-07-23 13:34:22','2026-07-23 13:34:24','offline'),
(74,51,6,'Namy',1150707,'203.17.85.4','2026-07-23 13:34:25','2026-07-23 13:34:26','offline'),
(75,51,6,'Namy',1150990,'203.17.85.4','2026-07-23 13:39:23','2026-07-23 13:39:25','offline'),
(76,51,6,'Namy',1151190,'203.17.85.4','2026-07-23 13:39:28','2026-07-23 13:39:29','offline'),
(77,52,6,'Dewa',1151926,'203.17.85.4','2026-07-23 13:44:48','2026-07-23 13:50:13','offline'),
(78,53,6,'Namy',1153689,'203.17.85.4','2026-07-23 14:18:57','2026-07-23 14:19:49','offline'),
(79,55,6,'Namy',1156962,'203.17.85.4','2026-07-23 15:58:00','2026-07-23 16:00:23','offline'),
(80,55,6,'Namy',1402927,'127.0.0.1','2026-07-24 10:25:44','2026-07-24 10:26:15','offline'),
(81,55,6,'Namy',1403048,'127.0.0.1','2026-07-24 10:29:04','2026-07-24 10:30:14','offline'),
(82,56,6,'Namy',1403393,'127.0.0.1','2026-07-24 10:31:23','2026-07-24 10:34:01','offline'),
(83,56,6,'Namy',1403550,'127.0.0.1','2026-07-24 10:34:10','2026-07-24 10:34:42','offline'),
(84,56,6,'Namy',1403629,'127.0.0.1','2026-07-24 10:34:49','2026-07-24 10:34:53','offline'),
(85,56,6,'Namy',1404188,'127.0.0.1','2026-07-24 10:54:08','2026-07-24 10:54:47','offline'),
(86,56,6,'Namy',1404552,'127.0.0.1','2026-07-24 11:01:33','2026-07-24 11:01:44','offline'),
(87,56,6,'Namy',1404683,'127.0.0.1','2026-07-24 11:02:48','2026-07-24 11:03:03','offline'),
(88,56,6,'Namy',1404916,'127.0.0.1','2026-07-24 11:09:28','2026-07-24 11:09:45','offline'),
(89,56,6,'Namy',1405409,'127.0.0.1','2026-07-24 11:23:07','2026-07-24 11:23:13','offline'),
(90,56,6,'Namy',1406240,'127.0.0.1','2026-07-24 11:28:03','2026-07-24 11:39:27','offline'),
(91,56,6,'Namy',1406623,'127.0.0.1','2026-07-24 11:39:31','2026-07-24 11:39:44','offline'),
(92,56,6,'Namy',1406699,'127.0.0.1','2026-07-24 11:39:45','2026-07-24 11:41:41','offline'),
(93,56,6,'Namy',1406894,'127.0.0.1','2026-07-24 11:44:47','2026-07-24 11:45:28','offline'),
(94,56,6,'Namy',1407454,'127.0.0.1','2026-07-24 12:03:08','2026-07-24 12:03:37','offline'),
(95,56,6,'Namy',1407643,'127.0.0.1','2026-07-24 12:04:43','2026-07-24 12:05:32','offline'),
(96,56,6,'Namy',1407777,'127.0.0.1','2026-07-24 12:05:58','2026-07-24 12:18:21','offline'),
(97,56,6,'Namy',1408169,'127.0.0.1','2026-07-24 12:18:22','2026-07-24 12:18:49','offline'),
(98,56,6,'Namy',1408378,'127.0.0.1','2026-07-24 12:23:39','2026-07-24 12:23:54','offline'),
(99,56,6,'Namy',1408511,'127.0.0.1','2026-07-24 12:25:52','2026-07-24 12:26:29','offline'),
(100,56,6,'Namy',1408665,'127.0.0.1','2026-07-24 12:27:37','2026-07-24 12:38:23','offline'),
(101,56,6,'Namy',1409210,'127.0.0.1','2026-07-24 12:40:49','2026-07-24 12:41:03','offline'),
(102,56,6,'Namy',1409283,'127.0.0.1','2026-07-24 12:41:05','2026-07-24 12:41:56','offline'),
(103,56,6,'Namy',1409386,'127.0.0.1','2026-07-24 12:42:28','2026-07-24 12:42:53','offline');
/*!40000 ALTER TABLE `ssh_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `profile` varchar(100) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `router_id` int(11) DEFAULT NULL,
  `type` enum('voucher','member') NOT NULL DEFAULT 'voucher',
  `status` varchar(20) DEFAULT 'unused',
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `expired_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
INSERT INTO `vouchers` VALUES
(191,'NMcAys','NMcAys','NMcAys','30hari',8,9,'voucher','used','2026-07-20 13:41:30','2026-07-20 10:17:55','2026-08-19 13:41:30',1),
(192,'NMpJGp','NMpJGp','NMpJGp','30hari',8,9,'voucher','used','2026-07-20 11:43:00','2026-07-20 10:18:09','2026-08-19 11:43:00',1),
(193,'NMjcDE','NMjcDE','NMjcDE','30hari',8,9,'voucher','used','2026-07-20 10:22:00','2026-07-20 10:18:09','2026-08-19 10:22:00',1),
(194,'NMXpzj','NMXpzj','NMXpzj','30hari',8,9,'voucher','used','2026-07-20 10:19:30','2026-07-20 10:18:10','2026-08-19 10:19:30',1),
(195,'NMJL8N','NMJL8N','NMJL8N','30hari',8,9,'voucher','used','2026-07-20 10:20:30','2026-07-20 10:18:10','2026-08-19 10:20:30',1),
(196,'NMmM3z','NMmM3z','NMmM3z','30hari',8,9,'voucher','used','2026-07-20 13:51:00','2026-07-20 13:50:17','2026-08-19 13:51:00',1);
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-24 12:43:53
